# import os
# import json
# import asyncio
# import logging
# from pathlib import Path
# from typing import Optional, Dict, Any, List
# from enum import Enum
# from pydantic import BaseModel, ConfigDict

# logger = logging.getLogger(__name__)

# class BlenderConfig(BaseModel):
#     blender_path: str
#     python_path: str
#     scripts_path: str
#     output_path: str
#     temp_path: str

# class ExportSettings(BaseModel):
#     format: str = "glb"
#     scale: float = 1.0
#     optimize: bool = True
#     texture_resolution: int = 1024

# class OutputFormat(str, Enum):
#     GLB = "glb"
#     GLTF = "gltf"
#     OBJ = "obj"
#     FBX = "fbx"
#     BLEND = "blend"

#     @classmethod
#     def __get_pydantic_core_schema__(cls, source_type, handler):
#         return handler(cls)

# class ModelGenerationRequest(BaseModel):
#     session_id: int
#     input_json: Dict[str, Any]
#     export_settings: ExportSettings
#     output_formats: List[OutputFormat]

#     model_config = ConfigDict(arbitrary_types_allowed=True)

# class BlenderIntegration:
#     def __init__(self, config: BlenderConfig, db_manager):
#         self.config = config
#         self.db_manager = db_manager
#         os.makedirs(self.config.output_path, exist_ok=True)
#         os.makedirs(self.config.temp_path, exist_ok=True)

#     async def generate_3d_model(self, request: ModelGenerationRequest) -> Dict[str, Any]:
#         """Generate 3D model from JSON input"""
#         try:
#             # Save input JSON
#             temp_json_path = os.path.join(self.config.temp_path, f"session_{request.session_id}.json")
#             with open(temp_json_path, 'w') as f:
#                 json.dump(request.input_json, f)

#             # Generate output
#             output_base = os.path.join(self.config.output_path, f"model_{request.session_id}")
#             export_paths = await self._convert_json_to_3d(temp_json_path, output_base, request.export_settings)
            
#             # Save to database
#             await self._save_model_outputs(request.session_id, export_paths)
            
#             return {
#                 "status": "success",
#                 "session_id": request.session_id,
#                 "output_files": export_paths
#             }
#         except Exception as e:
#             logger.error(f"3D model generation failed: {str(e)}", exc_info=True)
#             raise

#     async def _convert_json_to_3d(self, json_path: str, output_base: str, settings: ExportSettings) -> Dict[str, str]:
#         """Convert JSON to 3D model formats"""
#         try:
#             from glb_generator import convert_json_to_glb
#             result = convert_json_to_glb(
#                 json_path=json_path,
#                 output_base_path=output_base,
#                 scale=settings.scale,
#                 texture_resolution=settings.texture_resolution
#             )
#             if not result:
#                 raise ValueError("No models were generated")
#             return result
#         except Exception as e:
#             logger.error(f"3D conversion failed: {str(e)}")
#             raise

#     async def _save_model_outputs(self, session_id: int, export_paths: Dict[str, str]) -> None:
#         from database_manager import db_manager

#         allowed_types = {"glb", "obj"}  # match DB column constraint

#         try:
#             with db_manager.get_session() as db:
#                 for format, path in export_paths.items():
#                     if format not in allowed_types:
#                         logger.warning(f"Skipping format {format} — not allowed in DB")
#                         continue

#                     try:
#                         file_size = os.path.getsize(path) / (1024 * 1024)
#                         output_data = {
#                             "session_id": session_id,
#                             "output_type": format,
#                             "file_path": path,
#                             "file_size_mb": file_size,
#                             "generation_time_ms": None,
#                             "blender_version": None,
#                             "export_settings": None,
#                             "quality_metrics": None
#                         }
#                         db_manager.save_model_output(db, output_data)
#                     except Exception as e:
#                         logger.error(f"Failed to save model output {path}: {str(e)}")
#         except Exception as e:
#             logger.error(f"Failed to connect to database for saving model outputs: {str(e)}", exc_info=True)




import os
import json
import asyncio
import logging
from pathlib import Path
from typing import Optional, Dict, Any, List
from enum import Enum
from pydantic import BaseModel, ConfigDict

logger = logging.getLogger(__name__)

class BlenderConfig(BaseModel):
    blender_path: str
    python_path: str
    scripts_path: str
    output_path: str
    temp_path: str

class ExportSettings(BaseModel):
    format: str = "glb"
    scale: float = 1.0
    optimize: bool = True
    texture_resolution: int = 1024

class OutputFormat(str, Enum):
    GLB = "glb"
    GLTF = "gltf"
    OBJ = "obj"
    FBX = "fbx"
    BLEND = "blend"

    @classmethod
    def __get_pydantic_core_schema__(cls, source_type, handler):
        return handler(cls)

class ModelGenerationRequest(BaseModel):
    session_id: int
    input_json: Dict[str, Any]
    export_settings: ExportSettings
    output_formats: List[OutputFormat]

    model_config = ConfigDict(arbitrary_types_allowed=True)

class BlenderIntegration:
    def __init__(self, config: BlenderConfig, db_manager):
        self.config = config
        self.db_manager = db_manager
        os.makedirs(self.config.output_path, exist_ok=True)
        os.makedirs(self.config.temp_path, exist_ok=True)

    async def generate_3d_model(self, request: ModelGenerationRequest) -> Dict[str, Any]:
        """Generate 3D model from JSON input"""
        try:
            # Look for the JSON file in the exports folder with the correct naming pattern
            exports_dir = os.path.join(os.getcwd(), 'exports')
            json_filename = f"session_{request.session_id}_final.json"
            json_file_path = os.path.join(exports_dir, json_filename)
            
            # Check if the file exists in exports folder
            if os.path.exists(json_file_path):
                print(f"Found JSON file at: {json_file_path}")
            else:
                # Fallback: save the input JSON to temp location
                temp_json_path = os.path.join(self.config.temp_path, f"session_{request.session_id}.json")
                with open(temp_json_path, 'w') as f:
                    json.dump(request.input_json, f)
                json_file_path = temp_json_path
                print(f"Using temp JSON file at: {json_file_path}")

            # Generate output using the corrected path
            output_base = os.path.join(self.config.output_path, f"model_{request.session_id}")
            export_paths = await self._convert_json_to_3d(json_file_path, output_base, request.export_settings)
            
            # Save to database
            await self._save_model_outputs(request.session_id, export_paths)
            
            return {
                "status": "success",
                "session_id": request.session_id,
                "output_files": export_paths,
                "source_json": json_file_path
            }
        except Exception as e:
            logger.error(f"3D model generation failed: {str(e)}", exc_info=True)
            raise

    async def _convert_json_to_3d(self, json_path: str, output_base: str, settings: ExportSettings) -> Dict[str, str]:
        """Convert JSON to 3D model formats using the fixed GLB generator"""
        try:
            # Import the fixed GLB generator
            from glb_generator import convert_json_to_glb
            
            # Use the convert function that matches the working version
            result = convert_json_to_glb(
                json_path=json_path,
                output_base_path=output_base,
                scale=settings.scale,
                texture_resolution=settings.texture_resolution
            )
            
            if not result:
                raise ValueError("No models were generated")
                
            print(f"Generated models: {list(result.keys())}")
            return result
            
        except ImportError as e:
            logger.error(f"Could not import GLB generator: {str(e)}")
            raise ValueError(f"GLB generator not available: {str(e)}")
        except Exception as e:
            logger.error(f"3D conversion failed: {str(e)}")
            raise

    async def _save_model_outputs(self, session_id: int, export_paths: Dict[str, str]) -> None:
        """Save model outputs to database"""
        from database_manager import db_manager

        allowed_types = {"glb", "obj"}  # match DB column constraint

        try:
            with db_manager.get_session() as db:
                for format, path in export_paths.items():
                    if format not in allowed_types:
                        logger.warning(f"Skipping format {format} – not allowed in DB")
                        continue

                    try:
                        file_size = os.path.getsize(path) / (1024 * 1024)
                        output_data = {
                            "session_id": session_id,
                            "output_type": format,
                            "file_path": path,
                            "file_size_mb": file_size,
                            "generation_time_ms": None,
                            "blender_version": None,
                            "export_settings": None,
                            "quality_metrics": None
                        }
                        db_manager.save_model_output(db, output_data)
                        print(f"  -> Saved {format} model to database")
                    except Exception as e:
                        logger.error(f"Failed to save model output {path}: {str(e)}")
        except Exception as e:
            logger.error(f"Failed to connect to database for saving model outputs: {str(e)}", exc_info=True)