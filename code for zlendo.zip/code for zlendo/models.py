# from sqlalchemy import (
#     Column, Integer, String, Text, JSON, Float, Boolean, 
#     TIMESTAMP, Enum, ForeignKey, Index, DECIMAL
# )
# from sqlalchemy.ext.declarative import declarative_base
# from sqlalchemy.orm import relationship
# from sqlalchemy.sql import func
# from datetime import datetime
# import enum

# Base = declarative_base()

# class ProjectStatus(enum.Enum):
#     PENDING = "pending"
#     PROCESSING = "processing"
#     COMPLETED = "completed"
#     FAILED = "failed"

# class SessionStatus(enum.Enum):
#     QUEUED = "queued"
#     PROCESSING = "processing"
#     COMPLETED = "completed"
#     FAILED = "failed"

# class StageStatus(enum.Enum):
#     PENDING = "pending"
#     PROCESSING = "processing"
#     COMPLETED = "completed"
#     FAILED = "failed"

# class StageType(enum.Enum):
#     GLOBAL = "global"
#     LOCAL = "local"

# class AIModel(enum.Enum):
#     MASKRCNN = "maskrcnn"
#     YOLOV8 = "yolov8"
#     ENSEMBLE = "ensemble"

# class ObjectClassType(enum.Enum):
#     STRUCTURAL = "structural"
#     FURNITURE = "furniture"
#     FIXTURE = "fixture"

# class Orientation(enum.Enum):
#     HORIZONTAL = "horizontal"
#     VERTICAL = "vertical"
#     DIAGONAL = "diagonal"

# class LogLevel(enum.Enum):
#     DEBUG = "debug"
#     INFO = "info"
#     WARNING = "warning"
#     ERROR = "error"
#     CRITICAL = "critical"

# class OutputType(enum.Enum):
#     GLB = "glb"
#     OBJ = "obj"
#     FBX = "fbx"
#     BLEND = "blend"

# class Project(Base):
#     __tablename__ = "projects"
    
#     id = Column(Integer, primary_key=True, autoincrement=True)
#     name = Column(String(255), nullable=False)
#     description = Column(Text)
#     original_image_path = Column(String(500))
#     image_dimensions = Column(JSON)  # {width, height, resolution}
#     status = Column(Enum(ProjectStatus), default=ProjectStatus.PENDING)
#     created_at = Column(TIMESTAMP, default=func.current_timestamp())
#     updated_at = Column(TIMESTAMP, default=func.current_timestamp(), onupdate=func.current_timestamp())
#     user_id = Column(Integer)
    
#     # Relationships
#     processing_sessions = relationship("ProcessingSession", back_populates="project", cascade="all, delete-orphan")
    
#     # Indexes
#     __table_args__ = (
#         Index('idx_status', 'status'),
#         Index('idx_created_at', 'created_at'),
#     )

# class ProcessingSession(Base):
#     __tablename__ = "processing_sessions"
    
#     id = Column(Integer, primary_key=True, autoincrement=True)
#     project_id = Column(Integer, ForeignKey('projects.id', ondelete='CASCADE'))
#     session_uuid = Column(String(36), unique=True)
#     ai_model_flags = Column(JSON)  # {maskrcnn: true, yolo: false, both: false}
#     processing_config = Column(JSON)
#     total_stages = Column(Integer, default=4)
#     current_stage = Column(Integer, default=0)
#     status = Column(Enum(SessionStatus), default=SessionStatus.QUEUED)
#     started_at = Column(TIMESTAMP)
#     completed_at = Column(TIMESTAMP)
#     created_at = Column(TIMESTAMP, default=func.current_timestamp())
    
#     # Relationships
#     project = relationship("Project", back_populates="processing_sessions")
#     json_stages = relationship("JSONStage", back_populates="session", cascade="all, delete-orphan")
#     ai_model_results = relationship("AIModelResult", back_populates="session", cascade="all, delete-orphan")
#     object_classes = relationship("ObjectClass", back_populates="session", cascade="all, delete-orphan")
#     debug_logs = relationship("DebugLog", back_populates="session", cascade="all, delete-orphan")
#     model_outputs = relationship("ModelOutput", back_populates="session", cascade="all, delete-orphan")
    
#     # Indexes
#     __table_args__ = (
#         Index('idx_session_uuid', 'session_uuid'),
#         Index('idx_status', 'status'),
#     )

# class JSONStage(Base):
#     __tablename__ = "json_stages"
    
#     id = Column(Integer, primary_key=True, autoincrement=True)
#     session_id = Column(Integer, ForeignKey('processing_sessions.id', ondelete='CASCADE'))
#     stage_number = Column(Integer)  # 1=global, 2-4=local refinements
#     stage_name = Column(String(100))  # 'global_detection', 'geometric_refinement', etc.
#     stage_type = Column(Enum(StageType), default=StageType.LOCAL)
#     input_json = Column(JSON)
#     output_json = Column(JSON)
#     processing_time_ms = Column(Integer)
#     confidence_scores = Column(JSON)
#     error_log = Column(Text)
#     status = Column(Enum(StageStatus), default=StageStatus.PENDING)
#     created_at = Column(TIMESTAMP, default=func.current_timestamp())
    
#     # Relationships
#     session = relationship("ProcessingSession", back_populates="json_stages")
#     object_classes = relationship("ObjectClass", back_populates="stage", cascade="all, delete-orphan")
#     debug_logs = relationship("DebugLog", back_populates="stage", cascade="all, delete-orphan")
    
#     # Indexes
#     __table_args__ = (
#         Index('idx_session_stage', 'session_id', 'stage_number'),
#         Index('idx_stage_type', 'stage_type'),
#     )

# class AIModelResult(Base):
#     __tablename__ = "ai_model_results"
    
#     id = Column(Integer, primary_key=True, autoincrement=True)
#     session_id = Column(Integer, ForeignKey('processing_sessions.id', ondelete='CASCADE'))
#     model_name = Column(Enum(AIModel))
#     raw_output = Column(JSON)
#     processed_output = Column(JSON)
#     confidence_threshold = Column(Float)
#     processing_time_ms = Column(Integer)
#     model_version = Column(String(50))
#     created_at = Column(TIMESTAMP, default=func.current_timestamp())
    
#     # Relationships
#     session = relationship("ProcessingSession", back_populates="ai_model_results")
    
#     # Indexes
#     __table_args__ = (
#         Index('idx_session_model', 'session_id', 'model_name'),
#     )

# class ObjectClass(Base):
#     __tablename__ = "object_classes"
    
#     id = Column(Integer, primary_key=True, autoincrement=True)
#     session_id = Column(Integer, ForeignKey('processing_sessions.id', ondelete='CASCADE'))
#     stage_id = Column(Integer, ForeignKey('json_stages.id', ondelete='CASCADE'))
#     class_name = Column(String(100))  # 'door', 'window', 'wall', 'room', etc.
#     class_type = Column(Enum(ObjectClassType))
#     bounding_box = Column(JSON)  # {x1, y1, x2, y2}
#     center_point = Column(JSON)  # {x, y}
#     orientation = Column(Enum(Orientation))
#     start_point = Column(JSON)  # {x, y}
#     end_point = Column(JSON)  # {x, y}
#     dimensions = Column(JSON)  # {width, height, depth}
#     confidence_score = Column(Float)
#     is_global = Column(Boolean, default=False)
#     parent_class_id = Column(Integer, ForeignKey('object_classes.id', ondelete='SET NULL'))
#     created_at = Column(TIMESTAMP, default=func.current_timestamp())
    
#     # Relationships
#     session = relationship("ProcessingSession", back_populates="object_classes")
#     stage = relationship("JSONStage", back_populates="object_classes")
#     parent_class = relationship("ObjectClass", remote_side=[id])
    
#     # Indexes
#     __table_args__ = (
#         Index('idx_session_class', 'session_id', 'class_name'),
#         Index('idx_confidence', 'confidence_score'),
#     )

# class DebugLog(Base):
#     __tablename__ = "debug_logs"
    
#     id = Column(Integer, primary_key=True, autoincrement=True)
#     session_id = Column(Integer, ForeignKey('processing_sessions.id', ondelete='CASCADE'))
#     stage_id = Column(Integer, ForeignKey('json_stages.id', ondelete='SET NULL'))
#     log_level = Column(Enum(LogLevel))
#     component = Column(String(100))
#     message = Column(Text)
#     stack_trace = Column(Text)
#     log_data = Column(JSON)  # RENAMED from 'metadata' to 'log_data'
#     created_at = Column(TIMESTAMP, default=func.current_timestamp())
    
#     # Relationships
#     session = relationship("ProcessingSession", back_populates="debug_logs")
#     stage = relationship("JSONStage", back_populates="debug_logs")
    
#     # Indexes
#     __table_args__ = (
#         Index('idx_session_level', 'session_id', 'log_level'),
#         Index('idx_created_at', 'created_at'),
#     )

# class ModelOutput(Base):
#     __tablename__ = "model_outputs"
    
#     id = Column(Integer, primary_key=True, autoincrement=True)
#     session_id = Column(Integer, ForeignKey('processing_sessions.id', ondelete='CASCADE'))
#     output_type = Column(Enum(OutputType))
#     file_path = Column(String(500))
#     file_size_mb = Column(DECIMAL(10, 2))
#     generation_time_ms = Column(Integer)
#     blender_version = Column(String(20))
#     export_settings = Column(JSON)
#     quality_metrics = Column(JSON)
#     created_at = Column(TIMESTAMP, default=func.current_timestamp())
    
#     # Relationships
#     session = relationship("ProcessingSession", back_populates="model_outputs")
    
#     # Indexes
#     __table_args__ = (
#         Index('idx_session_type', 'session_id', 'output_type'),
#     )




from sqlalchemy import (
    Column, Integer, String, Text, JSON, Float, Boolean, 
    TIMESTAMP, Enum, ForeignKey, Index, DECIMAL
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from datetime import datetime
import enum

Base = declarative_base()

class ProjectStatus(enum.Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"

class SessionStatus(enum.Enum):
    QUEUED = "queued"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"

class StageStatus(enum.Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"

class StageType(enum.Enum):
    GLOBAL = "global"
    LOCAL = "local"

class AIModel(enum.Enum):
    MASKRCNN = "maskrcnn"
    YOLOV8 = "yolov8"
    ENSEMBLE = "ensemble"

class ObjectClassType(enum.Enum):
    STRUCTURAL = "structural"
    FURNITURE = "furniture"
    FIXTURE = "fixture"

class Orientation(enum.Enum):
    HORIZONTAL = "horizontal"
    VERTICAL = "vertical"
    DIAGONAL = "diagonal"

class LogLevel(enum.Enum):
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"

class OutputType(enum.Enum):
    GLB = "glb"
    OBJ = "obj"
    FBX = "fbx"
    BLEND = "blend"

class ImageFormat(enum.Enum):
    JPEG = "jpeg"
    JPG = "jpg"
    PNG = "png"
    BMP = "bmp"
    TIFF = "tiff"
    WEBP = "webp"

class Project(Base):
    __tablename__ = "projects"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    original_image_path = Column(String(500))
    
    # Enhanced image metadata columns
    image_width = Column(Integer)  # Image width in pixels
    image_height = Column(Integer)  # Image height in pixels
    image_resolution_dpi = Column(Integer)  # DPI resolution
    image_size_bytes = Column(Integer)  # File size in bytes
    image_format = Column(Enum(ImageFormat))  # Image format
    image_color_mode = Column(String(20))  # RGB, RGBA, L, etc.
    image_has_transparency = Column(Boolean, default=False)
    image_aspect_ratio = Column(Float)  # width/height ratio
    
    # Legacy field for backward compatibility (can be deprecated later)
    image_dimensions = Column(JSON)  # {width, height, resolution}
    
    status = Column(Enum(ProjectStatus), default=ProjectStatus.PENDING)
    created_at = Column(TIMESTAMP, default=func.current_timestamp())
    updated_at = Column(TIMESTAMP, default=func.current_timestamp(), onupdate=func.current_timestamp())
    user_id = Column(Integer)
    
    # Relationships
    processing_sessions = relationship("ProcessingSession", back_populates="project", cascade="all, delete-orphan")
    
    # Indexes
    __table_args__ = (
        Index('idx_status', 'status'),
        Index('idx_created_at', 'created_at'),
        Index('idx_image_format', 'image_format'),
        Index('idx_image_size', 'image_width', 'image_height'),
    )

class ProcessingSession(Base):
    __tablename__ = "processing_sessions"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    project_id = Column(Integer, ForeignKey('projects.id', ondelete='CASCADE'))
    session_uuid = Column(String(36), unique=True)
    ai_model_flags = Column(JSON)  # {maskrcnn: true, yolo: false, both: false}
    processing_config = Column(JSON)
    total_stages = Column(Integer, default=4)
    current_stage = Column(Integer, default=0)
    status = Column(Enum(SessionStatus), default=SessionStatus.QUEUED)
    started_at = Column(TIMESTAMP)
    completed_at = Column(TIMESTAMP)
    created_at = Column(TIMESTAMP, default=func.current_timestamp())
    
    # Export metadata
    export_file_path = Column(String(500))  # Path to exported JSON file
    export_file_size_bytes = Column(Integer)  # Size of export file
    export_created_at = Column(TIMESTAMP)  # When export was created
    export_format_version = Column(String(20), default="2.1")  # Export format version
    
    # Relationships
    project = relationship("Project", back_populates="processing_sessions")
    json_stages = relationship("JSONStage", back_populates="session", cascade="all, delete-orphan")
    ai_model_results = relationship("AIModelResult", back_populates="session", cascade="all, delete-orphan")
    object_classes = relationship("ObjectClass", back_populates="session", cascade="all, delete-orphan")
    debug_logs = relationship("DebugLog", back_populates="session", cascade="all, delete-orphan")
    model_outputs = relationship("ModelOutput", back_populates="session", cascade="all, delete-orphan")
    
    # Indexes
    __table_args__ = (
        Index('idx_session_uuid', 'session_uuid'),
        Index('idx_status', 'status'),
        Index('idx_export_created', 'export_created_at'),
    )

class JSONStage(Base):
    __tablename__ = "json_stages"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(Integer, ForeignKey('processing_sessions.id', ondelete='CASCADE'))
    stage_number = Column(Integer)  # 1=global, 2-4=local refinements
    stage_name = Column(String(100))  # 'global_detection', 'geometric_refinement', etc.
    stage_type = Column(Enum(StageType), default=StageType.LOCAL)
    input_json = Column(JSON)
    output_json = Column(JSON)
    processing_time_ms = Column(Integer)
    confidence_scores = Column(JSON)
    error_log = Column(Text)
    status = Column(Enum(StageStatus), default=StageStatus.PENDING)
    created_at = Column(TIMESTAMP, default=func.current_timestamp())
    
    # Relationships
    session = relationship("ProcessingSession", back_populates="json_stages")
    object_classes = relationship("ObjectClass", back_populates="stage", cascade="all, delete-orphan")
    debug_logs = relationship("DebugLog", back_populates="stage", cascade="all, delete-orphan")
    
    # Indexes
    __table_args__ = (
        Index('idx_session_stage', 'session_id', 'stage_number'),
        Index('idx_stage_type', 'stage_type'),
    )

class AIModelResult(Base):
    __tablename__ = "ai_model_results"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(Integer, ForeignKey('processing_sessions.id', ondelete='CASCADE'))
    model_name = Column(Enum(AIModel))
    raw_output = Column(JSON)
    processed_output = Column(JSON)
    confidence_threshold = Column(Float)
    processing_time_ms = Column(Integer)
    model_version = Column(String(50))
    created_at = Column(TIMESTAMP, default=func.current_timestamp())
    
    # Relationships
    session = relationship("ProcessingSession", back_populates="ai_model_results")
    
    # Indexes
    __table_args__ = (
        Index('idx_session_model', 'session_id', 'model_name'),
    )

class ObjectClass(Base):
    __tablename__ = "object_classes"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(Integer, ForeignKey('processing_sessions.id', ondelete='CASCADE'))
    stage_id = Column(Integer, ForeignKey('json_stages.id', ondelete='CASCADE'))
    class_name = Column(String(100))  # 'door', 'window', 'wall', 'room', etc.
    class_type = Column(Enum(ObjectClassType))
    bounding_box = Column(JSON)  # {x1, y1, x2, y2}
    center_point = Column(JSON)  # {x, y}
    orientation = Column(Enum(Orientation))
    start_point = Column(JSON)  # {x, y}
    end_point = Column(JSON)  # {x, y}
    dimensions = Column(JSON)  # {width, height, depth}
    confidence_score = Column(Float)
    is_global = Column(Boolean, default=False)
    parent_class_id = Column(Integer, ForeignKey('object_classes.id', ondelete='SET NULL'))
    created_at = Column(TIMESTAMP, default=func.current_timestamp())
    
    # Relationships
    session = relationship("ProcessingSession", back_populates="object_classes")
    stage = relationship("JSONStage", back_populates="object_classes")
    parent_class = relationship("ObjectClass", remote_side=[id])
    
    # Indexes
    __table_args__ = (
        Index('idx_session_class', 'session_id', 'class_name'),
        Index('idx_confidence', 'confidence_score'),
    )

class DebugLog(Base):
    __tablename__ = "debug_logs"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(Integer, ForeignKey('processing_sessions.id', ondelete='CASCADE'))
    stage_id = Column(Integer, ForeignKey('json_stages.id', ondelete='SET NULL'))
    log_level = Column(Enum(LogLevel))
    component = Column(String(100))
    message = Column(Text)
    stack_trace = Column(Text)
    log_data = Column(JSON)  # RENAMED from 'metadata' to 'log_data'
    created_at = Column(TIMESTAMP, default=func.current_timestamp())
    
    # Relationships
    session = relationship("ProcessingSession", back_populates="debug_logs")
    stage = relationship("JSONStage", back_populates="debug_logs")
    
    # Indexes
    __table_args__ = (
        Index('idx_session_level', 'session_id', 'log_level'),
        Index('idx_created_at', 'created_at'),
    )

class ModelOutput(Base):
    __tablename__ = "model_outputs"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(Integer, ForeignKey('processing_sessions.id', ondelete='CASCADE'))
    output_type = Column(Enum(OutputType))
    file_path = Column(String(500))
    file_size_mb = Column(DECIMAL(10, 2))
    generation_time_ms = Column(Integer)
    blender_version = Column(String(20))
    export_settings = Column(JSON)
    quality_metrics = Column(JSON)
    created_at = Column(TIMESTAMP, default=func.current_timestamp())
    
    # Relationships
    session = relationship("ProcessingSession", back_populates="model_outputs")
    
    # Indexes
    __table_args__ = (
        Index('idx_session_type', 'session_id', 'output_type'),
    )