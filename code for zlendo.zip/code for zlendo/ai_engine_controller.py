import os
import time
import json
import logging
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime
from sqlalchemy.orm import Session

from database_manager import DatabaseManager
from repositories import (
    ProcessingSessionRepository, 
    AIModelResultRepository, 
    DebugLogRepository,
    JSONStageRepository
)
from models import AIModel, SessionStatus, LogLevel, StageStatus
# from maskrcnn_processor import MaskRCNNProcessor
from yolo_processor import YOLOProcessor
from ensemble_processor import EnsembleProcessor
from model_comparator import ModelComparator

logger = logging.getLogger(__name__)

class AIEngineController:
    """Main controller for AI model selection and processing"""
    
    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager
        # self.maskrcnn_processor = MaskRCNNProcessor()
        self.yolo_processor = YOLOProcessor()
        self.ensemble_processor = EnsembleProcessor()
        self.model_comparator = ModelComparator()
        
        # Initialize processors
        self._initialize_processors()
    
    def _initialize_processors(self):
        """Initialize all AI processors"""
        try:
            logger.info("Initializing AI processors...")
            
            # Initialize MaskRCNN if available
            # if self.maskrcnn_processor.is_available():
            #     self.maskrcnn_processor.load_model()
            #     logger.info("MaskRCNN processor initialized successfully")
            # else:
            #     logger.warning("MaskRCNN processor not available")
            
            # Initialize YOLO if available
            if self.yolo_processor.is_available():
                self.yolo_processor.load_model()
                logger.info("YOLO processor initialized successfully")
            else:
                logger.warning("YOLO processor not available")
            
            logger.info("AI Engine Controller initialized successfully")
            
        except Exception as e:
            logger.error(f"Error initializing AI processors: {str(e)}")
            raise
    
    def process_image(self, session_id: int, image_path: str, 
                     ai_model_flags: Dict[str, bool]) -> Dict[str, Any]:
        """
        Process image with selected AI models
        
        Args:
            session_id: Processing session ID
            image_path: Path to input image
            ai_model_flags: Dictionary of model flags (maskrcnn, yolo, ensemble)
            
        Returns:
            Dictionary containing processing results
        """
        start_time = time.time()
        results = {}
        
        with self.db_manager.get_session() as db:
            session_repo = ProcessingSessionRepository(db)
            ai_result_repo = AIModelResultRepository(db)
            debug_repo = DebugLogRepository(db)
            stage_repo = JSONStageRepository(db)
            
            try:
                # Update session status
                session_repo.update_status(session_id, SessionStatus.PROCESSING)
                
                # Log processing start
                # debug_repo.create(
                #     session_id=session_id,
                #     log_level=LogLevel.INFO,
                #     component="AIEngineController",
                #     message=f"Starting image processing with models: {ai_model_flags}",
                #     metadata={"image_path": image_path}
                # )
                debug_repo.create(
                    session_id=session_id,
                    log_level=LogLevel.INFO,
                    component="AIEngineController",
                    message=f"Starting image processing with models: {ai_model_flags}",
                    log_data={"image_path": image_path}
                )

                
                # Process with MaskRCNN if enabled
                # if ai_model_flags.get('maskrcnn', False):
                #     maskrcnn_result = self._process_with_maskrcnn(
                #         session_id, image_path, db
                #     )
                #     results['maskrcnn'] = maskrcnn_result
                
                # Process with YOLO if enabled
                if ai_model_flags.get('yolo', False):
                    yolo_result = self._process_with_yolo(
                        session_id, image_path, db
                    )
                    results['yolo'] = yolo_result
                
                # Process with ensemble if enabled
                if ai_model_flags.get('ensemble', False):
                    ensemble_result = self._process_with_ensemble(
                        session_id, image_path, results, db
                    )
                    results['ensemble'] = ensemble_result
                
                # Compare results if multiple models used
                if len(results) > 1:
                    comparison_result = self._compare_model_results(
                        session_id, results, db
                    )
                    results['comparison'] = comparison_result
                
                # Select best result
                best_result = self._select_best_result(results)
                
                # Create final JSON stage
                final_stage = stage_repo.create(
                    session_id=session_id,
                    stage_number=1,
                    stage_name="global_detection",
                    stage_type="global",
                    input_json={"image_path": image_path}
                )
                
                stage_repo.update_output(
                    stage_id=final_stage.id,
                    output_json=best_result,
                    processing_time_ms=int((time.time() - start_time) * 1000)
                )
                
                # Update session status
                session_repo.update_status(session_id, SessionStatus.COMPLETED)
                
                # Log success
                # debug_repo.create(
                #     session_id=session_id,
                #     log_level=LogLevel.INFO,
                #     component="AIEngineController",
                #     message="Image processing completed successfully",
                #     metadata={
                #         "processing_time_ms": int((time.time() - start_time) * 1000),
                #         "models_used": list(results.keys())
                #     }
                # )
                debug_repo.create(
                    session_id=session_id,
                    log_level=LogLevel.INFO,
                    component="AIEngineController",
                    message="Image processing completed successfully",
                    log_data={
                        "processing_time_ms": int((time.time() - start_time) * 1000),
                        "models_used": list(results.keys())
                    }
                )

                
                return {
                    "success": True,
                    "results": results,
                    "best_result": best_result,
                    "processing_time_ms": int((time.time() - start_time) * 1000)
                }
                
            except Exception as e:
                # Log error
                debug_repo.create(
                    session_id=session_id,
                    log_level=LogLevel.ERROR,
                    component="AIEngineController",
                    message=f"Error processing image: {str(e)}",
                    stack_trace=str(e)
                )
                
                # Update session status
                session_repo.update_status(session_id, SessionStatus.FAILED)
                
                raise
    
    # def _process_with_maskrcnn(self, session_id: int, image_path: str, 
    #                           db: Session) -> Dict[str, Any]:
    #     """Process image with MaskRCNN"""
    #     start_time = time.time()
        
    #     try:
    #         debug_repo = DebugLogRepository(db)
    #         ai_result_repo = AIModelResultRepository(db)
            
    #         debug_repo.create(
    #             session_id=session_id,
    #             log_level=LogLevel.INFO,
    #             component="MaskRCNN",
    #             message="Starting MaskRCNN processing"
    #         )
            
    #         # Process with MaskRCNN
    #         result = self.maskrcnn_processor.process_image(image_path)
            
    #         # Store result in database
    #         ai_result_repo.create(
    #             session_id=session_id,
    #             model_name=AIModel.MASKRCNN,
    #             raw_output=result,
    #             processed_output=result,
    #             processing_time_ms=int((time.time() - start_time) * 1000),
    #             model_version=self.maskrcnn_processor.get_model_version()
    #         )
            
    #         debug_repo.create(
    #             session_id=session_id,
    #             log_level=LogLevel.INFO,
    #             component="MaskRCNN",
    #             message="MaskRCNN processing completed"
    #         )
            
    #         return result
            
    #     except Exception as e:
    #         debug_repo.create(
    #             session_id=session_id,
    #             log_level=LogLevel.ERROR,
    #             component="MaskRCNN",
    #             message=f"MaskRCNN processing failed: {str(e)}"
    #         )
    #         raise
    def _process_with_yolo(self, session_id: int, image_path: str, db):
        if not self.yolo_processor.model_loaded:
            loaded = self.yolo_processor.load_model()
            if not loaded:
                raise RuntimeError("YOLOv8 model could not be loaded")

        logger.info(f"Running YOLOv8 for session {session_id} on image {image_path}")
        return self.yolo_processor.process_image(image_path)

    # def _process_with_yolo(self, session_id: int, image_path: str, 
    #                       db: Session) -> Dict[str, Any]:
    #     """Process image with YOLO"""
    #     start_time = time.time()
        
    #     try:
    #         debug_repo = DebugLogRepository(db)
    #         ai_result_repo = AIModelResultRepository(db)
            
    #         debug_repo.create(
    #             session_id=session_id,
    #             log_level=LogLevel.INFO,
    #             component="YOLO",
    #             message="Starting YOLO processing"
    #         )
            
    #         # Process with YOLO
    #         result = self.yolo_processor.process_image(image_path)
            
    #         # Store result in database
    #         ai_result_repo.create(
    #             session_id=session_id,
    #             model_name=AIModel.YOLOV8,
    #             raw_output=result,
    #             processed_output=result,
    #             processing_time_ms=int((time.time() - start_time) * 1000),
    #             model_version=self.yolo_processor.get_model_version()
    #         )
            
    #         debug_repo.create(
    #             session_id=session_id,
    #             log_level=LogLevel.INFO,
    #             component="YOLO",
    #             message="YOLO processing completed"
    #         )
            
    #         return result
            
    #     except Exception as e:
    #         debug_repo.create(
    #             session_id=session_id,
    #             log_level=LogLevel.ERROR,
    #             component="YOLO",
    #             message=f"YOLO processing failed: {str(e)}"
    #         )
    #         raise
    
    def _process_with_ensemble(self, session_id: int, image_path: str, 
                              results: Dict[str, Any], db: Session) -> Dict[str, Any]:
        """Process image with ensemble method"""
        start_time = time.time()
        
        try:
            debug_repo = DebugLogRepository(db)
            ai_result_repo = AIModelResultRepository(db)
            
            debug_repo.create(
                session_id=session_id,
                log_level=LogLevel.INFO,
                component="Ensemble",
                message="Starting ensemble processing"
            )
            
            # Process with ensemble
            result = self.ensemble_processor.process_results(results)
            
            # Store result in database
            ai_result_repo.create(
                session_id=session_id,
                model_name=AIModel.ENSEMBLE,
                raw_output=result,
                processed_output=result,
                processing_time_ms=int((time.time() - start_time) * 1000),
                model_version=self.ensemble_processor.get_model_version()
            )
            
            debug_repo.create(
                session_id=session_id,
                log_level=LogLevel.INFO,
                component="Ensemble",
                message="Ensemble processing completed"
            )
            
            return result
            
        except Exception as e:
            debug_repo.create(
                session_id=session_id,
                log_level=LogLevel.ERROR,
                component="Ensemble",
                message=f"Ensemble processing failed: {str(e)}"
            )
            raise
    
    def _compare_model_results(self, session_id: int, results: Dict[str, Any], 
                              db: Session) -> Dict[str, Any]:
        """Compare results from multiple models"""
        try:
            debug_repo = DebugLogRepository(db)
            
            debug_repo.create(
                session_id=session_id,
                log_level=LogLevel.INFO,
                component="ModelComparator",
                message="Starting model comparison"
            )
            
            comparison = self.model_comparator.compare_results(results)
            
            debug_repo.create(
                session_id=session_id,
                log_level=LogLevel.INFO,
                component="ModelComparator",
                message="Model comparison completed"
            )
            
            return comparison
            
        except Exception as e:
            debug_repo.create(
                session_id=session_id,
                log_level=LogLevel.ERROR,
                component="ModelComparator",
                message=f"Model comparison failed: {str(e)}"
            )
            raise
    
    def _select_best_result(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Select the best result from available models"""
        # Priority order: ensemble > maskrcnn > yolo
        if 'ensemble' in results:
            return results['ensemble']
        # elif 'maskrcnn' in results:
        #     return results['maskrcnn']
        elif 'yolo' in results:
            return results['yolo']
        else:
            raise ValueError("No valid results found")
    
    def get_available_models(self) -> List[str]:
        """Get list of available AI models"""
        available = []
        
        # if self.maskrcnn_processor.is_available():
        #     available.append('maskrcnn')
        
        if self.yolo_processor.is_available():
            available.append('yolo')
        
        if len(available) > 1:
            available.append('ensemble')
        
        return available
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get information about loaded models"""
        info = {}
        
        # if self.maskrcnn_processor.is_available():
        #     info['maskrcnn'] = {
        #         'version': self.maskrcnn_processor.get_model_version(),
        #         'classes': self.maskrcnn_processor.get_supported_classes(),
        #         'loaded': True
        #     }
        
        if self.yolo_processor.is_available():
            info['yolo'] = {
                'version': self.yolo_processor.get_model_version(),
                'classes': self.yolo_processor.get_supported_classes(),
                'loaded': True
            }
        
        return info