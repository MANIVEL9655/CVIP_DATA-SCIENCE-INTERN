import uuid
import math
import os
import json
import numpy as np
import cv2
import requests
from typing import Dict, Any, List, Tuple, Optional
from dataclasses import dataclass, field
from collections import defaultdict
from shapely.geometry import Polygon, LineString, Point
from shapely.ops import unary_union, polygonize
from shapely.validation import make_valid

@dataclass
class Point:
    x: float
    y: float

    def distance_to(self, other: 'Point') -> float:
        return math.sqrt((self.x - other.x) ** 2 + (self.y - other.y) ** 2)

    def __hash__(self):
        return hash((round(self.x, 2), round(self.y, 2)))

    def __eq__(self, other):
        if not isinstance(other, Point):
            return False
        return abs(self.x - other.x) < 0.01 and abs(self.y - other.y) < 0.01

@dataclass
class BoundingBox:
    x1: float
    y1: float
    x2: float
    y2: float

@dataclass
class DetectedObject:
    id: str
    class_name: str
    class_type: str
    bounding_box: BoundingBox
    center_point: Point
    orientation: str
    start_point: Point
    end_point: Point
    dimensions: Dict[str, float]
    confidence_score: float
    attributes: Dict[str, Any] = field(default_factory=dict)

class WallConstructor:
    def __init__(self, db_manager):
        self.db_manager = db_manager
        self.stage_name = "final_wall_construction"
        self.stage_number = 4
        
        # API endpoint for getting item dimensions
        self.dimensions_api_url = "http://103.16.202.150:4456/assets/"
        self.item_dimensions_cache = {}
        
        # Fixed class mapping for items
        self.class_mapping = {
            "wall": "wall", "door": "Z_door", "window": "Z_window", "bed": "Z_Bed1",
            "table": "Z_Table1", "dining": "Z_Diningset", "sofa": "Z_Sofa1", 
            "sink": "Z_Kitchensink", "bathtub": "Z_Bathtub2", "western_t": "Z_ToiletW",
            "indian_t": "Z_ToiletI", "stove": "Z_Stove", "cabinet": "Z_Cabinets",
            "fridge": "Z_Fridge2", "cupboard": "Z_Cupboard", "flower_pot": "Z_Flowerpot",
            "w_machine": "Z_Washingmachine", "tv": "Z_TV", "ac": "Z_AC", "steps": "Z_Steps",
            "chair": "Z_Chair1", "balcony": "Z_Balcony1"
        }

        # Wall proximity rules for different item types
        self.wall_placement_rules = {
            "Z_Bed1": {"min_wall_distance": 30, "preferred_wall_distance": 50, "can_touch_wall": True},
            "Z_Sofa1": {"min_wall_distance": 20, "preferred_wall_distance": 40, "can_touch_wall": True},
            "Z_TV": {"min_wall_distance": 5, "preferred_wall_distance": 10, "can_touch_wall": True},
            "Z_Fridge2": {"min_wall_distance": 5, "preferred_wall_distance": 15, "can_touch_wall": True},
            "Z_Kitchensink": {"min_wall_distance": 5, "preferred_wall_distance": 10, "can_touch_wall": True},
            "Z_Bathtub2": {"min_wall_distance": 5, "preferred_wall_distance": 15, "can_touch_wall": True},
            "Z_ToiletW": {"min_wall_distance": 10, "preferred_wall_distance": 20, "can_touch_wall": False},
            "Z_ToiletI": {"min_wall_distance": 10, "preferred_wall_distance": 20, "can_touch_wall": False},
            "Z_Cabinets": {"min_wall_distance": 2, "preferred_wall_distance": 5, "can_touch_wall": True},
            "Z_Cupboard": {"min_wall_distance": 2, "preferred_wall_distance": 5, "can_touch_wall": True},
            "Z_Stove": {"min_wall_distance": 10, "preferred_wall_distance": 20, "can_touch_wall": False},
            "Z_Washingmachine": {"min_wall_distance": 10, "preferred_wall_distance": 20, "can_touch_wall": False},
            "Z_AC": {"min_wall_distance": 2, "preferred_wall_distance": 5, "can_touch_wall": True},
            "Z_Table1": {"min_wall_distance": 40, "preferred_wall_distance": 60, "can_touch_wall": False},
            "Z_Diningset": {"min_wall_distance": 50, "preferred_wall_distance": 80, "can_touch_wall": False},
            "Z_Chair1": {"min_wall_distance": 30, "preferred_wall_distance": 40, "can_touch_wall": False},
            "Z_Flowerpot": {"min_wall_distance": 10, "preferred_wall_distance": 20, "can_touch_wall": False}
        }
        
        # Load item dimensions from API
        self._load_item_dimensions()

    
    def _load_item_dimensions(self):
        """Load item dimensions from the secured /assets/ API with authentication."""
        try:
            print("Loading item dimensions from API (secured endpoint)...")

            # 1️⃣ Login to get access token
            login_resp = requests.post(
                "http://103.16.202.150:4456/auth/login",
                data={"username": "Zlendo", "password": "Zlendo@123"},
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=10
            )
            login_resp.raise_for_status()
            login_json = login_resp.json()
            if not isinstance(login_json, dict):
                raise ValueError("Unexpected login response format")
            token = login_json.get("access_token")
            if not token:
                raise ValueError("No access_token returned from login API")
            print("✅ Successfully authenticated, received access token.")

            # 2️⃣ Get API key
            api_key_resp = requests.get(
                "http://103.16.202.150:4456/users/me/api-key",
                headers={"Authorization": f"Bearer {token}"},
                timeout=10
            )
            api_key_resp.raise_for_status()
            api_key_json = api_key_resp.json()

            # Handle possible API key formats
            if isinstance(api_key_json, str):
                api_key = api_key_json.strip()
            elif isinstance(api_key_json, dict):
                api_key = api_key_json.get("api_key") or api_key_json.get("X-API-Key")
            elif isinstance(api_key_json, list) and api_key_json and isinstance(api_key_json[0], dict):
                api_key = api_key_json[0].get("api_key") or api_key_json[0].get("X-API-Key")
            else:
                api_key = None

            if not api_key:
                raise ValueError("Could not find API key in response")
            print("✅ Successfully retrieved API key.")

            # 3️⃣ Fetch assets
            response = requests.get(
                "http://103.16.202.150:4456/assets/",
                headers={"X-API-Key": api_key},
                timeout=10
            )
            response.raise_for_status()
            items_data = response.json()

            if not isinstance(items_data, list):
                raise ValueError(f"Unexpected /assets/ response format: {type(items_data).__name__}")

            # 4️⃣ Parse dimensions
            loaded_count = 0
            for idx, item in enumerate(items_data):
                if not isinstance(item, dict):
                    continue

                name = item.get("3D_asset_name")
                meta = item.get("3D_asset_metadata")
                if not isinstance(meta, dict):
                    continue

                dims_data = meta.get("dimensions")
                if not isinstance(dims_data, dict):
                    continue

                try:
                    width = float(dims_data.get("width", 0))
                    height = float(dims_data.get("height", 0))
                    depth = float(dims_data.get("thickness", 0))
                    if width > 0 and height > 0 and depth > 0:
                        self.item_dimensions_cache[name] = {
                            "width": width,
                            "depth": depth,
                            "height": height
                        }
                        loaded_count += 1
                except (ValueError, TypeError):
                    continue

            print(f"✅ Successfully loaded dimensions for {loaded_count} items.")

        except requests.RequestException as e:
            print(f"❌ Failed to load item dimensions from API: {e}")
            print("Using fallback dimensions")
        except Exception as e:
            print(f"❌ Error processing item dimensions: {e}")
            print("Using fallback dimensions")




    def _get_class_name(self, raw_class_name: str) -> str:
        """Convert raw class name to proper class name"""
        yolo_classes = [
            "Wall", "Door", "Window", "Bed", "Table", "Dining", "Sofa", "Sink", 
            "Bathtub", "Western_T", "Indian_T", "Stove", "Cabinet", "Fridge", 
            "Cupboard", "Flower_Pot", "W_Machine", "TV", "AC", "Steps", "Chair", "Balcony"
        ]
        
        if raw_class_name.startswith("class_"):
            try:
                class_index = int(raw_class_name.split("_")[1])
                if 0 <= class_index < len(yolo_classes):
                    return yolo_classes[class_index]
            except (ValueError, IndexError):
                pass
        
        for class_name in yolo_classes:
            if raw_class_name.lower() == class_name.lower():
                return class_name
        
        return raw_class_name

    def _empty_output(self):
        """Return empty output structure"""
        return {
            "unit": "cm",
            "layers": {
                "layer-1": {
                    "id": "layer-1", "name": "default", "altitude": 0, "order": 0,
                    "visible": True, "opacity": 1, "vertices": {}, "lines": {},
                    "holes": {}, "areas": {}, "items": {},
                    "selected": {"vertices": [], "lines": [], "holes": [], "areas": [], "items": []}
                }
            },
            "grids": {
                "h1": {"id": "h1", "type": "horizontal-streak", 
                       "properties": {"step": 20, "colors": ["#808080", "#ddd", "#ddd", "#ddd", "#ddd"]}},
                "v1": {"id": "v1", "type": "vertical-streak",
                       "properties": {"step": 20, "colors": ["#808080", "#ddd", "#ddd", "#ddd", "#ddd"]}}
            },
            "selectedLayer": "layer-1", "groups": {}, "width": 4000, "height": 4000,
            "meta": {}, "guides": {"horizontal": {}, "vertical": {}, "circular": {}}
        }


    def _extract_opencv_walls(self, detected_objects: List[Dict[str, Any]], image_size=(4000, 4000)) -> List[DetectedObject]:
        """Enhanced wall extraction that properly integrates window segments"""
        
        target_classes = {"Wall", "Window", "Door"}
        
        # Step 1: Separate walls, windows, and doors
        wall_segments = []
        window_segments = []
        door_segments = []
        
        for obj in detected_objects:
            class_name = self._get_class_name(obj.get("class_name", ""))
            if class_name in target_classes:
                start = obj.get("start_point")
                end = obj.get("end_point")
                if start and end:
                    x1, y1 = float(start["x"]), float(start["y"])
                    x2, y2 = float(end["x"]), float(end["y"])
                    if class_name == "Wall":
                        wall_segments.append(("Wall", (x1, y1), (x2, y2)))
                    elif class_name == "Window":
                        window_segments.append(("Window", (x1, y1), (x2, y2)))
                    elif class_name == "Door":
                        door_segments.append(("Door", (x1, y1), (x2, y2)))

        print(f"Found {len(wall_segments)} walls, {len(window_segments)} windows, {len(door_segments)} doors")

        # Step 2: CREATE UNIFIED WALL NETWORK - Include ALL structural elements
        # This is the key fix - treat windows and doors as part of the wall structure
        all_structural_segments = wall_segments + window_segments + door_segments
        
        if not all_structural_segments:
            print("No structural segments found for processing")
            return []

        # Helper functions
        def distance(p1, p2):
            return math.hypot(p1[0] - p2[0], p1[1] - p2[1])

        def snap_to_orthogonal(p1, p2):
            """Snap segment to orthogonal direction"""
            dx = p2[0] - p1[0]
            dy = p2[1] - p1[1]
            
            if abs(dx) < 2 and abs(dy) < 2:
                return p1, p2
                
            angle = math.degrees(math.atan2(dy, dx)) % 360
            
            if angle <= 45 or angle > 315:  # Horizontal (0°)
                avg_y = (p1[1] + p2[1]) / 2
                return (p1[0], avg_y), (p2[0], avg_y)
            elif 45 < angle <= 135:  # Vertical (90°)
                avg_x = (p1[0] + p2[0]) / 2
                return (avg_x, p1[1]), (avg_x, p2[1])
            elif 135 < angle <= 225:  # Horizontal (180°)
                avg_y = (p1[1] + p2[1]) / 2
                return (p1[0], avg_y), (p2[0], avg_y)
            else:  # Vertical (270°)
                avg_x = (p1[0] + p2[0]) / 2
                return (avg_x, p1[1]), (avg_x, p2[1])

        # Step 3: Snap ALL segments to orthogonal (including windows/doors)
        orthogonal_segments = []
        for cls, (x1, y1), (x2, y2) in all_structural_segments:
            snapped_start, snapped_end = snap_to_orthogonal((x1, y1), (x2, y2))
            if distance(snapped_start, snapped_end) > 5:
                orthogonal_segments.append((cls, snapped_start, snapped_end))

        print(f"After orthogonal snapping: {len(orthogonal_segments)} segments")

        # Step 4: Find segments that should be merged into continuous walls
        def segments_are_collinear_and_close(seg1, seg2):
            _, s1, e1 = seg1
            _, s2, e2 = seg2
            
            # Must have same orientation
            is_h1 = abs(e1[1] - s1[1]) < abs(e1[0] - s1[0])
            is_h2 = abs(e2[1] - s2[1]) < abs(e2[0] - s2[0])
            if is_h1 != is_h2:
                return False
            
            if is_h1:  # Both horizontal
                # Check Y alignment
                if max(abs(s1[1] - s2[1]), abs(e1[1] - e2[1]), abs(s1[1] - e2[1]), abs(e1[1] - s2[1])) > 15:
                    return False
                # Check X proximity/overlap
                x1_range = (min(s1[0], e1[0]), max(s1[0], e1[0]))
                x2_range = (min(s2[0], e2[0]), max(s2[0], e2[0]))
                gap = max(0, max(x1_range[0], x2_range[0]) - min(x1_range[1], x2_range[1]))
                return gap <= 100  # Allow larger gaps for window/door integration
            else:  # Both vertical
                # Check X alignment
                if max(abs(s1[0] - s2[0]), abs(e1[0] - e2[0]), abs(s1[0] - e2[0]), abs(e1[0] - s2[0])) > 15:
                    return False
                # Check Y proximity/overlap
                y1_range = (min(s1[1], e1[1]), max(s1[1], e1[1]))
                y2_range = (min(s2[1], e2[1]), max(s2[1], e2[1]))
                gap = max(0, max(y1_range[0], y2_range[0]) - min(y1_range[1], y2_range[1]))
                return gap <= 100
        
        # Step 5: Build connection graph between segments
        from collections import defaultdict
        connections = defaultdict(set)
        
        for i, seg1 in enumerate(orthogonal_segments):
            for j, seg2 in enumerate(orthogonal_segments):
                if i != j and segments_are_collinear_and_close(seg1, seg2):
                    connections[i].add(j)
                    connections[j].add(i)
        
        # Step 6: Find connected components (wall runs)
        visited = set()
        wall_runs = []
        
        for i in range(len(orthogonal_segments)):
            if i in visited:
                continue
            
            # BFS to find all connected segments
            current_run = []
            queue = [i]
            visited.add(i)
            
            while queue:
                current_idx = queue.pop(0)
                current_run.append(current_idx)
                
                for neighbor_idx in connections[current_idx]:
                    if neighbor_idx not in visited:
                        visited.add(neighbor_idx)
                        queue.append(neighbor_idx)
            
            wall_runs.append(current_run)
        
        print(f"Found {len(wall_runs)} connected wall runs")
        
        # Step 7: Convert each wall run into a single merged wall
        def merge_segment_indices(segment_indices):
            """Merge segments by indices into a single wall segment"""
            segments = [orthogonal_segments[i] for i in segment_indices]
            
            if len(segments) == 1:
                return segments[0]
            
            # Collect all points
            all_points = []
            for _, s, e in segments:
                all_points.extend([s, e])
            
            # Determine orientation from first segment
            _, s1, e1 = segments[0]
            is_horizontal = abs(e1[1] - s1[1]) < abs(e1[0] - s1[0])
            
            if is_horizontal:
                # For horizontal walls
                xs = [p[0] for p in all_points]
                ys = [p[1] for p in all_points]
                avg_y = sum(ys) / len(ys)
                min_x, max_x = min(xs), max(xs)
                merged_start = (min_x, avg_y)
                merged_end = (max_x, avg_y)
            else:
                # For vertical walls
                xs = [p[0] for p in all_points]
                ys = [p[1] for p in all_points]
                avg_x = sum(xs) / len(xs)
                min_y, max_y = min(ys), max(ys)
                merged_start = (avg_x, min_y)
                merged_end = (avg_x, max_y)
            
            return ("Wall", merged_start, merged_end)
        
        # Step 8: Normalize coordinates
        all_points = [p for _, s, e in orthogonal_segments for p in (s, e)]
        if not all_points:
            return []
            
        xs, ys = zip(*all_points)
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        
        plan_width = max_x - min_x if max_x > min_x else 100
        plan_height = max_y - min_y if max_y > min_y else 100
        offset_x = (image_size[0] - plan_width) / 2 - min_x
        offset_y = (image_size[1] - plan_height) / 2 - min_y
        
        # Step 9: Create final wall objects
        opencv_walls = []
        for i, run_indices in enumerate(wall_runs):
            merged_segment = merge_segment_indices(run_indices)
            cls, start_point, end_point = merged_segment
            
            # Apply coordinate transformation
            transformed_start = (start_point[0] + offset_x, start_point[1] + offset_y)
            transformed_end = (end_point[0] + offset_x, end_point[1] + offset_y)
            
            # Convert back to original coordinate system for output
            original_start = Point(transformed_start[0] - offset_x, transformed_start[1] - offset_y)
            original_end = Point(transformed_end[0] - offset_x, transformed_end[1] - offset_y)
            
            segment_length = original_start.distance_to(original_end)
            if segment_length < 8:
                continue
                
            wall_obj = DetectedObject(
                id=f"opencv_wall_{i}",
                class_name="wall",
                class_type="structural",
                bounding_box=BoundingBox(
                    x1=min(original_start.x, original_end.x),
                    y1=min(original_start.y, original_end.y),
                    x2=max(original_start.x, original_end.x),
                    y2=max(original_start.y, original_end.y)
                ),
                center_point=Point(
                    x=(original_start.x + original_end.x) / 2,
                    y=(original_start.y + original_end.y) / 2
                ),
                orientation="horizontal" if abs(original_start.y - original_end.y) < abs(original_start.x - original_end.x) else "vertical",
                start_point=original_start,
                end_point=original_end,
                dimensions={"length": segment_length},
                confidence_score=1.0,
                attributes={
                    "source": "opencv_integrated_structure",
                    "original_class": cls,
                    "run_size": len(run_indices),
                    "contains_windows": any(orthogonal_segments[idx][0] == "Window" for idx in run_indices),
                    "contains_doors": any(orthogonal_segments[idx][0] == "Door" for idx in run_indices)
                }
            )
            opencv_walls.append(wall_obj)
        
        windows_integrated = sum(1 for wall in opencv_walls if wall.attributes.get("contains_windows", False))
        doors_integrated = sum(1 for wall in opencv_walls if wall.attributes.get("contains_doors", False))
        
        print(f"Final integrated walls: {len(opencv_walls)} walls")
        print(f"Windows integrated into walls: {windows_integrated}")
        print(f"Doors integrated into walls: {doors_integrated}")
        
        return opencv_walls


    
    def _find_wall_intersections_improved(self, walls, tolerance=30.0):
        intersections = []
        endpoint_tolerance = 40.0  # more forgiving

        for i, wall1 in enumerate(walls):
            for j, wall2 in enumerate(walls[i+1:], i+1):
                p1_start, p1_end = wall1.start_point, wall1.end_point
                p2_start, p2_end = wall2.start_point, wall2.end_point

                # Skip if endpoints are already very close
                endpoint_pairs = [
                    (p1_start, p2_start), (p1_start, p2_end),
                    (p1_end, p2_start), (p1_end, p2_end)
                ]
                min_endpoint_distance = min(p1.distance_to(p2) for p1, p2 in endpoint_pairs)
                if min_endpoint_distance < endpoint_tolerance:
                    continue

                # --- Check if wall1 endpoint touches wall2's body (T-junction) ---
                for endpoint in [p1_start, p1_end]:
                    dist_to_line = self._point_to_line_distance_detailed(endpoint, p2_start, p2_end)
                    if dist_to_line < tolerance:
                        proj_t = self._project_point_on_line(endpoint, p2_start, p2_end)
                        if 0.01 < proj_t < 0.99:  # inside the segment
                            intersection_point = Point(
                                p2_start.x + proj_t * (p2_end.x - p2_start.x),
                                p2_start.y + proj_t * (p2_end.y - p2_start.y)
                            )
                            intersections.append({
                                'point': intersection_point,
                                'wall1_idx': i,
                                'wall2_idx': j,
                                'wall1': wall1,
                                'wall2': wall2,
                                'type': 'T-junction',
                                'split_wall': j
                            })

                # --- Check the opposite (wall2 endpoint to wall1's body) ---
                for endpoint in [p2_start, p2_end]:
                    dist_to_line = self._point_to_line_distance_detailed(endpoint, p1_start, p1_end)
                    if dist_to_line < tolerance:
                        proj_t = self._project_point_on_line(endpoint, p1_start, p1_end)
                        if 0.01 < proj_t < 0.99:
                            intersection_point = Point(
                                p1_start.x + proj_t * (p1_end.x - p1_start.x),
                                p1_start.y + proj_t * (p1_end.y - p1_start.y)
                            )
                            intersections.append({
                                'point': intersection_point,
                                'wall1_idx': i,
                                'wall2_idx': j,
                                'wall1': wall1,
                                'wall2': wall2,
                                'type': 'T-junction',
                                'split_wall': i
                            })

        print(f"Found {len(intersections)} T-junction intersections")
        return intersections



    
    def _merge_nearby_endpoints_opencv(self, walls, threshold=200.0):
        if not walls:
            return []

        # Step 1: Collect endpoints with wall references
        endpoint_info = []
        for wall_idx, wall in enumerate(walls):
            endpoint_info.append({
                'point': wall.start_point,
                'wall_idx': wall_idx,
                'is_start': True
            })
            endpoint_info.append({
                'point': wall.end_point,
                'wall_idx': wall_idx,
                'is_start': False
            })

        # Step 2: Group endpoints by proximity
        groups = []
        used_indices = set()

        for i, info1 in enumerate(endpoint_info):
            if i in used_indices:
                continue

            current_group = [i]
            used_indices.add(i)

            for j, info2 in enumerate(endpoint_info):
                if j in used_indices:
                    continue
                distance = info1['point'].distance_to(info2['point'])
                if distance < threshold:
                    current_group.append(j)
                    used_indices.add(j)

            if len(current_group) > 1:
                groups.append(current_group)

        # Step 3: Copy original walls
        updated_walls = [
            DetectedObject(
                id=w.id,
                class_name=w.class_name,
                class_type=w.class_type,
                bounding_box=w.bounding_box,
                center_point=w.center_point,
                orientation=w.orientation,
                start_point=Point(w.start_point.x, w.start_point.y),
                end_point=Point(w.end_point.x, w.end_point.y),
                dimensions=w.dimensions,
                confidence_score=w.confidence_score,
                attributes=w.attributes
            )
            for w in walls
        ]

        # Step 4: Replace grouped endpoints with centroid
        for group in groups:
            points = [endpoint_info[idx]['point'] for idx in group]
            centroid_x = sum(p.x for p in points) / len(points)
            centroid_y = sum(p.y for p in points) / len(points)
            centroid = Point(centroid_x, centroid_y)

            for idx in group:
                info = endpoint_info[idx]
                wall = updated_walls[info['wall_idx']]
                if info['is_start']:
                    wall.start_point = centroid
                else:
                    wall.end_point = centroid

        # Step 5: Remove walls that are too short
        final_walls = []
        for wall in updated_walls:
            if wall.start_point.distance_to(wall.end_point) > 5.0:  # stricter min length
                wall.bounding_box = BoundingBox(
                    x1=min(wall.start_point.x, wall.end_point.x),
                    y1=min(wall.start_point.y, wall.end_point.y),
                    x2=max(wall.start_point.x, wall.end_point.x),
                    y2=max(wall.start_point.y, wall.end_point.y)
                )
                wall.center_point = Point(
                    x=(wall.start_point.x + wall.end_point.x) / 2,
                    y=(wall.start_point.y + wall.end_point.y) / 2
                )
                final_walls.append(wall)

        print(f"Endpoint merging: {len(walls)} -> {len(final_walls)} walls ({len(groups)} merge groups)")
        return final_walls



    def _create_holes_improved(self, detected_objects, lines, vertices, transform_func):
        """Fixed hole creation that preserves windows and doors"""
        holes = {}

        # Create wall segments mapping with better tolerance
        wall_segments = []
        for line_id, line_data in lines.items():
            line_vertices = line_data["vertices"]
            if len(line_vertices) >= 2:
                start_pos = self._get_vertex_position(line_vertices[0], vertices)
                end_pos = self._get_vertex_position(line_vertices[1], vertices)
                if start_pos and end_pos:
                    wall_segments.append({
                        'line_id': line_id,
                        'start': start_pos,
                        'end': end_pos,
                        'length': math.sqrt((end_pos[0] - start_pos[0])**2 + (end_pos[1] - start_pos[1])**2)
                    })

        # Sort by length (prefer longer walls)
        wall_segments.sort(key=lambda x: x['length'], reverse=True)

        window_count = 0
        door_count = 0

        for obj in detected_objects:
            class_name = self._get_class_name(obj.get("class_name", "")).lower()
            if class_name in ["window", "door"]:
                # Use original center point (before any transformation issues)
                center = obj.get("center_point", {})
                if not center or "x" not in center or "y" not in center:
                    print(f"Skipping {class_name} due to missing center point")
                    continue

                original_center = (float(center["x"]), float(center["y"]))
                
                # Apply coordinate transformation
                transformed_point = transform_func(Point(original_center[0], original_center[1]))
                hole_center = (transformed_point.x, transformed_point.y)

                # Find best wall segment with RELAXED matching criteria
                best_segment = None
                min_distance = float('inf')
                best_offset = 0.5

                for segment in wall_segments:
                    # Use relaxed distance calculation
                    distance = self._point_to_line_distance_with_segment_check(
                        hole_center, segment['start'], segment['end']
                    )
                    
                    # MUCH more tolerant distance threshold
                    if distance < 100:  # Increased from 60
                        offset = self._calculate_hole_position_on_line_improved(
                            segment['start'], segment['end'], hole_center
                        )
                        
                        # More lenient position quality scoring
                        position_quality = 1.0 if 0.05 <= offset <= 0.95 else 0.5
                        wall_length_factor = min(1.0, segment['length'] / 150.0)
                        distance_penalty = distance / 100.0
                        
                        quality_score = (position_quality * 0.3 + 
                                    wall_length_factor * 0.2 + 
                                    (1 - distance_penalty) * 0.5)  # Prioritize closeness
                        
                        adjusted_distance = distance / (1 + quality_score * 0.5)

                        if adjusted_distance < min_distance:
                            min_distance = adjusted_distance
                            best_segment = segment
                            best_offset = offset

                # Much more lenient final acceptance threshold
                if best_segment and min_distance < 120:  # Increased from 80
                    hole_id = uuid.uuid4().hex[:12]
                    line_id = best_segment['line_id']

                    is_window = class_name == "window"
                    hole_type = "Z_window" if is_window else "Z_door"

                    # Use consistent standard dimensions
                    hole_width = 80 if is_window else 90
                    hole_height = 80 if is_window else 210
                    hole_altitude = 90 if is_window else 0

                    # More lenient offset clamping
                    clamped_offset = max(0.05, min(0.95, best_offset))  # Was 0.1 to 0.9

                    holes[hole_id] = {
                        "id": hole_id,
                        "type": hole_type,
                        "prototype": "holes",
                        "name": "Window" if is_window else "Door",
                        "misc": {},
                        "selected": False,
                        "properties": {
                            "width": {"length": hole_width},
                            "height": {"length": hole_height},
                            "thickness": {"length": 20},
                            "altitude": {"length": hole_altitude}
                        },
                        "visible": True,
                        "offset": clamped_offset,
                        "line": line_id
                    }

                    if "holes" not in lines[line_id]:
                        lines[line_id]["holes"] = []
                    lines[line_id]["holes"].append(hole_id)

                    if is_window:
                        window_count += 1
                    else:
                        door_count += 1
                        
                    print(f"Created {hole_type} hole at offset {clamped_offset:.3f} on line {line_id} (distance: {min_distance:.1f})")
                else:
                    print(f"No suitable wall found for {class_name} at {hole_center} (min_distance: {min_distance:.1f})")

        print(f"Total holes created: {window_count} windows, {door_count} doors")
        return holes


    def _straighten_wall_runs(self, walls: List[DetectedObject], angle_tolerance: float = 2.0):
        """
        Enhanced wall straightening that maintains perfect orthogonal geometry
        """
        from collections import defaultdict

        if not walls:
            return walls

        # Create adjacency mapping using rounded coordinates for better grouping
        point_to_walls = defaultdict(list)
        for i, wall in enumerate(walls):
            start_key = (round(wall.start_point.x, 0), round(wall.start_point.y, 0))
            end_key = (round(wall.end_point.x, 0), round(wall.end_point.y, 0))
            point_to_walls[start_key].append(i)
            point_to_walls[end_key].append(i)

        processed_walls = set()
        
        for i, wall in enumerate(walls):
            if i in processed_walls:
                continue

            # Determine wall's cardinal direction
            dx = wall.end_point.x - wall.start_point.x
            dy = wall.end_point.y - wall.start_point.y
            
            if abs(dx) > abs(dy):  # Horizontal
                base_direction = "horizontal"
            else:  # Vertical
                base_direction = "vertical"

            chain = [i]
            processed_walls.add(i)
            queue = [i]

            # Find connected walls with same direction
            while queue:
                current_idx = queue.pop(0)
                current_wall = walls[current_idx]

                for endpoint in [current_wall.start_point, current_wall.end_point]:
                    endpoint_key = (round(endpoint.x, 0), round(endpoint.y, 0))
                    
                    for neighbor_idx in point_to_walls.get(endpoint_key, []):
                        if neighbor_idx in processed_walls:
                            continue
                        
                        neighbor_wall = walls[neighbor_idx]
                        neighbor_dx = neighbor_wall.end_point.x - neighbor_wall.start_point.x
                        neighbor_dy = neighbor_wall.end_point.y - neighbor_wall.start_point.y
                        
                        if abs(neighbor_dx) > abs(neighbor_dy):  # Horizontal
                            neighbor_direction = "horizontal"
                        else:  # Vertical
                            neighbor_direction = "vertical"
                        
                        # Only connect walls with same cardinal direction
                        if neighbor_direction == base_direction:
                            chain.append(neighbor_idx)
                            processed_walls.add(neighbor_idx)
                            queue.append(neighbor_idx)

            # Straighten the chain if it has multiple walls
            if len(chain) > 1:
                chain_walls = [walls[idx] for idx in chain]
                all_points = []
                for w in chain_walls:
                    all_points.extend([w.start_point, w.end_point])

                if base_direction == "horizontal":
                    # For horizontal walls, align all Y coordinates
                    avg_y = sum(p.y for p in all_points) / len(all_points)
                    for w in chain_walls:
                        w.start_point.y = avg_y
                        w.end_point.y = avg_y
                else:  # vertical
                    # For vertical walls, align all X coordinates
                    avg_x = sum(p.x for p in all_points) / len(all_points)
                    for w in chain_walls:
                        w.start_point.x = avg_x
                        w.end_point.x = avg_x

        return walls
    
    

    # def _find_wall_intersections_improved(self, walls, tolerance=15.0):
    #     """Improved intersection detection that better handles T-junctions"""
    #     intersections = []
    #     endpoint_tolerance = 25.0

    #     for i, wall1 in enumerate(walls):
    #         for j, wall2 in enumerate(walls[i+1:], i+1):
    #             p1_start, p1_end = wall1.start_point, wall1.end_point
    #             p2_start, p2_end = wall2.start_point, wall2.end_point

    #             # Check if endpoints are already close
    #             endpoint_pairs = [
    #                 (p1_start, p2_start), (p1_start, p2_end),
    #                 (p1_end, p2_start), (p1_end, p2_end)
    #             ]
    #             endpoints_connected = any(
    #                 p1.distance_to(p2) < endpoint_tolerance for p1, p2 in endpoint_pairs
    #             )
    #             if endpoints_connected:
    #                 continue

    #             # Check for T-junctions
    #             t_junction_found = False
    #             intersection_point = None

    #             # Check if wall1's endpoints touch wall2's middle
    #             for endpoint in [p1_start, p1_end]:
    #                 dist_to_line = self._point_to_line_distance_detailed(endpoint, p2_start, p2_end)
    #                 if dist_to_line < tolerance:
    #                     proj_t = self._project_point_on_line(endpoint, p2_start, p2_end)
    #                     if 0.1 < proj_t < 0.9:
    #                         intersection_point = Point(
    #                             p2_start.x + proj_t * (p2_end.x - p2_start.x),
    #                             p2_start.y + proj_t * (p2_end.y - p2_start.y)
    #                         )
    #                         intersections.append({
    #                             'point': intersection_point, 'wall1_idx': i, 'wall2_idx': j,
    #                             'wall1': wall1, 'wall2': wall2, 'type': 'T-junction', 'split_wall': j
    #                         })
    #                         t_junction_found = True
    #                         break

    #             if t_junction_found:
    #                 continue

    #             # Check if wall2's endpoints touch wall1's middle
    #             for endpoint in [p2_start, p2_end]:
    #                 dist_to_line = self._point_to_line_distance_detailed(endpoint, p1_start, p1_end)
    #                 if dist_to_line < tolerance:
    #                     proj_t = self._project_point_on_line(endpoint, p1_start, p1_end)
    #                     if 0.1 < proj_t < 0.9:
    #                         intersection_point = Point(
    #                             p1_start.x + proj_t * (p1_end.x - p1_start.x),
    #                             p1_start.y + proj_t * (p1_end.y - p1_start.y)
    #                         )
    #                         intersections.append({
    #                             'point': intersection_point, 'wall1_idx': i, 'wall2_idx': j,
    #                             'wall1': wall1, 'wall2': wall2, 'type': 'T-junction', 'split_wall': i
    #                         })
    #                         break

    #     return intersections

    def _point_to_line_distance_detailed(self, point, line_start, line_end):
        """Calculate detailed distance from point to line segment"""
        line_vec = Point(line_end.x - line_start.x, line_end.y - line_start.y)
        line_length = line_start.distance_to(line_end)
        
        if line_length == 0:
            return point.distance_to(line_start)

        point_vec = Point(point.x - line_start.x, point.y - line_start.y)
        dot_product = point_vec.x * line_vec.x + point_vec.y * line_vec.y
        projection_length = dot_product / line_length

        if projection_length < 0:
            return point.distance_to(line_start)
        elif projection_length > line_length:
            return point.distance_to(line_end)
        else:
            proj_point = Point(
                line_start.x + (projection_length / line_length) * line_vec.x,
                line_start.y + (projection_length / line_length) * line_vec.y
            )
            return point.distance_to(proj_point)

    def _project_point_on_line(self, point, line_start, line_end):
        """Project a point onto a line and return parameter t"""
        line_vec_x = line_end.x - line_start.x
        line_vec_y = line_end.y - line_start.y
        point_vec_x = point.x - line_start.x
        point_vec_y = point.y - line_start.y
        
        line_length_sq = line_vec_x * line_vec_x + line_vec_y * line_vec_y
        if line_length_sq == 0:
            return 0
        
        dot_product = point_vec_x * line_vec_x + point_vec_y * line_vec_y
        return dot_product / line_length_sq

    def _split_walls_at_intersections_improved(self, walls, intersections, min_length=5.0, tolerance=2.0):

        if not intersections:
            return walls

        # Step 1: Group intersections by wall to split
        split_points_by_wall = {}
        for inter in intersections:
            wall_idx = inter['split_wall']
            pt = inter['point']

            if wall_idx not in split_points_by_wall:
                split_points_by_wall[wall_idx] = []

            # Avoid adding duplicate points too close to existing ones
            if not any(p.distance_to(pt) < tolerance for p in split_points_by_wall[wall_idx]):
                split_points_by_wall[wall_idx].append(pt)

        # Step 2: Rebuild wall list with splits applied
        new_walls = []
        for idx, wall in enumerate(walls):
            if idx not in split_points_by_wall:
                # No splits, keep wall as-is
                new_walls.append(wall)
                continue

            # Sort split points along the wall’s direction
            sp = split_points_by_wall[idx]
            wall_vec = (wall.end_point.x - wall.start_point.x, wall.end_point.y - wall.start_point.y)
            wall_len = wall.start_point.distance_to(wall.end_point)

            def proj_t(point):
                return ((point.x - wall.start_point.x) * wall_vec[0] +
                        (point.y - wall.start_point.y) * wall_vec[1]) / (wall_len ** 2)

            sorted_points = sorted(sp, key=proj_t)

            # Ensure endpoints are included in the split chain
            chain = [wall.start_point] + sorted_points + [wall.end_point]

            # Step 3: Build new sub-walls from consecutive points
            for k in range(len(chain) - 1):
                p1, p2 = chain[k], chain[k + 1]
                if p1.distance_to(p2) >= min_length:
                    new_wall = DetectedObject(
                        id=str(uuid.uuid4()),
                        class_name=wall.class_name,
                        class_type=wall.class_type,
                        bounding_box=BoundingBox(
                            x1=min(p1.x, p2.x),
                            y1=min(p1.y, p2.y),
                            x2=max(p1.x, p2.x),
                            y2=max(p1.y, p2.y),
                        ),
                        center_point=Point((p1.x + p2.x) / 2, (p1.y + p2.y) / 2),
                        orientation=wall.orientation,
                        start_point=Point(p1.x, p1.y),
                        end_point=Point(p2.x, p2.y),
                        dimensions=wall.dimensions,
                        confidence_score=wall.confidence_score,
                        attributes=wall.attributes,
                    )
                    new_walls.append(new_wall)

        print(f"Wall splitting: {len(walls)} -> {len(new_walls)} walls")
        return new_walls

    def fix_wall_connectivity(self, walls):

        print(f"Starting connectivity fix with {len(walls)} walls")

        # Step 1: Merge nearby endpoints
        merged_walls = self._merge_nearby_endpoints_opencv(walls, threshold=40.0)

        # Step 2: Detect T-junction intersections
        intersections = self._find_wall_intersections_improved(merged_walls, tolerance=30.0)

        # Step 3: Split walls at intersection points
        fixed_walls = self._split_walls_at_intersections_improved(merged_walls, intersections, min_length=5.0)

        print(f"Connectivity fix complete: {len(walls)} → {len(fixed_walls)} walls")
        return fixed_walls

    def _sort_points_along_wall(self, wall, points):
        """Sort points along a wall from start to end"""
        wall_vector_x = wall.end_point.x - wall.start_point.x
        wall_vector_y = wall.end_point.y - wall.start_point.y

        def get_projection_parameter(point):
            point_vector_x = point.x - wall.start_point.x
            point_vector_y = point.y - wall.start_point.y
            wall_length_sq = wall_vector_x * wall_vector_x + wall_vector_y * wall_vector_y
            if wall_length_sq == 0:
                return 0
            dot_product = point_vector_x * wall_vector_x + point_vector_y * wall_vector_y
            return dot_product / wall_length_sq

        return sorted(points, key=get_projection_parameter)

    def _merge_nearby_endpoints_conservative(self, walls, threshold=15.0):
        """Conservative endpoint merging that preserves T-junction integrity"""
        from collections import defaultdict

        points = []
        for wall in walls:
            points.extend([wall.start_point, wall.end_point])
        
        unique_points = list({(round(p.x, 2), round(p.y, 2)): p for p in points}.values())
        if not unique_points:
            return walls

        # Find merge groups
        merge_groups = []
        used_indices = set()

        for i in range(len(unique_points)):
            if i in used_indices:
                continue
            
            current_group = [i]
            used_indices.add(i)

            for j in range(i + 1, len(unique_points)):
                if j in used_indices:
                    continue
                distance = unique_points[i].distance_to(unique_points[j])
                if distance < threshold:
                    current_group.append(j)
                    used_indices.add(j)
            
            merge_groups.append(current_group)

        # Create point mapping
        point_mapping = {}
        for group in merge_groups:
            if len(group) == 1:
                point = unique_points[group[0]]
                key = (round(point.x, 2), round(point.y, 2))
                point_mapping[key] = point
            else:
                group_points = [unique_points[idx] for idx in group]
                avg_x = sum(p.x for p in group_points) / len(group_points)
                avg_y = sum(p.y for p in group_points) / len(group_points)
                centroid = Point(avg_x, avg_y)
                
                for idx in group:
                    point = unique_points[idx]
                    key = (round(point.x, 2), round(point.y, 2))
                    point_mapping[key] = centroid

        # Apply mapping to walls
        updated_walls = []
        for wall in walls:
            start_key = (round(wall.start_point.x, 2), round(wall.start_point.y, 2))
            end_key = (round(wall.end_point.x, 2), round(wall.end_point.y, 2))
            
            new_start = point_mapping.get(start_key, wall.start_point)
            new_end = point_mapping.get(end_key, wall.end_point)

            if new_start.distance_to(new_end) > 2.0:
                updated_wall = DetectedObject(
                    id=wall.id,
                    class_name=wall.class_name,
                    class_type=wall.class_type,
                    bounding_box=BoundingBox(
                        x1=min(new_start.x, new_end.x),
                        y1=min(new_start.y, new_end.y),
                        x2=max(new_start.x, new_end.x),
                        y2=max(new_start.y, new_end.y)
                    ),
                    center_point=Point(
                        x=(new_start.x + new_end.x) / 2,
                        y=(new_start.y + new_end.y) / 2
                    ),
                    orientation=wall.orientation,
                    start_point=new_start,
                    end_point=new_end,
                    dimensions=wall.dimensions,
                    confidence_score=wall.confidence_score,
                    attributes=wall.attributes
                )
                updated_walls.append(updated_wall)

        print(f"Conservative merging: {len(walls)} -> {len(updated_walls)} walls")
        return updated_walls
    
    # def _merge_nearby_endpoints_opencv(self, walls, threshold=15.0):
    #     """
    #     Merge wall endpoints using a proximity-based connected-points approach.
    #     Groups points within 'threshold' distance and replaces them with centroid.
    #     """
    #     if not walls:
    #         return []

    #     # Step 1: Collect endpoints
    #     points = []
    #     for wall in walls:
    #         points.append((wall.start_point.x, wall.start_point.y))
    #         points.append((wall.end_point.x, wall.end_point.y))
    #     points_np = np.array(points, dtype=np.float32)

    #     # Step 2: Build adjacency list for proximity
    #     n_points = len(points_np)
    #     adjacency = [[] for _ in range(n_points)]
    #     for i in range(n_points):
    #         for j in range(i + 1, n_points):
    #             if np.linalg.norm(points_np[i] - points_np[j]) < threshold:
    #                 adjacency[i].append(j)
    #                 adjacency[j].append(i)

    #     # Step 3: Find connected components manually (BFS)
    #     visited = [False] * n_points
    #     labels = [-1] * n_points
    #     label_id = 0

    #     for i in range(n_points):
    #         if not visited[i]:
    #             queue = [i]
    #             visited[i] = True
    #             labels[i] = label_id
    #             while queue:
    #                 node = queue.pop(0)
    #                 for neigh in adjacency[node]:
    #                     if not visited[neigh]:
    #                         visited[neigh] = True
    #                         labels[neigh] = label_id
    #                         queue.append(neigh)
    #             label_id += 1

    #     # Step 4: Compute centroid for each group
    #     group_centroids = {}
    #     for group in range(label_id):
    #         group_points = points_np[np.array(labels) == group]
    #         centroid = np.mean(group_points, axis=0)
    #         group_centroids[group] = Point(float(centroid[0]), float(centroid[1]))

    #     # Step 5: Rebuild walls with merged endpoints
    #     updated_walls = []
    #     for wall in walls:
    #         start_idx = points.index((wall.start_point.x, wall.start_point.y))
    #         end_idx = points.index((wall.end_point.x, wall.end_point.y))
    #         new_start = group_centroids[labels[start_idx]]
    #         new_end = group_centroids[labels[end_idx]]

    #         if new_start.distance_to(new_end) > 2.0:
    #             updated_walls.append(DetectedObject(
    #                 id=wall.id,
    #                 class_name=wall.class_name,
    #                 class_type=wall.class_type,
    #                 bounding_box=BoundingBox(
    #                     x1=min(new_start.x, new_end.x),
    #                     y1=min(new_start.y, new_end.y),
    #                     x2=max(new_start.x, new_end.x),
    #                     y2=max(new_start.y, new_end.y)
    #                 ),
    #                 center_point=Point(
    #                     x=(new_start.x + new_end.x) / 2,
    #                     y=(new_start.y + new_end.y) / 2
    #                 ),
    #                 orientation=wall.orientation,
    #                 start_point=new_start,
    #                 end_point=new_end,
    #                 dimensions=wall.dimensions,
    #                 confidence_score=wall.confidence_score,
    #                 attributes=wall.attributes
    #             ))

    #     print(f"OpenCV-style merging: {len(walls)} -> {len(updated_walls)} walls")
    #     return updated_walls



    def _snap_vertices_to_axis(self, walls, tolerance_deg=5):
        """Snap clusters of connected vertices to horizontal/vertical alignment"""
        from collections import defaultdict
        
        adj = defaultdict(set)
        all_points = []
        
        for wall in walls:
            all_points.append(wall.start_point)
            all_points.append(wall.end_point)
            adj[wall.start_point].add(wall.end_point)
            adj[wall.end_point].add(wall.start_point)

        processed = set()
        for point in all_points:
            if point in processed:
                continue
            
            cluster = [point]
            stack = [point]
            processed.add(point)

            while stack:
                curr = stack.pop()
                for neigh in adj[curr]:
                    if neigh not in processed:
                        processed.add(neigh)
                        cluster.append(neigh)
                        stack.append(neigh)

            if len(cluster) >= 2:
                dx = cluster[-1].x - cluster[0].x
                dy = cluster[-1].y - cluster[0].y
                angle = math.degrees(math.atan2(dy, dx)) % 180
                
                if abs(angle - 0) < tolerance_deg or abs(angle - 180) < tolerance_deg:
                    avg_y = sum(p.y for p in cluster) / len(cluster)
                    for p in cluster:
                        p.y = avg_y
                elif abs(angle - 90) < tolerance_deg:
                    avg_x = sum(p.x for p in cluster) / len(cluster)
                    for p in cluster:
                        p.x = avg_x

    # def _straighten_wall_runs(self, walls, angle_tolerance=5):
    #     """Straighten sequences of collinear walls"""
    #     from collections import defaultdict
        
    #     processed = set()
    #     adj = defaultdict(list)
        
    #     for idx, wall in enumerate(walls):
    #         adj[wall.start_point].append(idx)
    #         adj[wall.end_point].append(idx)

    #     def wall_angle(w):
    #         dx = w.end_point.x - w.start_point.x
    #         dy = w.end_point.y - w.start_point.y
    #         return math.degrees(math.atan2(dy, dx)) % 180

    #     for i, wall in enumerate(walls):
    #         if i in processed:
    #             continue

    #         group_idx = [i]
    #         stack = [i]
    #         base_angle = wall_angle(wall)

    #         while stack:
    #             curr_idx = stack.pop()
    #             if curr_idx in processed:
    #                 continue
    #             processed.add(curr_idx)
    #             curr_wall = walls[curr_idx]

    #             for point in [curr_wall.start_point, curr_wall.end_point]:
    #                 for neigh_idx in adj[point]:
    #                     if neigh_idx not in processed:
    #                         ang = wall_angle(walls[neigh_idx])
    #                         if (abs(ang - base_angle) < angle_tolerance or 
    #                             abs(abs(ang - base_angle) - 180) < angle_tolerance):
    #                             stack.append(neigh_idx)
    #                             group_idx.append(neigh_idx)

    #         if len(group_idx) > 1:
    #             points = []
    #             for idx in group_idx:
    #                 points.extend([walls[idx].start_point, walls[idx].end_point])

    #             xs = [p.x for p in points]
    #             ys = [p.y for p in points]
    #             dx = max(xs) - min(xs)
    #             dy = max(ys) - min(ys)

    #             if dx == 0:
    #                 avg_x = sum(xs) / len(xs)
    #                 for p in points:
    #                     p.x = avg_x
    #             elif dy == 0:
    #                 avg_y = sum(ys) / len(ys)
    #                 for p in points:
    #                     p.y = avg_y
    #             else:
    #                 m, c = np.polyfit(xs, ys, 1)
    #                 for p in points:
    #                     x_proj = (p.x + m * p.y - m * c) / (m**2 + 1)
    #                     y_proj = m * x_proj + c
    #                     p.x = x_proj
    #                     p.y = y_proj

    
    # def _create_holes_improved(self, detected_objects, lines, vertices, transform_func):
    #     """Improved hole creation for windows and doors with better positioning"""
    #     holes = {}

    #     # Create wall segments mapping
    #     wall_segments = []
    #     for line_id, line_data in lines.items():
    #         line_vertices = line_data["vertices"]
    #         if len(line_vertices) >= 2:
    #             start_pos = self._get_vertex_position(line_vertices[0], vertices)
    #             end_pos = self._get_vertex_position(line_vertices[1], vertices)
    #             if start_pos and end_pos:
    #                 wall_segments.append({
    #                     'line_id': line_id,
    #                     'start': start_pos,
    #                     'end': end_pos,
    #                     'length': math.sqrt((end_pos[0] - start_pos[0])**2 + (end_pos[1] - start_pos[1])**2)
    #                 })

    #     # Sort by length (prefer longer walls)
    #     wall_segments.sort(key=lambda x: x['length'], reverse=True)

    #     for obj in detected_objects:
    #         class_name = self._get_class_name(obj.get("class_name", "")).lower()
    #         if class_name in ["window", "door"]:
    #             center = obj.get("center_point", {})
    #             if not center or "x" not in center or "y" not in center:
    #                 continue

    #             original_center = (float(center["x"]), float(center["y"]))
                
    #             # FIX 1: Apply coordinate transformation consistently
    #             transformed_point = transform_func(Point(original_center[0], original_center[1]))
    #             hole_center = (transformed_point.x, transformed_point.y)

    #             # Find best wall segment with improved matching
    #             best_segment = None
    #             min_distance = float('inf')
    #             best_offset = 0.5

    #             for segment in wall_segments:
    #                 # FIX 2: Use the improved distance calculation
    #                 distance = self._point_to_line_distance_with_segment_check(
    #                     hole_center, segment['start'], segment['end']
    #                 )
                    
    #                 # FIX 3: Increase tolerance for wall matching
    #                 if distance < 60:  # Increased from 40
    #                     offset = self._calculate_hole_position_on_line_improved(
    #                         segment['start'], segment['end'], hole_center
    #                     )
                        
    #                     # FIX 4: Better quality scoring for wall selection
    #                     position_quality = min(offset, 1 - offset) if 0.1 <= offset <= 0.9 else 0
    #                     wall_length_factor = min(1.0, segment['length'] / 200.0)
    #                     distance_penalty = distance / 60.0
                        
    #                     quality_score = (position_quality * 0.4 + 
    #                                 wall_length_factor * 0.3 + 
    #                                 (1 - distance_penalty) * 0.3)
                        
    #                     adjusted_distance = distance / (1 + quality_score)

    #                     if adjusted_distance < min_distance:
    #                         min_distance = adjusted_distance
    #                         best_segment = segment
    #                         best_offset = offset

    #             # FIX 5: More lenient distance threshold for final selection
    #             if best_segment and min_distance < 80:  # Increased from 50
    #                 hole_id = uuid.uuid4().hex[:12]
    #                 line_id = best_segment['line_id']

    #                 is_window = class_name == "window"
    #                 hole_type = "Z_window" if is_window else "Z_door"

    #                 dims = obj.get("dimensions", {})
    #                 width = dims.get("width", 80 if is_window else 90)
    #                 height = dims.get("height", 80 if is_window else 210)
    #                 altitude = 90 if is_window else 0

    #                 # FIX 6: Clamp offset to valid range
    #                 clamped_offset = max(0.1, min(0.9, best_offset))

    #                 holes[hole_id] = {
    #                     "id": hole_id,
    #                     "type": hole_type,
    #                     "prototype": "holes",
    #                     "name": "Window" if is_window else "Door",
    #                     "misc": {},
    #                     "selected": False,
    #                     "properties": {
    #                         "width": {"length": width},
    #                         "height": {"length": height},
    #                         "thickness": {"length": 20},
    #                         "altitude": {"length": altitude}
    #                     },
    #                     "visible": True,
    #                     "offset": clamped_offset,  # Use clamped offset
    #                     "line": line_id
    #                 }

    #                 if "holes" not in lines[line_id]:
    #                     lines[line_id]["holes"] = []
    #                 lines[line_id]["holes"].append(hole_id)

    #                 print(f"Created {hole_type} hole at offset {clamped_offset:.3f} on line {line_id} (distance: {min_distance:.1f})")
    #             else:
    #                 print(f"No suitable wall found for {class_name} at {hole_center} (min_distance: {min_distance:.1f})")

    #     return holes

    # In final_validator.py

    # def _create_holes_improved(self, detected_objects, lines, vertices, transform_func):
    #     """
    #     MODIFIED: Hole creation for windows and doors using their refined start/end points
    #     instead of their original center point.
    #     """
    #     holes = {}

    #     # Create wall segments mapping
    #     wall_segments = []
    #     for line_id, line_data in lines.items():
    #         line_vertices = line_data["vertices"]
    #         if len(line_vertices) >= 2:
    #             start_pos = self._get_vertex_position(line_vertices[0], vertices)
    #             end_pos = self._get_vertex_position(line_vertices[1], vertices)
    #             if start_pos and end_pos:
    #                 wall_segments.append({
    #                     'line_id': line_id,
    #                     'start': start_pos,
    #                     'end': end_pos,
    #                     'length': math.sqrt((end_pos[0] - start_pos[0])**2 + (end_pos[1] - start_pos[1])**2)
    #                 })

    #     # Sort by length (prefer longer walls)
    #     wall_segments.sort(key=lambda x: x['length'], reverse=True)

    #     for obj in detected_objects:
    #         class_name = self._get_class_name(obj.get("class_name", "")).lower()
    #         if class_name in ["window", "door"]:
    #             # --- START OF CHANGES ---

    #             # 1. GET REFINED COORDINATES instead of the old center point
    #             start_pt_data = obj.get("start_point", {})
    #             end_pt_data = obj.get("end_point", {})

    #             if not all(k in start_pt_data for k in ['x', 'y']) or not all(k in end_pt_data for k in ['x', 'y']):
    #                 print(f"Skipping {class_name} due to missing refined start/end points.")
    #                 continue
                
    #             original_start = Point(float(start_pt_data["x"]), float(start_pt_data["y"]))
    #             original_end = Point(float(end_pt_data["x"]), float(end_pt_data["y"]))
                
    #             # Apply the same coordinate transformation as walls
    #             transformed_start = transform_func(original_start)
    #             transformed_end = transform_func(original_end)
                
    #             # 2. CALCULATE MIDPOINT from refined coordinates
    #             hole_midpoint = (
    #                 (transformed_start.x + transformed_end.x) / 2,
    #                 (transformed_start.y + transformed_end.y) / 2
    #             )
                
    #             # 3. CALCULATE WIDTH directly from refined coordinates for accuracy
    #             hole_width = math.sqrt(
    #                 (transformed_end.x - transformed_start.x)**2 + (transformed_end.y - transformed_start.y)**2
    #             )

    #             # --- END OF CHANGES ---

    #             # Find best wall segment with improved matching
    #             best_segment = None
    #             min_distance = float('inf')
    #             best_offset = 0.5

    #             for segment in wall_segments:
    #                 # USE THE NEW MIDPOINT to find the closest wall
    #                 distance = self._point_to_line_distance_with_segment_check(
    #                     hole_midpoint, segment['start'], segment['end']
    #                 )
                    
    #                 if distance < 60:
    #                     # USE THE NEW MIDPOINT to calculate the offset
    #                     offset = self._calculate_hole_position_on_line_improved(
    #                         segment['start'], segment['end'], hole_midpoint
    #                     )
                        
    #                     position_quality = min(offset, 1 - offset) if 0.1 <= offset <= 0.9 else 0
    #                     wall_length_factor = min(1.0, segment['length'] / 200.0)
    #                     distance_penalty = distance / 60.0
                        
    #                     quality_score = (position_quality * 0.4 + 
    #                                 wall_length_factor * 0.3 + 
    #                                 (1 - distance_penalty) * 0.3)
                        
    #                     adjusted_distance = distance / (1 + quality_score)

    #                     if adjusted_distance < min_distance:
    #                         min_distance = adjusted_distance
    #                         best_segment = segment
    #                         best_offset = offset

    #             if best_segment and min_distance < 80:
    #                 hole_id = uuid.uuid4().hex[:12]
    #                 line_id = best_segment['line_id']

    #                 is_window = class_name == "window"
    #                 hole_type = "Z_window" if is_window else "Z_door"

    #                 # Get fallback height/altitude, but use the ACCURATE calculated width
    #                 height = 80 if is_window else 210
    #                 altitude = 90 if is_window else 0

    #                 clamped_offset = max(0.1, min(0.9, best_offset))

    #                 holes[hole_id] = {
    #                     "id": hole_id,
    #                     "type": hole_type,
    #                     "prototype": "holes",
    #                     "name": "Window" if is_window else "Door",
    #                     "misc": {},
    #                     "selected": False,
    #                     "properties": {
    #                         # 4. USE THE ACCURATE WIDTH calculated from refined points
    #                         "width": {"length": hole_width},
    #                         "height": {"length": height},
    #                         "thickness": {"length": 20},
    #                         "altitude": {"length": altitude}
    #                     },
    #                     "visible": True,
    #                     "offset": clamped_offset,
    #                     "line": line_id
    #                 }

    #                 if "holes" not in lines[line_id]:
    #                     lines[line_id]["holes"] = []
    #                 lines[line_id]["holes"].append(hole_id)

    #                 print(f"Created {hole_type} hole (width: {hole_width:.1f}) at offset {clamped_offset:.3f} on line {line_id}")
    #             else:
    #                 print(f"No suitable wall found for {class_name} (min_distance: {min_distance:.1f})")

    #     return holes


    # def _create_holes_improved(self, detected_objects, lines, vertices, transform_func):
    #     """
    #     MODIFIED: Hole creation for windows and doors using their refined start/end points
    #     with CONSISTENT STANDARD SIZES instead of variable detected dimensions.
    #     """
    #     holes = {}

    #     # Create wall segments mapping
    #     wall_segments = []
    #     for line_id, line_data in lines.items():
    #         line_vertices = line_data["vertices"]
    #         if len(line_vertices) >= 2:
    #             start_pos = self._get_vertex_position(line_vertices[0], vertices)
    #             end_pos = self._get_vertex_position(line_vertices[1], vertices)
    #             if start_pos and end_pos:
    #                 wall_segments.append({
    #                     'line_id': line_id,
    #                     'start': start_pos,
    #                     'end': end_pos,
    #                     'length': math.sqrt((end_pos[0] - start_pos[0])**2 + (end_pos[1] - start_pos[1])**2)
    #                 })

    #     # Sort by length (prefer longer walls)
    #     wall_segments.sort(key=lambda x: x['length'], reverse=True)

    #     for obj in detected_objects:
    #         class_name = self._get_class_name(obj.get("class_name", "")).lower()
    #         if class_name in ["window", "door"]:
    #             # --- START OF CHANGES ---

    #             # 1. GET REFINED COORDINATES instead of the old center point
    #             start_pt_data = obj.get("start_point", {})
    #             end_pt_data = obj.get("end_point", {})

    #             if not all(k in start_pt_data for k in ['x', 'y']) or not all(k in end_pt_data for k in ['x', 'y']):
    #                 print(f"Skipping {class_name} due to missing refined start/end points.")
    #                 continue
                
    #             original_start = Point(float(start_pt_data["x"]), float(start_pt_data["y"]))
    #             original_end = Point(float(end_pt_data["x"]), float(end_pt_data["y"]))
                
    #             # Apply the same coordinate transformation as walls
    #             transformed_start = transform_func(original_start)
    #             transformed_end = transform_func(original_end)
                
    #             # 2. CALCULATE MIDPOINT from refined coordinates
    #             hole_midpoint = (
    #                 (transformed_start.x + transformed_end.x) / 2,
    #                 (transformed_start.y + transformed_end.y) / 2
    #             )
                
    #             # 3. USE CONSISTENT STANDARD SIZES instead of calculated dimensions
    #             is_window = class_name == "window"
    #             hole_width = 80 if is_window else 70  # Fixed standard sizes for consistency
    #             hole_height = 80 if is_window else 210  # Standard heights
    #             hole_altitude = 90 if is_window else 0   # Standard altitudes

    #             # --- END OF CHANGES ---

    #             # Find best wall segment with improved matching
    #             best_segment = None
    #             min_distance = float('inf')
    #             best_offset = 0.5

    #             for segment in wall_segments:
    #                 # USE THE NEW MIDPOINT to find the closest wall
    #                 distance = self._point_to_line_distance_with_segment_check(
    #                     hole_midpoint, segment['start'], segment['end']
    #                 )
                    
    #                 if distance < 60:
    #                     # USE THE NEW MIDPOINT to calculate the offset
    #                     offset = self._calculate_hole_position_on_line_improved(
    #                         segment['start'], segment['end'], hole_midpoint
    #                     )
                        
    #                     position_quality = min(offset, 1 - offset) if 0.1 <= offset <= 0.9 else 0
    #                     wall_length_factor = min(1.0, segment['length'] / 200.0)
    #                     distance_penalty = distance / 60.0
                        
    #                     quality_score = (position_quality * 0.4 + 
    #                                 wall_length_factor * 0.3 + 
    #                                 (1 - distance_penalty) * 0.3)
                        
    #                     adjusted_distance = distance / (1 + quality_score)

    #                     if adjusted_distance < min_distance:
    #                         min_distance = adjusted_distance
    #                         best_segment = segment
    #                         best_offset = offset

    #             if best_segment and min_distance < 80:
    #                 hole_id = uuid.uuid4().hex[:12]
    #                 line_id = best_segment['line_id']

    #                 hole_type = "Z_window" if is_window else "Z_door"
    #                 clamped_offset = max(0.1, min(0.9, best_offset))

    #                 holes[hole_id] = {
    #                     "id": hole_id,
    #                     "type": hole_type,
    #                     "prototype": "holes",
    #                     "name": "Window" if is_window else "Door",
    #                     "misc": {},
    #                     "selected": False,
    #                     "properties": {
    #                         # Use consistent standard dimensions
    #                         "width": {"length": hole_width},   # Now uses fixed standard width
    #                         "height": {"length": hole_height}, # Fixed standard height
    #                         "thickness": {"length": 20},
    #                         "altitude": {"length": hole_altitude}  # Fixed standard altitude
    #                     },
    #                     "visible": True,
    #                     "offset": clamped_offset,
    #                     "line": line_id
    #                 }

    #                 if "holes" not in lines[line_id]:
    #                     lines[line_id]["holes"] = []
    #                 lines[line_id]["holes"].append(hole_id)

    #                 print(f"Created {hole_type} hole (standard width: {hole_width}) at offset {clamped_offset:.3f} on line {line_id}")
    #             else:
    #                 print(f"No suitable wall found for {class_name} (min_distance: {min_distance:.1f})")

    #     return holes

    def _point_to_line_distance_with_segment_check(self, point, line_start, line_end):
        """Calculate distance from point to line segment with proper segment boundary checking"""
        x0, y0 = point
        x1, y1 = line_start
        x2, y2 = line_end
        
        if x1 == x2 and y1 == y2:
            return math.sqrt((x0 - x1)**2 + (y0 - y1)**2)
        
        # Vector from line start to end
        line_vec_x = x2 - x1
        line_vec_y = y2 - y1
        
        # Vector from line start to point
        point_vec_x = x0 - x1
        point_vec_y = y0 - y1
        
        # Project point onto line
        line_length_sq = line_vec_x * line_vec_x + line_vec_y * line_vec_y
        if line_length_sq == 0:
            return math.sqrt((x0 - x1)**2 + (y0 - y1)**2)
        
        projection_param = (point_vec_x * line_vec_x + point_vec_y * line_vec_y) / line_length_sq
        
        # Clamp to segment boundaries
        projection_param = max(0, min(1, projection_param))
        
        # Find closest point on segment
        closest_x = x1 + projection_param * line_vec_x
        closest_y = y1 + projection_param * line_vec_y
        
        return math.sqrt((x0 - closest_x)**2 + (y0 - closest_y)**2)

    def _calculate_hole_position_on_line_improved(self, line_start, line_end, hole_center):
        """Improved calculation of hole position along a line with boundary checks"""
        line_vec = (line_end[0] - line_start[0], line_end[1] - line_start[1])
        line_length_sq = line_vec[0]**2 + line_vec[1]**2
        
        if line_length_sq == 0:
            return 0.5

        hole_vec = (hole_center[0] - line_start[0], hole_center[1] - line_start[1])
        dot_product = hole_vec[0] * line_vec[0] + hole_vec[1] * line_vec[1]
        
        # Calculate parameter t where projected point lies on line
        t = dot_product / line_length_sq
        
        # Apply stricter boundary conditions to avoid edge placement
        t = max(0.15, min(0.85, t))  # Keep windows away from wall endpoints
        
        return t

    # Additional helper method to improve window detection accuracy
    def _is_window_on_wall_orientation_correct(self, window_obj, wall_start, wall_end):
        """Check if window orientation matches wall orientation"""
        # Get window orientation from start/end points if available
        window_start = window_obj.get("start_point")
        window_end = window_obj.get("end_point")
        
        if not window_start or not window_end:
            return True  # Can't verify, assume correct
        
        # Calculate angles
        wall_dx = wall_end[0] - wall_start[0]
        wall_dy = wall_end[1] - wall_start[1]
        wall_angle = math.degrees(math.atan2(wall_dy, wall_dx)) % 180
        
        window_dx = window_end["x"] - window_start["x"]
        window_dy = window_end["y"] - window_start["y"]
        window_angle = math.degrees(math.atan2(window_dy, window_dx)) % 180
        
        # Check if angles are similar (within 15 degrees)
        angle_diff = abs(wall_angle - window_angle)
        if angle_diff > 90:
            angle_diff = 180 - angle_diff
        
        return angle_diff < 15

    def _get_vertex_position(self, vertex_id, vertices):
        """Get the position of a vertex by its ID"""
        if vertex_id in vertices:
            vertex = vertices[vertex_id]
            return (vertex["x"], vertex["y"])
        return None

    def _point_to_line_distance(self, point, line_start, line_end):
        """Calculate perpendicular distance from point to line"""
        x0, y0 = point
        x1, y1 = line_start
        x2, y2 = line_end
        
        if x1 == x2 and y1 == y2:
            return math.sqrt((x0 - x1)**2 + (y0 - y1)**2)
        
        A = y2 - y1
        B = x1 - x2
        C = x2 * y1 - x1 * y2
        return abs(A * x0 + B * y0 + C) / math.sqrt(A * A + B * B)

    def _calculate_hole_position_on_line(self, line_start, line_end, hole_center):
        """Calculate the position of a hole center along a line (0.0 to 1.0)"""
        line_vec = (line_end[0] - line_start[0], line_end[1] - line_start[1])
        line_length = math.sqrt(line_vec[0]**2 + line_vec[1]**2)
        
        if line_length == 0:
            return 0.5

        hole_vec = (hole_center[0] - line_start[0], hole_center[1] - line_start[1])
        dot_product = hole_vec[0] * line_vec[0] + hole_vec[1] * line_vec[1]
        projection_length = dot_product / line_length
        ratio = projection_length / line_length
        
        return max(0.0, min(1.0, ratio))

    def _create_items_from_detected_objects_enhanced(self, detected_objects, transform_func, wall_lines):
        """Enhanced item creation with proper scaling and placement"""
        items = {}

        # Calculate room-based scale factor
        room_scale_factor = self._calculate_room_based_scale_factor(detected_objects)

        # Convert wall_lines format
        wall_line_format = []
        for wall in wall_lines:
            wall_line_format.append({
                "start": {"x": wall.start_point.x, "y": wall.start_point.y},
                "end": {"x": wall.end_point.x, "y": wall.end_point.y}
            })

        for obj in detected_objects:
            class_name = self._get_class_name(obj.get("class_name", "")).lower()
            
            if class_name in ["wall", "window", "door"]:
                continue

            mapped_class = self.class_mapping.get(class_name)
            if not mapped_class:
                print(f"No mapping found for class: {class_name}")
                continue

            center = obj.get("center_point", {})
            if not center or "x" not in center or "y" not in center:
                continue

            # Transform coordinates
            original_point = Point(float(center["x"]), float(center["y"]))
            transformed_point = transform_func(original_point)

            # Get dimensions and scale them
            api_dims = self._get_item_dimensions(mapped_class)
            detected_dims = obj.get("dimensions", {})
            scaled_dims = self._scale_dimensions_with_aspect_ratio(
                api_dims, room_scale_factor, detected_dims, mapped_class
            )

            # Calculate rotation
            rotation = self._get_smart_item_rotation(obj, transform_func, wall_line_format)

            # Adjust position for wall collisions
            adjusted_position = self._adjust_item_position_for_walls(
                transformed_point, scaled_dims, rotation, mapped_class, wall_line_format
            )

            item_id = uuid.uuid4().hex[:10]
            items[item_id] = {
                "id": item_id,
                "type": mapped_class,
                "prototype": "items",
                "name": f"{mapped_class} (Textured)",
                "misc": {},
                "selected": False,
                "properties": {
                    "width": {"length": scaled_dims["width"]},
                    "height": {"length": scaled_dims["height"]},
                    "depth": {"length": scaled_dims["depth"]},
                    "altitude": {"length": 0}
                },
                "visible": True,
                "x": adjusted_position.x,
                "y": adjusted_position.y,
                "rotation": rotation
            }

            print(f"Created {mapped_class} at ({adjusted_position.x:.1f}, {adjusted_position.y:.1f})")

        return items

    def _calculate_room_based_scale_factor(self, detected_objects, room_type="living"):
        """Calculate scale factor based on room analysis"""
        wall_points = []
        for obj in detected_objects:
            class_name = self._get_class_name(obj.get("class_name", ""))
            if class_name == "Wall":
                start = obj.get("start_point")
                end = obj.get("end_point")
                if start and end:
                    wall_points.extend([(start["x"], start["y"]), (end["x"], end["y"])])

        if not wall_points:
            return 1.0

        xs, ys = zip(*wall_points)
        room_width = max(xs) - min(xs)
        room_height = max(ys) - min(ys)

        typical_room_sizes = {
            "living": {"width": 400, "height": 350},
            "bedroom": {"width": 350, "height": 300},
            "kitchen": {"width": 300, "height": 250},
            "bathroom": {"width": 200, "height": 180}
        }

        detected_room_type = self._determine_room_type(detected_objects)
        typical_size = typical_room_sizes.get(detected_room_type, typical_room_sizes["living"])

        if room_width > 0 and room_height > 0:
            width_scale = typical_size["width"] / room_width
            height_scale = typical_size["height"] / room_height
            scale_factor = (width_scale + height_scale) / 2
            scale_factor = max(0.5, min(5.0, scale_factor))
        else:
            scale_factor = 1.0

        print(f"Calculated scale factor: {scale_factor:.3f}")
        return scale_factor

    def _determine_room_type(self, detected_objects):
        """Determine room type based on detected furniture"""
        item_counts = {}
        for obj in detected_objects:
            class_name = self._get_class_name(obj.get("class_name", "")).lower()
            if class_name not in ["wall", "window", "door"]:
                item_counts[class_name] = item_counts.get(class_name, 0) + 1

        if any(item in item_counts for item in ["bathtub", "western_t", "indian_t"]):
            return "bathroom"
        elif any(item in item_counts for item in ["stove", "sink", "fridge"]):
            return "kitchen"
        elif any(item in item_counts for item in ["bed"]):
            return "bedroom"
        else:
            return "living"

    def _scale_dimensions_with_aspect_ratio(self, api_dims, scale_factor, detected_dims=None, item_type=None):
        """Scale dimensions while maintaining aspect ratio"""
        base_width = api_dims["width"]
        base_height = api_dims["height"]
        base_depth = api_dims["depth"]

        if detected_dims and "width" in detected_dims and "depth" in detected_dims:
            detected_width = detected_dims["width"]
            detected_depth = detected_dims["depth"]
            detected_area = detected_width * detected_depth
            api_area = base_width * base_depth
            if api_area > 0:
                area_scale = math.sqrt(detected_area / api_area)
                adjusted_scale = (scale_factor + area_scale) / 2
            else:
                adjusted_scale = scale_factor
        else:
            adjusted_scale = scale_factor

        # Apply uniform scaling
        scaled_width = base_width * adjusted_scale
        scaled_depth = base_depth * adjusted_scale
        scaled_height = base_height * adjusted_scale

        # Item-specific adjustments
        item_scale_adjustments = {
            "Z_Bed1": 0.8, "Z_Sofa1": 0.85, "Z_Table1": 0.7, "Z_Diningset": 0.75,
            "Z_TV": 1.2, "Z_Flowerpot": 0.6, "Z_Chair1": 0.8,
        }

        if item_type in item_scale_adjustments:
            adjustment = item_scale_adjustments[item_type]
            scaled_width *= adjustment
            scaled_depth *= adjustment
            scaled_height *= adjustment

        # Enforce size limits
        current_scale = scaled_width / base_width if base_width > 0 else 1.0
        min_scale = 20 / max(base_width, base_depth, base_height) if max(base_width, base_depth, base_height) > 0 else 0.2
        max_scale = 400 / max(base_width, base_depth, base_height) if max(base_width, base_depth, base_height) > 0 else 3.0

        clamped_scale = max(min_scale, min(max_scale, current_scale))
        final_width = base_width * clamped_scale
        final_depth = base_depth * clamped_scale
        final_height = base_height * clamped_scale

        return {
            "width": round(final_width, 2),
            "height": round(final_height, 2),
            "depth": round(final_depth, 2)
        }

    def _get_item_dimensions(self, item_name: str) -> Dict[str, float]:
        """Get item dimensions from cache or return defaults"""
        if item_name in self.item_dimensions_cache:
            dims = self.item_dimensions_cache[item_name]
            return {"width": dims["width"], "height": dims["height"], "depth": dims["depth"]}

        # Fallback dimensions
        fallback_dims = {
            "Z_Bed1": {"width": 200, "height": 50, "depth": 160},
            "Z_Table1": {"width": 120, "height": 75, "depth": 80},
            "Z_Diningset": {"width": 150, "height": 75, "depth": 90},
            "Z_Sofa1": {"width": 220, "height": 85, "depth": 90},
            "Z_Kitchensink": {"width": 60, "height": 85, "depth": 50},
            "Z_Bathtub2": {"width": 170, "height": 60, "depth": 75},
            "Z_ToiletW": {"width": 40, "height": 75, "depth": 60},
            "Z_ToiletI": {"width": 35, "height": 20, "depth": 35},
            "Z_Stove": {"width": 60, "height": 85, "depth": 60},
            "Z_Cabinets": {"width": 80, "height": 200, "depth": 40},
            "Z_Fridge2": {"width": 60, "height": 180, "depth": 65},
            "Z_Cupboard": {"width": 120, "height": 200, "depth": 50},
            "Z_Flowerpot": {"width": 30, "height": 40, "depth": 30},
            "Z_Washingmachine": {"width": 60, "height": 85, "depth": 60},
            "Z_TV": {"width": 120, "height": 70, "depth": 15},
            "Z_AC": {"width": 90, "height": 30, "depth": 25},
            "Z_Steps": {"width": 120, "height": 20, "depth": 30},
            "Z_Chair1": {"width": 45, "height": 85, "depth": 50},
            "Z_Balcony1": {"width": 200, "height": 20, "depth": 100}
        }
        return fallback_dims.get(item_name, {"width": 100, "height": 100, "depth": 50})
    
    def _find_closest_wall_orientation(self, point, wall_lines):
        """Find the orientation of the closest wall to a point"""
        min_distance = float('inf')
        closest_wall_angle = 0
        
        for wall in wall_lines:
            # Calculate distance from point to wall line
            wall_start = Point(wall["start"]["x"], wall["start"]["y"])
            wall_end = Point(wall["end"]["x"], wall["end"]["y"])
            
            distance = self._point_to_line_distance_detailed(point, wall_start, wall_end)
            
            if distance < min_distance:
                min_distance = distance
                # Calculate wall angle
                dx = wall_end.x - wall_start.x
                dy = wall_end.y - wall_start.y
                closest_wall_angle = math.degrees(math.atan2(dy, dx)) % 360
        
        return closest_wall_angle
    
    def _get_optimal_table_rotation(self, point, wall_lines):
        """Determine optimal table rotation based on room shape"""
        # Tables are typically oriented to maximize space utilization
        # For now, keep them aligned with room orientation
        if wall_lines:
            # Find the dominant wall orientation
            angles = []
            for wall in wall_lines:
                wall_start = Point(wall["start"]["x"], wall["start"]["y"])
                wall_end = Point(wall["end"]["x"], wall["end"]["y"])
                dx = wall_end.x - wall_start.x
                dy = wall_end.y - wall_start.y
                angle = math.degrees(math.atan2(dy, dx)) % 180  # 0-180 range
                angles.append(angle)
            
            # Find most common angle (dominant orientation)
            angle_counts = {}
            for angle in angles:
                # Group similar angles
                angle_group = round(angle / 45) * 45
                angle_counts[angle_group] = angle_counts.get(angle_group, 0) + 1
            
            if angle_counts:
                dominant_angle = max(angle_counts.keys(), key=lambda x: angle_counts[x])
                return dominant_angle
        
        return 0
    
    def _get_detected_orientation(self, obj):
        """Extract detected orientation from object data"""
        # Method 1: Direct orientation
        if "orientation" in obj:
            orientation = obj.get("orientation", "horizontal")
            return 90 if orientation == "vertical" else 0
        
        # Method 2: From bounding box
        bbox = obj.get("bounding_box", {})
        if bbox and all(k in bbox for k in ["x1", "y1", "x2", "y2"]):
            width = abs(bbox["x2"] - bbox["x1"])
            height = abs(bbox["y2"] - bbox["y1"])
            if height > width * 1.3:  # Clearly vertical
                return 90
            elif width > height * 1.3:  # Clearly horizontal
                return 0
        
        # Method 3: From start/end points
        start = obj.get("start_point")
        end = obj.get("end_point")
        if start and end:
            dx = end["x"] - start["x"]
            dy = end["y"] - start["y"]
            angle = math.degrees(math.atan2(dy, dx)) % 360
            return angle
        
        return None
    
    def _get_optimal_bed_rotation(self, point, wall_lines, closest_wall_angle):
        """Determine optimal bed rotation based on room layout"""
        # Beds are typically placed with the head against a wall
        # and the long side parallel to the wall
        return closest_wall_angle

    
    def _get_optimal_bathroom_fixture_rotation(self, fixture_type, point, wall_lines):
        """Determine optimal rotation for bathroom fixtures"""
        closest_wall_angle = self._find_closest_wall_orientation(point, wall_lines)
        
        if fixture_type == "Z_Bathtub2":
            # Bathtubs are typically placed along the longest wall
            return closest_wall_angle
        elif fixture_type in ["Z_ToiletW", "Z_ToiletI"]:
            # Toilets face away from walls typically
            return (closest_wall_angle + 180) % 360
        
        return closest_wall_angle

    def _get_smart_item_rotation(self, obj, transform_func, wall_lines):
        """Calculate intelligent item rotation based on room layout and wall proximity"""
        class_name = self._get_class_name(obj.get("class_name", "")).lower()
        mapped_class = self.class_mapping.get(class_name)
        
        if not mapped_class:
            return 0
        
        center = obj.get("center_point", {})
        if not center or "x" not in center or "y" not in center:
            return 0
        
        # Transform coordinates
        original_point = Point(float(center["x"]), float(center["y"]))
        transformed_point = transform_func(original_point)
        
        # Find the closest wall and its orientation
        closest_wall_angle = self._find_closest_wall_orientation(transformed_point, wall_lines)
        
        # Get object's detected orientation if available
        detected_orientation = self._get_detected_orientation(obj)
        
        # Smart rotation logic based on item type and wall proximity
        base_rotation = 0
        
        # Wall-mounted or wall-adjacent items
        if mapped_class in ["Z_TV", "Z_AC", "Z_Cabinets", "Z_Cupboard"]:
            # Orient parallel to the closest wall
            base_rotation = closest_wall_angle
            
        # Furniture that should face away from walls
        elif mapped_class in ["Z_Sofa1", "Z_Chair1"]:
            # Orient perpendicular to closest wall (facing into room)
            base_rotation = (closest_wall_angle + 90) % 360
            
        # Beds - typically placed parallel to walls
        elif mapped_class == "Z_Bed1":
            # Check room layout to determine best bed orientation
            base_rotation = self._get_optimal_bed_rotation(transformed_point, wall_lines, closest_wall_angle)
            
        # Tables and dining sets - center of room items
        elif mapped_class in ["Z_Table1", "Z_Diningset"]:
            # Orient based on room shape and available space
            base_rotation = self._get_optimal_table_rotation(transformed_point, wall_lines)
            
        # Appliances - typically against walls
        elif mapped_class in ["Z_Fridge2", "Z_Washingmachine", "Z_Stove"]:
            base_rotation = closest_wall_angle
            
        # Bathroom fixtures
        elif mapped_class in ["Z_ToiletW", "Z_ToiletI", "Z_Bathtub2"]:
            base_rotation = self._get_optimal_bathroom_fixture_rotation(mapped_class, transformed_point, wall_lines)
            
        # Use detected orientation if available and makes sense
        if detected_orientation is not None:
            # Blend detected orientation with smart rotation
            orientation_weight = 0.7  # Favor detected orientation
            smart_weight = 0.3
            
            # Convert orientations to vectors and blend
            detected_rad = math.radians(detected_orientation)
            smart_rad = math.radians(base_rotation)
            
            # Weighted vector average
            avg_x = orientation_weight * math.cos(detected_rad) + smart_weight * math.cos(smart_rad)
            avg_y = orientation_weight * math.sin(detected_rad) + smart_weight * math.sin(smart_rad)
            
            blended_rotation = math.degrees(math.atan2(avg_y, avg_x)) % 360
            base_rotation = blended_rotation
        
        # Normalize to common angles (0, 90, 180, 270)
        normalized_rotation = round(base_rotation / 90) * 90
        
        return normalized_rotation % 360

    def _adjust_item_position_for_walls(self, item_center, item_dims, rotation, mapped_class, wall_lines, placed_items_data):
        """
        Adjust item position to avoid wall and *other item* collisions.
        
        Args:
            item_center (Point): Initial center of the item.
            item_dims (dict): Dimensions of the item {"width", "height", "depth"}.
            rotation (float): Rotation of the item in degrees.
            mapped_class (str): The mapped class name of the item.
            wall_lines (list): List of wall line segments (e.g., [{"start": Point, "end": Point}]).
            placed_items_data (list): List of dictionaries for already placed items,
                                    each containing 'center', 'dims', 'rotation'.
        Returns:
            Point: The adjusted center point of the item.
        """
        placement_rules = self.wall_placement_rules.get(
            mapped_class, 
            {"min_wall_distance": 20, "preferred_wall_distance": 40, "can_touch_wall": False}
        )
        
        min_wall_distance_threshold = placement_rules["min_wall_distance"]
        can_touch_wall = placement_rules["can_touch_wall"]

        def check_all_collisions(center, dims, rot):
            # Check wall collisions
            wall_collision_detected, current_min_wall_dist = self._check_wall_collision(
                center, dims, rot, wall_lines
            )
            
            # Determine if wall collision is "acceptable" based on can_touch_wall
            is_wall_collision_unacceptable = wall_collision_detected or (not can_touch_wall and current_min_wall_dist < min_wall_distance_threshold)

            # Check item-to-item collisions
            item_collision_detected = self._check_item_to_item_collision(center, dims, rot, placed_items_data)

            return is_wall_collision_unacceptable or item_collision_detected, current_min_wall_dist, item_collision_detected

        # Initial check
        collision_detected, current_min_wall_distance, _ = check_all_collisions(item_center, item_dims, rotation)

        if not collision_detected: # If no collision initially, just return
            return item_center

        best_position = item_center
        best_overall_score = -1 # A higher score means better placement (less collision, better distance)

        # Define a range of movement to try
        search_radius = 200 # Max distance to try moving an item, adjust as needed
        step_size = 20 # How far to move in each step

        # Prioritize moving outward
        for dist_multiplier in range(0, int(search_radius / step_size) + 1):
            for dx_unit in [-1, 0, 1]:
                for dy_unit in [-1, 0, 1]:
                    if dx_unit == 0 and dy_unit == 0 and dist_multiplier > 0: continue # Skip no movement after initial check

                    current_move_distance = dist_multiplier * step_size
                    new_center = Point(
                        item_center.x + dx_unit * current_move_distance,
                        item_center.y + dy_unit * current_move_distance
                    )

                    all_collides, min_wall_dist, item_collides = check_all_collisions(new_center, item_dims, rotation)

                    # Score this position: Prioritize no collisions, then wall distance
                    current_score = 0
                    if not all_collides:
                        current_score += 1000 # Large bonus for no collisions
                        if not item_collides:
                            current_score += 500 # Extra bonus for no item collision
                        current_score += min(min_wall_dist, placement_rules["preferred_wall_distance"]) # Add wall distance, capped
                    
                    # If this position is better, update best
                    if current_score > best_overall_score:
                        best_overall_score = current_score
                        best_position = new_center
                    
                    # If we found a perfect spot (no collisions, preferred wall distance met), we can stop early
                    if not all_collides and min_wall_dist >= placement_rules["preferred_wall_distance"]:
                        return best_position
                        
        # If no perfect spot found, return the best non-colliding (or least colliding) one found
        return best_position

    def _check_wall_collision(self, item_center, item_dims, rotation, wall_lines):
        """Check if an item collides with walls"""
        half_width = item_dims["width"] / 2
        half_depth = item_dims["depth"] / 2

        if rotation == 90 or rotation == 270:
            half_width, half_depth = half_depth, half_width

        min_distance_to_wall = float('inf')
        collision_detected = False

        for wall in wall_lines:
            wall_start = Point(wall["start"]["x"], wall["start"]["y"])
            wall_end = Point(wall["end"]["x"], wall["end"]["y"])
            
            distance = self._point_to_line_distance_detailed(item_center, wall_start, wall_end)
            min_distance_to_wall = min(min_distance_to_wall, distance)

            if distance < max(half_width, half_depth):
                collision_detected = True

        return collision_detected, min_distance_to_wall
    
    def _straighten_walls_to_axis(self, walls, angle_tolerance=15):
        """Straighten walls to nearest horizontal or vertical orientation"""
        for wall in walls:
            dx = wall.end_point.x - wall.start_point.x
            dy = wall.end_point.y - wall.start_point.y
            
            if abs(dx) < 0.1 and abs(dy) < 0.1:  # Skip zero-length walls
                continue
                
            angle = math.degrees(math.atan2(dy, dx)) % 180  # Normalize to 0-180
            
            # Determine if wall is closer to horizontal or vertical
            if angle < angle_tolerance or angle > 180 - angle_tolerance:
                # Make perfectly horizontal (0 or 180 degrees)
                avg_y = (wall.start_point.y + wall.end_point.y) / 2
                wall.start_point.y = avg_y
                wall.end_point.y = avg_y
            elif abs(angle - 90) < angle_tolerance:
                # Make perfectly vertical (90 degrees)
                avg_x = (wall.start_point.x + wall.end_point.x) / 2
                wall.start_point.x = avg_x
                wall.end_point.x = avg_x

            
    def _straighten_wall_bends(self, walls, angle_tolerance=5):
        """Straighten small bends so connected walls become perfectly aligned."""
        from collections import defaultdict
        adj = defaultdict(list)
        for idx, wall in enumerate(walls):
            adj[wall.start_point].append(idx)
            adj[wall.end_point].append(idx)

        def wall_angle(w):
            dx = w.end_point.x - w.start_point.x
            dy = w.end_point.y - w.start_point.y
            return math.degrees(math.atan2(dy, dx)) % 180

        for point, connected_idxs in adj.items():
            if len(connected_idxs) == 2:
                w1, w2 = walls[connected_idxs[0]], walls[connected_idxs[1]]
                ang1, ang2 = wall_angle(w1), wall_angle(w2)
                if abs(ang1 - ang2) <= angle_tolerance or abs(abs(ang1 - ang2) - 180) <= angle_tolerance:
                    # Align both walls to the average angle
                    avg_angle = (ang1 + ang2) / 2
                    # Horizontal
                    if abs(avg_angle - 0) < angle_tolerance or abs(avg_angle - 180) < angle_tolerance:
                        avg_y = (w1.start_point.y + w1.end_point.y + w2.start_point.y + w2.end_point.y) / 4
                        for w in (w1, w2):
                            w.start_point.y = avg_y
                            w.end_point.y = avg_y
                    # Vertical
                    elif abs(avg_angle - 90) < angle_tolerance:
                        avg_x = (w1.start_point.x + w1.end_point.x + w2.start_point.x + w2.end_point.x) / 4
                        for w in (w1, w2):
                            w.start_point.x = avg_x
                            w.end_point.x = avg_x

    

    def _remove_unused_vertices(vertices, lines, areas):
        used_ids = set()
        for line in lines.values():
            used_ids.update(line["vertices"])
        for area in areas.values():
            used_ids.update(area["vertices"])
        return {vid: v for vid, v in vertices.items() if vid in used_ids}

 

    
    # Add this method to your WallConstructor class

    def _remove_unnecessary_vertices(self, vertices, lines, areas):
        """Remove vertices that are not essential connection points"""
        
        # Step 1: Count how many lines each vertex connects to
        vertex_line_count = {}
        for vertex_id in vertices:
            vertex_line_count[vertex_id] = 0
        
        # Count line connections
        for line_id, line_data in lines.items():
            line_vertices = line_data.get("vertices", [])
            for vertex_id in line_vertices:
                if vertex_id in vertex_line_count:
                    vertex_line_count[vertex_id] += 1
        
        # Step 2: Keep only ESSENTIAL vertices:
        # - Wall endpoints and intersections (used by lines)
        # - Do NOT automatically keep all area vertices
        
        essential_vertices = set()
        
        # Keep only vertices that are actually used by walls/lines
        for vertex_id, line_count in vertex_line_count.items():
            if line_count >= 1:  # Wall endpoints and intersections
                essential_vertices.add(vertex_id)
        
        print(f"Essential wall vertices: {len(essential_vertices)}")
        
        # Step 3: For areas, create simplified boundaries using only wall vertices
        simplified_areas = {}
        
        for area_id, area_data in areas.items():
            area_vertices = area_data.get("vertices", [])
            
            # Filter area vertices to only include those that are essential (wall-related)
            essential_area_vertices = []
            for vertex_id in area_vertices:
                if vertex_id in essential_vertices:
                    essential_area_vertices.append(vertex_id)
            
            # Only keep areas that have at least 3 essential vertices
            if len(essential_area_vertices) >= 3:
                # Further simplify: remove vertices that are too close together
                simplified_vertices = []
                for i, v_id in enumerate(essential_area_vertices):
                    if v_id not in vertices:
                        continue
                        
                    # Check distance to previous vertex
                    if simplified_vertices:
                        prev_v_id = simplified_vertices[-1]
                        if prev_v_id in vertices:
                            curr_v = vertices[v_id]
                            prev_v = vertices[prev_v_id]
                            distance = math.sqrt(
                                (curr_v["x"] - prev_v["x"])**2 + 
                                (curr_v["y"] - prev_v["y"])**2
                            )
                            # Skip if too close to previous vertex
                            if distance < 30:  # 30 pixel threshold
                                continue
                    
                    simplified_vertices.append(v_id)
                
                # Keep the area only if it has enough vertices after simplification
                if len(simplified_vertices) >= 3:
                    simplified_areas[area_id] = {
                        **area_data,
                        "vertices": simplified_vertices
                    }
                    print(f"Room {area_data.get('name', area_id)}: {len(area_vertices)} -> {len(simplified_vertices)} vertices")
                else:
                    print(f"Removed room {area_data.get('name', area_id)} - insufficient vertices after simplification")
            else:
                print(f"Removed room {area_data.get('name', area_id)} - insufficient essential vertices")
        
        # Step 4: Update essential vertices to include those used in simplified areas
        final_vertices_to_keep = essential_vertices.copy()
        for area_data in simplified_areas.values():
            for vertex_id in area_data["vertices"]:
                final_vertices_to_keep.add(vertex_id)
        
        # Step 5: Clean up vertices and update references
        cleaned_vertices = {vid: vertices[vid] for vid in final_vertices_to_keep if vid in vertices}
        
        # Update area references in vertices
        for vertex_id in cleaned_vertices:
            cleaned_vertices[vertex_id]["areas"] = []
        
        for area_id, area_data in simplified_areas.items():
            for vertex_id in area_data["vertices"]:
                if vertex_id in cleaned_vertices:
                    cleaned_vertices[vertex_id]["areas"].append(area_id)
        
        print(f"Final vertex cleanup: {len(vertices)} -> {len(cleaned_vertices)} vertices")
        print(f"Kept {len(simplified_areas)} rooms out of {len(areas)} original rooms")
        
        return cleaned_vertices, simplified_areas

    def _create_minimal_room_vertices(self, contours, canvas_width, canvas_height, vertex_map, vertices, min_area_px=2000):
        """Create very minimal vertices for room areas - only use existing wall vertices where possible"""
        areas = {}
        room_counter = 1
        
        for cnt in contours:
            xs, ys = cnt[:, 0, 0], cnt[:, 0, 1]
            
            # Skip boundary-touching contours
            if (min(xs) <= 5 or min(ys) <= 5 or 
                max(xs) >= canvas_width - 5 or max(ys) >= canvas_height - 5):
                continue
                
            # Skip small areas
            if cv2.contourArea(cnt) < min_area_px:
                continue
            
            # AGGRESSIVE simplification: Use much larger epsilon to get minimal vertices
            epsilon = 0.08 * cv2.arcLength(cnt, True)  # 8% of perimeter (was 2%)
            simplified_contour = cv2.approxPolyDP(cnt, epsilon, True)
            
            # If still too many points, increase epsilon further
            if len(simplified_contour) > 8:  # Maximum 8 vertices per room
                epsilon = 0.15 * cv2.arcLength(cnt, True)  # 15% of perimeter
                simplified_contour = cv2.approxPolyDP(cnt, epsilon, True)
            
            # Try to use existing wall vertices instead of creating new ones
            v_ids = []
            for point in simplified_contour.reshape(-1, 2):
                px, py = float(point[0]), float(point[1])
                
                # Try to snap to existing vertices with larger tolerance
                found_existing = False
                best_distance = float('inf')
                best_vertex_id = None
                
                for existing_pos, existing_id in vertex_map.items():
                    distance = math.sqrt((existing_pos[0] - px)**2 + (existing_pos[1] - py)**2)
                    if distance < 25 and distance < best_distance:  # 25 pixel tolerance
                        best_distance = distance
                        best_vertex_id = existing_id
                        found_existing = True
                
                if found_existing and best_vertex_id:
                    if best_vertex_id not in v_ids:  # Avoid duplicates
                        v_ids.append(best_vertex_id)
                else:
                    # Only create new vertex if absolutely necessary and far from existing ones
                    min_distance_to_existing = float('inf')
                    for existing_pos in vertex_map.keys():
                        dist = math.sqrt((existing_pos[0] - px)**2 + (existing_pos[1] - py)**2)
                        min_distance_to_existing = min(min_distance_to_existing, dist)
                    
                    # Only create if reasonably far from existing vertices
                    if min_distance_to_existing > 40:  # 40 pixel minimum distance
                        key = (round(px, 2), round(py, 2))
                        if key not in vertex_map:
                            v_id = uuid.uuid4().hex[:12]
                            vertex_map[key] = v_id
                            vertices[v_id] = {
                                "id": v_id, "type": "", "prototype": "vertices", "name": "Vertex",
                                "x": px, "y": py,
                                "lines": [], "areas": [], "visible": True,
                                "misc": {}, "properties": {}, "selected": False
                            }
                            v_ids.append(v_id)
            
            # Remove consecutive duplicate vertices
            unique_v_ids = []
            for v_id in v_ids:
                if not unique_v_ids or v_id != unique_v_ids[-1]:
                    unique_v_ids.append(v_id)
            
            # Remove the last vertex if it's the same as the first (closed polygon)
            if len(unique_v_ids) > 3 and unique_v_ids[0] == unique_v_ids[-1]:
                unique_v_ids = unique_v_ids[:-1]
            
            # Only create area if we have minimal but sufficient vertices
            if 3 <= len(unique_v_ids) <= 12:  # Very conservative vertex count
                area_id = uuid.uuid4().hex[:12]
                areas[area_id] = {
                    "id": area_id, "type": "area", "prototype": "areas",
                    "name": f"Room {room_counter}", "vertices": unique_v_ids, "holes": [],
                    "misc": {}, "selected": False, "visible": True, "properties": {}
                }
                
                print(f"Created Room {room_counter} with {len(unique_v_ids)} vertices")
                room_counter += 1
            else:
                print(f"Skipped room with {len(unique_v_ids)} vertices (outside 3-12 range)")
        
        return areas
    

    
    def _setup_scene_transformation(self, walls: List[DetectedObject], scale_factor: float = 1.5, canvas_size: Tuple[int, int] = (6000, 6000)):
        """
        Sets up the coordinate transformation from raw coordinates to a scaled and centered canvas.
        (FINAL CORRECTED VERSION - Accounts for renderer with bottom-left origin)

        Args:
            walls: A list of DetectedObject walls representing the floor plan.
            scale_factor: The factor by which to enlarge the plan.
            canvas_size: The desired (width, height) of the final canvas.

        Returns:
            A tuple containing:
            - A transformation function (Point -> Point).
            - The final canvas width.
            - The final canvas height.
        """
        canvas_width, canvas_height = canvas_size
        
        if not walls:
            def center_transform(p: Point) -> Point:
                return Point(x=canvas_width / 2, y=canvas_height / 2)
            return center_transform, canvas_width, canvas_height

        all_points = [w.start_point for w in walls] + [w.end_point for w in walls]
        min_x = min(p.x for p in all_points)
        max_x = max(p.x for p in all_points)
        min_y = min(p.y for p in all_points)
        max_y = max(p.y for p in all_points)

        plan_width = max_x - min_x
        plan_height = max_y - min_y
        
        # Handle cases where the plan has no width or height
        if plan_width < 1: plan_width = 1
        if plan_height < 1: plan_height = 1

        # Calculate the dimensions of the plan after scaling
        scaled_plan_width = plan_width * scale_factor
        scaled_plan_height = plan_height * scale_factor
        
        # Calculate the margin needed on each side to center the scaled plan
        margin_x = (canvas_width - scaled_plan_width) / 2
        margin_y = (canvas_height - scaled_plan_height) / 2

        def transform(p: Point) -> Point:
            # 1. Calculate the point's relative position (0.0 to 1.0) inside the original plan.
            # The input coordinates have (0,0) at the top-left.
            relative_x = (p.x - min_x)
            relative_y = (p.y - min_y)

            # 2. Scale the relative position.
            scaled_relative_x = relative_x * scale_factor
            scaled_relative_y = relative_y * scale_factor

            # 3. Calculate final coordinates for a canvas with (0,0) at the BOTTOM-LEFT.
            # For X: Start with the left margin and add the scaled relative X.
            final_x = margin_x + scaled_relative_x

            # For Y: Start at the top of the centered box and subtract the scaled relative Y.
            # The top of the box is at `canvas_height - margin_y`.
            # We subtract because the input Y grows downwards, but the output Y grows upwards.
            final_y = (canvas_height - margin_y) - scaled_relative_y
            
            return Point(x=float(final_x), y=float(final_y))

        return transform, canvas_width, canvas_height

    def _calculate_overlap_ratio(self, obj1_center, obj1_dims, obj2_center, obj2_dims):
        """Calculate overlap ratio between two rectangular objects"""
        # Convert centers and dimensions to bounding boxes
        obj1_half_w, obj1_half_h = obj1_dims.get("width", 50) / 2, obj1_dims.get("height", 50) / 2
        obj2_half_w, obj2_half_h = obj2_dims.get("width", 50) / 2, obj2_dims.get("height", 50) / 2
        
        obj1_x1 = obj1_center["x"] - obj1_half_w
        obj1_y1 = obj1_center["y"] - obj1_half_h
        obj1_x2 = obj1_center["x"] + obj1_half_w
        obj1_y2 = obj1_center["y"] + obj1_half_h
        
        obj2_x1 = obj2_center["x"] - obj2_half_w
        obj2_y1 = obj2_center["y"] - obj2_half_h
        obj2_x2 = obj2_center["x"] + obj2_half_w
        obj2_y2 = obj2_center["y"] + obj2_half_h
        
        # Calculate intersection
        intersect_x1 = max(obj1_x1, obj2_x1)
        intersect_y1 = max(obj1_y1, obj2_y1)
        intersect_x2 = min(obj1_x2, obj2_x2)
        intersect_y2 = min(obj1_y2, obj2_y2)
        
        if intersect_x1 >= intersect_x2 or intersect_y1 >= intersect_y2:
            return 0.0
        
        intersect_area = (intersect_x2 - intersect_x1) * (intersect_y2 - intersect_y1)
        obj1_area = (obj1_x2 - obj1_x1) * (obj1_y2 - obj1_y1)
        obj2_area = (obj2_x2 - obj2_x1) * (obj2_y2 - obj2_y1)
        
        # Return ratio of intersection to smaller object
        smaller_area = min(obj1_area, obj2_area)
        return intersect_area / smaller_area if smaller_area > 0 else 0.0

    def _deduplicate_holes_and_items(self, detected_objects, overlap_threshold=0.5):
        """Remove duplicate holes and items based on confidence scores"""
        target_classes = {"window", "door", "bed", "table", "dining", "sofa", "sink", 
                        "bathtub", "western_t", "indian_t", "stove", "cabinet", "fridge", 
                        "cupboard", "flower_pot", "w_machine", "tv", "ac", "steps", 
                        "chair", "balcony"}
        
        # Filter objects that need deduplication
        candidates = []
        other_objects = []
        
        for obj in detected_objects:
            class_name = self._get_class_name(obj.get("class_name", "")).lower()
            if class_name in target_classes:
                candidates.append(obj)
            else:
                other_objects.append(obj)
        
        if len(candidates) <= 1:
            return detected_objects
        
        # Group overlapping objects
        to_remove = set()
        
        for i, obj1 in enumerate(candidates):
            if i in to_remove:
                continue
                
            center1 = obj1.get("center_point", {})
            dims1 = obj1.get("dimensions", {})
            class1 = self._get_class_name(obj1.get("class_name", "")).lower()
            conf1 = obj1.get("confidence_score", 0.5)
            
            if not center1 or "x" not in center1 or "y" not in center1:
                continue
            
            for j, obj2 in enumerate(candidates[i+1:], i+1):
                if j in to_remove:
                    continue
                    
                center2 = obj2.get("center_point", {})
                dims2 = obj2.get("dimensions", {})
                class2 = self._get_class_name(obj2.get("class_name", "")).lower()
                conf2 = obj2.get("confidence_score", 0.5)
                
                if not center2 or "x" not in center2 or "y" not in center2:
                    continue
                
                # Check if objects overlap significantly
                overlap_ratio = self._calculate_overlap_ratio(center1, dims1, center2, dims2)
                
                if overlap_ratio > overlap_threshold:
                    # Decide which one to keep
                    if conf1 > conf2:
                        to_remove.add(j)
                        print(f"Removed duplicate {class2} (conf: {conf2:.2f}) in favor of {class1} (conf: {conf1:.2f})")
                    elif conf2 > conf1:
                        to_remove.add(i)
                        print(f"Removed duplicate {class1} (conf: {conf1:.2f}) in favor of {class2} (conf: {conf2:.2f})")
                        break  # Don't process more comparisons for obj1 since it's removed
                    else:
                        # Same confidence, prefer certain classes or remove the second one
                        priority_classes = ["door", "window", "bed", "sofa", "table"]
                        if class1 in priority_classes and class2 not in priority_classes:
                            to_remove.add(j)
                        elif class2 in priority_classes and class1 not in priority_classes:
                            to_remove.add(i)
                            break
                        else:
                            # Remove the second one (obj2)
                            to_remove.add(j)
                            print(f"Removed duplicate {class2} (same confidence as {class1})")
        
        # Build final list without removed objects
        deduplicated_candidates = [obj for i, obj in enumerate(candidates) if i not in to_remove]
        
        print(f"Deduplication: {len(candidates)} -> {len(deduplicated_candidates)} objects (removed {len(to_remove)})")
        
        return other_objects + deduplicated_candidates
    

    # PASTE THESE TWO FUNCTIONS INSIDE THE WallConstructor CLASS in final_validator.py

    def _snap_walls_to_axis(self, walls: List[DetectedObject], angle_tolerance: float = 5.0):
        """
        A crucial first pass to force walls that are nearly horizontal or vertical
        to be perfectly on-axis. This simplifies all subsequent calculations.
        """
        for wall in walls:
            dx = wall.end_point.x - wall.start_point.x
            dy = wall.end_point.y - wall.start_point.y
            if abs(dx) < 1e-6 and abs(dy) < 1e-6: continue

            angle = abs(math.degrees(math.atan2(dy, dx)) % 180)

            # Check if it's close to horizontal (0 or 180 degrees)
            if angle < angle_tolerance or abs(angle - 180) < angle_tolerance:
                avg_y = (wall.start_point.y + wall.end_point.y) / 2
                wall.start_point.y = avg_y
                wall.end_point.y = avg_y
            # Check if it's close to vertical (90 degrees)
            elif abs(angle - 90) < angle_tolerance:
                avg_x = (wall.start_point.x + wall.end_point.x) / 2
                wall.start_point.x = avg_x
                wall.end_point.x = avg_x
        return walls


    def _is_plan_mostly_orthogonal(self, walls: List[DetectedObject], angle_threshold_deg: float = 10.0, ratio_threshold: float = 0.85) -> bool:
        """
        Analyzes all walls to determine if the plan is primarily orthogonal.
        Returns True if the ratio of near-orthogonal walls exceeds the threshold.
        """
        if not walls:
            return False

        orthogonal_wall_count = 0
        for wall in walls:
            dx = wall.end_point.x - wall.start_point.x
            dy = wall.end_point.y - wall.start_point.y
            if abs(dx) < 1e-6 and abs(dy) < 1e-6: continue

            angle = abs(math.degrees(math.atan2(dy, dx)) % 180)

            # Check if angle is close to 0/180 (horizontal) or 90 (vertical)
            is_orthogonal = (angle < angle_threshold_deg or 
                             abs(angle - 180) < angle_threshold_deg or 
                             abs(angle - 90) < angle_threshold_deg)
            
            if is_orthogonal:
                orthogonal_wall_count += 1
        
        ratio = orthogonal_wall_count / len(walls)
        
        if ratio >= ratio_threshold:
            print(f"Plan is mostly orthogonal (Ratio: {ratio:.2f}). Applying axis snapping.")
            return True
        else:
            print(f"Plan contains significant diagonal walls (Ratio: {ratio:.2f}). Skipping axis snapping.")
            return False


    # REPLACE the entire process_stage_final method in final_validator.py with this one

    def process_stage_final(self, session_id: int, input_json: Dict[str, Any]) -> Dict[str, Any]:
        """
        FINAL CORRECTED VERSION: Conditionally applies both snapping AND straightening
        to correctly handle both orthogonal and diagonal plans.
        """
        print(f"Stage 4 started for session {session_id} - Robust Geometry Processing")

        # --- Step 1: Load and Pre-process Objects ---
        if isinstance(input_json, dict) and "detected_objects" in input_json:
            raw_objects = input_json["detected_objects"]
        else:
            raw_objects = []

        raw_objects = self._deduplicate_holes_and_items(raw_objects, overlap_threshold=0.3)
        walls = self._extract_opencv_walls(raw_objects)

        if not walls:
            print("No walls extracted, returning empty output.")
            return self._empty_output()

        # --- Step 2: The Correct, Robust Order of Operations for Geometry Cleaning ---
        print(f"Initial wall count: {len(walls)}")

        # Analyze the overall plan layout to decide if we should apply orthogonal corrections.
        is_orthogonal_plan = self._is_plan_mostly_orthogonal(walls)

        # 2a. Find and Split T-Junctions (This is safe for all plan types)
        intersections = self._find_wall_intersections_improved(walls)
        if intersections:
            walls = self._split_walls_at_intersections_improved(walls, intersections)
        print(f"Step 2a (T-Junctions) complete. Wall count: {len(walls)}")

        # 2b. Merge Endpoints (This is safe for all plan types and crucial for closing gaps)
        walls = self._merge_nearby_endpoints_opencv(walls, threshold=25.0)
        print(f"Step 2b (Merge Endpoints) complete. Wall count: {len(walls)}")

        # --- Conditional Orthogonal Cleaning Block ---
        if is_orthogonal_plan:
            print("--- Running Orthogonal Cleaning Pipeline ---")
            # 2c. Snap to Axis: Force slightly angled walls to be perfectly horizontal/vertical.
            walls = self._snap_walls_to_axis(walls, angle_tolerance=5.0)
            print("Step 2c (Snap to Axis) complete.")

            # 2d. Straighten Runs: Fix any "bends" in long walls.
            walls = self._straighten_wall_runs(walls)
            print("Step 2d (Straighten Runs) complete.")
            
            # 2e. Final Axis Snap: A final pass for perfection.
            walls = self._snap_walls_to_axis(walls, angle_tolerance=2.0)
            print("Step 2e (Final Snap) complete.")
        else:
            print("--- Skipping Orthogonal Cleaning for Diagonal Plan ---")


        if not walls:
            print("All walls were removed during cleaning, returning empty output.")
            return self._empty_output()

        # --- Step 3: Transformations and Canvas Setup ---
        transform_for_renderer, canvas_width, canvas_height = self._setup_scene_transformation(
            walls, scale_factor=2.0, canvas_size=(4000, 4000)
        )

        # --- Step 4: Create Final Scene Elements ---
        vertex_map, vertices, lines = {}, {}, {}
        for wall in walls:
            tp_start, tp_end = transform_for_renderer(wall.start_point), transform_for_renderer(wall.end_point)
            key_start, key_end = (round(tp_start.x, 2), round(tp_start.y, 2)), (round(tp_end.x, 2), round(tp_end.y, 2))

            if key_start not in vertex_map:
                v_id = uuid.uuid4().hex[:12]; vertex_map[key_start] = v_id
                vertices[v_id] = {"id": v_id, "x": tp_start.x, "y": tp_start.y, "lines": [], "areas": []}
            start_id = vertex_map[key_start]

            if key_end not in vertex_map:
                v_id = uuid.uuid4().hex[:12]; vertex_map[key_end] = v_id
                vertices[v_id] = {"id": v_id, "x": tp_end.x, "y": tp_end.y, "lines": [], "areas": []}
            end_id = vertex_map[key_end]

            if start_id != end_id:
                line_id = uuid.uuid4().hex[:12]
                lines[line_id] = {"id": line_id, "type": "wall", "prototype": "lines", "properties": {"height": {"length": 300.0}, "thickness": {"length": 20.0}, "textureA": "bricks", "textureB": "bricks"}, "vertices": [start_id, end_id], "holes": []}
                vertices[start_id]["lines"].append(line_id)
                vertices[end_id]["lines"].append(line_id)

        holes = self._create_holes_improved(raw_objects, lines, vertices, transform_for_renderer)
        items = self._create_items_from_detected_objects_enhanced(raw_objects, transform_for_renderer, walls)

        # --- Step 5: Room Detection ---
        print("Running SHAPELY-BASED room detection...")
        areas = self._detect_rooms_shapely_based(vertices, lines, canvas_width, canvas_height, session_id, items)
        
        # --- Step 6: Final Assembly ---
        output_json = self._empty_output()
        layer1 = output_json["layers"]["layer-1"]
        layer1.update({
            "vertices": vertices, "lines": lines, "holes": holes,
            "areas": areas, "items": items
        })
        output_json.update({"width": canvas_width, "height": canvas_height})

        print(f"Generated {len(vertices)} vertices, {len(lines)} walls, {len(holes)} holes, {len(items)} items, {len(areas)} rooms")
        return output_json

    
    def _detect_rooms_shapely_based(self, vertices, lines, canvas_width, canvas_height, session_id, items):
        """
        Simple Shapely room detection — keep all polygons without validation filtering.
        """
        from shapely.geometry import Polygon, LineString
        from shapely.ops import unary_union, polygonize
        import math
        import uuid

        areas = {}

        # Create LineString objects from walls
        wall_lines = []
        vertex_coords = {v_id: (v['x'], v['y']) for v_id, v in vertices.items()}

        for line in lines.values():
            v1_id, v2_id = line['vertices'][0], line['vertices'][1]
            coord1, coord2 = vertex_coords[v1_id], vertex_coords[v2_id]

            # Skip very short lines
            if math.hypot(coord2[0] - coord1[0], coord2[1] - coord1[1]) > 10:
                wall_lines.append(LineString([coord1, coord2]))

        if not wall_lines:
            return areas

        print(f"Created {len(wall_lines)} wall line segments for Shapely analysis")

        try:
            # Polygonize directly without validation
            line_collection = unary_union(wall_lines)
            polygons = list(polygonize(wall_lines))

            print(f"Shapely found {len(polygons)} initial polygons")

            room_counter = 1
            for poly in polygons:
                try:
                    exterior_coords = list(poly.exterior.coords)[:-1]  # remove duplicate last point
                    if len(exterior_coords) < 3:
                        continue

                    room_vertex_ids = []
                    for coord in exterior_coords:
                        closest_vertex_id = None
                        min_distance = float('inf')
                        for v_id, v_coord in vertex_coords.items():
                            distance = math.hypot(coord[0] - v_coord[0], coord[1] - v_coord[1])
                            if distance < min_distance:
                                min_distance = distance
                                closest_vertex_id = v_id
                        if closest_vertex_id and min_distance < 100:
                            if closest_vertex_id not in room_vertex_ids:
                                room_vertex_ids.append(closest_vertex_id)

                    if len(room_vertex_ids) >= 3:
                        area_id = uuid.uuid4().hex[:12]
                        shape_type = self._classify_room_shape(poly, exterior_coords)
                        room_name = self._classify_room_by_fixtures(room_vertex_ids, vertex_coords, items) or f"Room {room_counter}"

                        areas[area_id] = {
                            "id": area_id,
                            "type": "area",
                            "prototype": "areas",
                            "name": room_name,
                            "vertices": room_vertex_ids,
                            "holes": [],
                            "misc": {
                                "shape_type": shape_type,
                                "area_sqm": round(poly.area / 10000, 2)
                            },
                            "selected": False,
                            "visible": True,
                            "properties": {
                                "texture": "none",
                                "patternColor": "#cccccc"
                            }
                        }
                        room_counter += 1

                except Exception as e:
                    print(f"Error processing polygon: {e}")
                    continue

        except Exception as e:
            print(f"Error in Shapely polygonization: {e}")
            return areas

        print(f"Successfully created {len(areas)} rooms using Shapely")
        return areas


    def _classify_room_shape(self, polygon, coords):
        """Classify the shape of a room (rectangle, square, L-shape, T-shape, etc.)."""
        try:
            # Simplify polygon to reduce noise
            simplified = polygon.simplify(tolerance=20, preserve_topology=True)
            simplified_coords = list(simplified.exterior.coords)[:-1]
            num_vertices = len(simplified_coords)
            
            if num_vertices == 4:
                # Check if it's rectangular
                bounds = polygon.bounds
                width = bounds[2] - bounds[0]
                height = bounds[3] - bounds[1]
                
                # Check if it's close to the bounding rectangle area
                rect_area = width * height
                actual_area = polygon.area
                area_ratio = actual_area / rect_area if rect_area > 0 else 0
                
                if area_ratio > 0.85:  # Close to rectangular
                    aspect_ratio = max(width, height) / min(width, height) if min(width, height) > 0 else 1
                    if 0.8 <= aspect_ratio <= 1.25:
                        return "Square"
                    else:
                        return "Rectangle"
                else:
                    return "Quadrilateral"
            
            elif 5 <= num_vertices <= 8:
                # Check for L-shape or T-shape by analyzing concavity
                if self._is_concave_polygon(simplified_coords):
                    # Simple heuristic: if polygon has significant concavity, classify as L or T
                    convex_hull_area = polygon.convex_hull.area
                    concavity_ratio = (convex_hull_area - polygon.area) / convex_hull_area if convex_hull_area > 0 else 0
                    
                    if concavity_ratio > 0.2:
                        if num_vertices <= 6:
                            return "L-Shape"
                        else:
                            return "T-Shape"
                    else:
                        return f"{num_vertices}-sided"
                else:
                    return f"{num_vertices}-sided"
            
            else:
                return f"{num_vertices}-sided"
                
        except:
            return "Irregular"

    def _is_concave_polygon(self, coords):
        """Check if polygon is concave by examining cross products."""
        if len(coords) < 4:
            return False
        
        def cross_product(o, a, b):
            return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
        
        sign = None
        n = len(coords)
        
        for i in range(n):
            o = coords[i]
            a = coords[(i + 1) % n]
            b = coords[(i + 2) % n]
            
            cp = cross_product(o, a, b)
            if abs(cp) > 1:  # Ignore very small cross products
                if sign is None:
                    sign = cp > 0
                elif (cp > 0) != sign:
                    return True  # Concave
        
        return False  # Convex

    def _classify_room_by_fixtures(self, room_vertices, vertex_coords, items):
        """Classify room type based on fixtures/items inside."""
        # This is a placeholder for fixture-based room classification
        # You can enhance this by checking what items/fixtures are inside each room
        return None

