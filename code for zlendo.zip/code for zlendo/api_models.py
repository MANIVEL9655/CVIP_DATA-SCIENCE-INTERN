# api_models.py

import logging
import os
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from typing import List, Dict, Any

from database_manager import get_db, db_manager
from repositories import ProcessingSessionRepository, JSONStageRepository, ModelOutputRepository
from blender_integration import BlenderIntegration, BlenderConfig, ModelGenerationRequest, ExportSettings, OutputFormat

logger = logging.getLogger(__name__)
router = APIRouter()

# Blender Configuration
blender_config = BlenderConfig(
    blender_path=os.getenv("BLENDER_PATH", "/usr/bin/blender"),
    python_path=os.getenv("PYTHON_PATH", "/usr/bin/python"),
    scripts_path="./blender_scripts",
    output_path="./output/models",
    temp_path="./temp"
)
blender_service = BlenderIntegration(config=blender_config, db_manager=db_manager)

@router.post("/sessions/{session_id}/generate-3d", response_model=Dict[str, Any])
async def generate_3d_model_from_session(session_id: int, db: Session = Depends(get_db)):
    """Generate a 3D model (GLB) from the final validated JSON of a session."""
    session = ProcessingSessionRepository(db).get_by_id(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    if session.status.value != "completed":
        raise HTTPException(
            status_code=400, 
            detail=f"Session status is '{session.status.value}', must be 'completed' to generate a model."
        )

    final_stage = JSONStageRepository(db).get_by_session_and_stage(session_id, 4)
    if not final_stage or not final_stage.output_json:
        raise HTTPException(status_code=404, detail="Final validated JSON (Stage 4) not found for this session.")

    try:
        export_settings = ExportSettings(format=OutputFormat.GLB)
        request = ModelGenerationRequest(
            session_id=session_id,
            input_json=final_stage.output_json,
            export_settings=export_settings,
            output_formats=[OutputFormat.GLB]
        )
        result = await blender_service.generate_3d_model(request)
        return result
    except Exception as e:
        logger.error(f"Failed to generate 3D model for session {session_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"3D model generation failed: {e}")


# @router.post("/sessions/{session_id}/generate-3d", response_model=Dict[str, Any])
# async def generate_3d_model_from_session(session_id: int, db: Session = Depends(get_db)):
#     """
#     Generate a 3D model (GLB) from the final validated JSON of a session.
#     """
#     session = ProcessingSessionRepository(db).get_by_id(session_id)
#     if not session:
#         raise HTTPException(status_code=404, detail="Session not found")
    
#     # Fix the status check logic
#     if session.status.value != "completed":  # Compare with the string value
#         raise HTTPException(
#             status_code=400, 
#             detail=f"Session status is '{session.status.value}', must be 'completed' to generate a model."
#         )

#     # Get the final stage JSON (assuming stage 4 is the final one)
#     final_stage = JSONStageRepository(db).get_by_session_and_stage(session_id, 4)
#     if not final_stage or not final_stage.output_json:
#         raise HTTPException(status_code=404, detail="Final validated JSON (Stage 4) not found for this session.")

#     try:
#         # Default export settings for GLB
#         export_settings = ExportSettings(format=OutputFormat.GLB)
#         request = ModelGenerationRequest(
#             session_id=session_id,
#             input_json=final_stage.output_json,
#             export_settings=export_settings,
#             output_formats=[OutputFormat.GLB]
#         )
#         result = await blender_service.generate_3d_model(request)
#         return result
#     except Exception as e:
#         logger.error(f"Failed to generate 3D model for session {session_id}: {e}", exc_info=True)
#         raise HTTPException(status_code=500, detail=f"3D model generation failed: {e}")

@router.get("/sessions/{session_id}/models", response_model=List[Dict[str, Any]])
def get_generated_models(session_id: int, db: Session = Depends(get_db)):
    """
    Get a list of all 3D models generated for a session.
    """
    models = ModelOutputRepository(db).get_by_session(session_id)
    if not models:
        # Check if session exists
        if not ProcessingSessionRepository(db).get_by_id(session_id):
            raise HTTPException(status_code=404, detail="Session not found")
        return []

    return [
        {
            "model_id": model.id,
            "output_type": model.output_type.value,
            "file_path": model.file_path,
            "file_size_mb": model.file_size_mb,
            "created_at": model.created_at,
            "download_url": f"/api/v2/sessions/{session_id}/models/{model.id}/download"
        } for model in models
    ]

@router.get("/sessions/{session_id}/models/{model_id}/download")
def download_3d_model(session_id: int, model_id: int, db: Session = Depends(get_db)):
    """
    Download a specific 3D model file.
    """
    model = ModelOutputRepository(db).get_by_id(model_id)
    if not model or model.session_id != session_id:
        raise HTTPException(status_code=404, detail="Model not found")

    file_path = model.file_path
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Model file not found on server.")

    return FileResponse(path=file_path, filename=os.path.basename(file_path))