import matplotlib
matplotlib.use("Agg")

import os
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import logging
from typing import Dict, Any, List
from collections import Counter

logger = logging.getLogger("visualization_service")


class VisualizationService:
    def __init__(self, output_dir: str = "session_visualizations"):
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)
        
        # YOLO class mapping (index to class name)
        self.yolo_classes = [
            "Wall", "Door", "Window", "Bed", "Table", "Dining", "Sofa", "Sink",
            "Bathtub", "Western_T", "Indian_T", "Stove", "Cabinet", "Fridge",
            "Cupboard", "Flower_Pot", "W_Machine", "TV", "AC", "Steps", "Chair", "Balcony"
        ]
        
        # Define class colors for consistent visualization
        self.class_colors = {
            "Wall": "#2C3E50", "Door": "#E74C3C", "Window": "#3498DB", "Bed": "#9B59B6",
            "Table": "#E67E22", "Dining": "#F39C12", "Sofa": "#27AE60", "Sink": "#1ABC9C",
            "Bathtub": "#16A085", "Western_T": "#F1C40F", "Indian_T": "#F39C12",
            "Stove": "#E74C3C", "Cabinet": "#8E44AD", "Fridge": "#34495E", "Cupboard": "#7F8C8D",
            "Flower_Pot": "#2ECC71", "W_Machine": "#95A5A6", "TV": "#2C3E50", "AC": "#BDC3C7",
            "Steps": "#95A5A6", "Chair": "#D35400", "Balcony": "#1ABC9C"
        }

    def _determine_door_opening_direction(self, door_bbox: Dict, walls: List[Dict], ax) -> str:
        """
        Determine door direction ('top', 'bottom', 'left', 'right') using strict wall-edge overlap.
        Supports detecting adjacent overlapping walls in the same direction.
        """
        def overlaps(a, b, tol=5):
            return max(a[0], b[0]) - tol < min(a[1], b[1]) + tol
    
        x1, y1, x2, y2 = door_bbox['x1'], door_bbox['y1'], door_bbox['x2'], door_bbox['y2']
        door_x_range = (min(x1, x2), max(x1, x2))
        door_y_range = (min(y1, y2), max(y1, y2))
        door_center = ((x1 + x2) / 2, (y1 + y2) / 2)
    
        matched_walls = []
        direction = 'unknown'
    
        for wall in walls:
            wall_bbox = wall.get("bounding_box", {})
            wx1, wy1 = wall_bbox.get("x1"), wall_bbox.get("y1")
            wx2, wy2 = wall_bbox.get("x2"), wall_bbox.get("y2")
            if None in [wx1, wy1, wx2, wy2]:
                continue
    
            wall_x_range = (min(wx1, wx2), max(wx1, wx2))
            wall_y_range = (min(wy1, wy2), max(wy1, wy2))
    
            # Strict horizontal wall check
            if abs(wy1 - wy2) < 10 and overlaps(wall_x_range, door_x_range):
                if abs(wy1 - y1) <= 5: direction = "bottom"
                elif abs(wy1 - y2) <= 5: direction = "top"
                else: continue
                matched_walls.append(((wx1 + wx2) / 2, (wy1 + wy2) / 2))
    
            # Strict vertical wall check
            elif abs(wx1 - wx2) < 10 and overlaps(wall_y_range, door_y_range):
                if abs(wx1 - x1) <= 5: direction = "right"
                elif abs(wx1 - x2) <= 5: direction = "left"
                else: continue
                matched_walls.append(((wx1 + wx2) / 2, (wy1 + wy2) / 2))
    
        for wall_center in matched_walls:
            ax.plot([door_center[0], wall_center[0]], [door_center[1], wall_center[1]],
                    linestyle="--", color="orange", linewidth=2, alpha=0.9, zorder=4)
            ax.text((door_center[0] + wall_center[0]) / 2, (door_center[1] + wall_center[1]) / 2 - 10,
                    direction, fontsize=9, color="orange",
                    bbox=dict(boxstyle="round,pad=0.2", facecolor="white", alpha=0.8), zorder=5)
    
        return direction
    
   
    def visualize_yolo_lines_opencv(self, session_id: int, detected_objects: List[Dict[str, Any]], image_size=(4000, 4000)) -> None:
        import cv2
        import numpy as np
        import os
        import math
        from collections import defaultdict

        canvas = np.ones((image_size[1], image_size[0], 3), dtype=np.uint8) * 255
        output_path = os.path.join(self.output_dir, str(session_id))
        os.makedirs(output_path, exist_ok=True)
        image_path = os.path.join(output_path, "yolo_lines_output.png")

        target_classes = {"Wall", "Window"}
        wall_color = (0, 0, 255)  # Red for walls
        window_color = (0, 165, 255)  # Orange for windows
        vertex_color = (0, 255, 0)  # Green for vertices
        connection_color = (255, 0, 255)  # Magenta for vertex connections
        extended_color = (255, 255, 0)  # Cyan for extended/cut portions
        intersection_color = (255, 0, 0)  # Blue for intersection vertices
        line_thickness = 6
        vertex_radius = 15
        connection_thickness = 3

        # Thresholds for snapping
        VERTEX_MERGE_THRESHOLD = 30  # Distance to consider vertices as same
        SNAP_THRESHOLD = 80  # Distance to snap wall endpoints to vertices
        EXTENSION_LIMIT = 150  # Maximum distance to extend a wall
        INTERSECTION_TOLERANCE = 5  # Tolerance for line intersection detection

        # Step 1: Collect all relevant segments
        segments = []
        for obj in detected_objects:
            class_name = self._get_class_name(obj.get("class_name", ""))
            if class_name in target_classes:
                start = obj.get("start_point")
                end = obj.get("end_point")
                if start and end:
                    x1, y1 = float(start["x"]), float(start["y"])
                    x2, y2 = float(end["x"]), float(end["y"])
                    segments.append((class_name, (x1, y1), (x2, y2)))

        if not segments:
            logger.warning("No segments to draw.")
            return

        # Step 2: Compute bounding box and offset to center
        all_points = [p for _, s, e in segments for p in (s, e)]
        xs, ys = zip(*all_points)
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        plan_width = max_x - min_x
        plan_height = max_y - min_y
        offset_x = (image_size[0] - plan_width) / 2 - min_x
        offset_y = (image_size[1] - plan_height) / 2 - min_y

        # Step 3: Normalize coordinates
        norm_segments = []
        for cls, (x1, y1), (x2, y2) in segments:
            p1 = (x1 + offset_x, y1 + offset_y)
            p2 = (x2 + offset_x, y2 + offset_y)
            norm_segments.append((cls, p1, p2))

        # Step 4: Utility functions
        def distance(p1, p2):
            return math.hypot(p1[0] - p2[0], p1[1] - p2[1])

        def angle_between_points(p1, p2):
            return math.degrees(math.atan2(p2[1] - p1[1], p2[0] - p1[0]))

        def are_angles_similar(a1, a2, tolerance=10):
            """Check if two angles are similar (considering 180-degree symmetry)"""
            diff = abs(a1 - a2)
            return diff < tolerance or abs(diff - 180) < tolerance or abs(diff - 360) < tolerance

        def point_to_line_distance(point, line_start, line_end):
            """Calculate perpendicular distance from point to line segment"""
            x0, y0 = point
            x1, y1 = line_start
            x2, y2 = line_end
            
            if x1 == x2 and y1 == y2:
                return distance(point, line_start)
            
            A = y2 - y1
            B = x1 - x2
            C = x2 * y1 - x1 * y2
            
            return abs(A * x0 + B * y0 + C) / math.sqrt(A * A + B * B)

        def line_intersection(line1_start, line1_end, line2_start, line2_end):
            """
            Find intersection point of two line segments.
            Returns (intersection_point, on_segment1, on_segment2) or (None, False, False)
            """
            x1, y1 = line1_start
            x2, y2 = line1_end
            x3, y3 = line2_start
            x4, y4 = line2_end
            
            # Calculate the denominator
            denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
            
            # Lines are parallel if denominator is 0
            if abs(denom) < 1e-10:
                return None, False, False
            
            # Calculate intersection parameters
            t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom
            u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / denom
            
            # Calculate intersection point
            intersection_x = x1 + t * (x2 - x1)
            intersection_y = y1 + t * (y2 - y1)
            intersection = (intersection_x, intersection_y)
            
            # Check if intersection is on both line segments (with tolerance)
            tolerance = INTERSECTION_TOLERANCE / 100.0  # Convert to parameter space
            on_segment1 = -tolerance <= t <= 1 + tolerance
            on_segment2 = -tolerance <= u <= 1 + tolerance
            
            return intersection, on_segment1, on_segment2

        def point_on_line_segment(point, line_start, line_end, tolerance=INTERSECTION_TOLERANCE):
            """Check if a point lies on a line segment within tolerance"""
            # Check if point is within the bounding box of the line segment
            min_x = min(line_start[0], line_end[0]) - tolerance
            max_x = max(line_start[0], line_end[0]) + tolerance
            min_y = min(line_start[1], line_end[1]) - tolerance
            max_y = max(line_start[1], line_end[1]) + tolerance
            
            if not (min_x <= point[0] <= max_x and min_y <= point[1] <= max_y):
                return False
            
            # Check if point is close enough to the line
            dist_to_line = point_to_line_distance(point, line_start, line_end)
            return dist_to_line <= tolerance

        def extend_line_to_point(line_start, line_end, target_point, max_extension=EXTENSION_LIMIT):
            """Extend or cut a line to reach a target point"""
            # Calculate line direction vector
            dx = line_end[0] - line_start[0]
            dy = line_end[1] - line_start[1]
            line_length = math.hypot(dx, dy)
            
            if line_length == 0:
                return line_start, line_end, False
            
            # Normalize direction vector
            unit_dx = dx / line_length
            unit_dy = dy / line_length
            
            # Check which endpoint is closer to target
            dist_to_start = distance(line_start, target_point)
            dist_to_end = distance(line_end, target_point)
            
            if dist_to_start < dist_to_end:
                # Extend/cut from start
                # Project target point onto line to find intersection
                proj_length = ((target_point[0] - line_start[0]) * unit_dx + 
                            (target_point[1] - line_start[1]) * unit_dy)
                
                if abs(proj_length) <= max_extension:
                    new_start = target_point
                    return new_start, line_end, True
            else:
                # Extend/cut from end
                # Project target point onto line extended from end
                proj_length = ((target_point[0] - line_end[0]) * unit_dx + 
                            (target_point[1] - line_end[1]) * unit_dy)
                
                if abs(proj_length) <= max_extension:
                    new_end = target_point
                    return line_start, new_end, True
            
            return line_start, line_end, False

        def segments_can_merge(seg1, seg2, distance_threshold=50, angle_threshold=10, collinearity_threshold=20):
            """Check if two segments can be merged"""
            _, s1, e1 = seg1
            _, s2, e2 = seg2
            
            angle1 = angle_between_points(s1, e1)
            angle2 = angle_between_points(s2, e2)
            
            if not are_angles_similar(angle1, angle2, angle_threshold):
                return False
            
            distances = [
                point_to_line_distance(s2, s1, e1),
                point_to_line_distance(e2, s1, e1),
                point_to_line_distance(s1, s2, e2),
                point_to_line_distance(e1, s2, e2)
            ]
            
            if min(distances) > collinearity_threshold:
                return False
            
            endpoint_distances = [
                distance(s1, s2), distance(s1, e2),
                distance(e1, s2), distance(e1, e2)
            ]
            
            return min(endpoint_distances) < distance_threshold

        def merge_segment_group(group):
            """Merge a group of segments into a single continuous line"""
            if len(group) == 1:
                return group[0]
            
            all_points = []
            for _, s, e in group:
                all_points.extend([s, e])
            
            max_dist = 0
            best_pair = None
            
            for i, p1 in enumerate(all_points):
                for j, p2 in enumerate(all_points[i+1:], i+1):
                    dist = distance(p1, p2)
                    if dist > max_dist:
                        max_dist = dist
                        best_pair = (p1, p2)
            
            if best_pair:
                class_name = group[0][0]
                return (class_name, best_pair[0], best_pair[1])
            else:
                return group[0]

        # Step 5: Initial segment merging
        segment_groups = []
        used_indices = set()
        
        for i, seg1 in enumerate(norm_segments):
            if i in used_indices:
                continue
                
            current_group = [seg1]
            used_indices.add(i)
            
            group_changed = True
            while group_changed:
                group_changed = False
                for j, seg2 in enumerate(norm_segments):
                    if j in used_indices:
                        continue
                    
                    can_merge_with_group = False
                    for group_seg in current_group:
                        if segments_can_merge(group_seg, seg2):
                            can_merge_with_group = True
                            break
                    
                    if can_merge_with_group:
                        current_group.append(seg2)
                        used_indices.add(j)
                        group_changed = True
            
            segment_groups.append(current_group)

        # Step 6: Create initial merged segments
        initial_segments = []
        for group in segment_groups:
            merged_segment = merge_segment_group(group)
            initial_segments.append(merged_segment)

        # Step 7: Find line intersections and create intersection vertices
        intersection_points = []
        intersection_info = []  # Store which lines intersect where
        
        for i, (cls1, start1, end1) in enumerate(initial_segments):
            for j, (cls2, start2, end2) in enumerate(initial_segments[i+1:], i+1):
                intersection, on_seg1, on_seg2 = line_intersection(start1, end1, start2, end2)
                
                if intersection and on_seg1 and on_seg2:
                    # Make sure it's not too close to existing endpoints
                    too_close_to_endpoint = False
                    for endpoint in [start1, end1, start2, end2]:
                        if distance(intersection, endpoint) < VERTEX_MERGE_THRESHOLD:
                            too_close_to_endpoint = True
                            break
                    
                    if not too_close_to_endpoint:
                        intersection_points.append(intersection)
                        intersection_info.append({
                            'point': intersection,
                            'lines': [i, j],
                            'line_classes': [cls1, cls2]
                        })

        # Step 8: Find potential vertices (intersection points and endpoints)
        potential_vertices = []
        
        # Add all endpoints
        for cls, start_point, end_point in initial_segments:
            potential_vertices.extend([start_point, end_point])
        
        # Add intersection points
        potential_vertices.extend(intersection_points)
        
        # Cluster potential vertices
        vertices = {}
        vertex_id_counter = 0
        vertex_types = {}  # Track if vertex is intersection or endpoint
        
        for point in potential_vertices:
            # Check if this point is close to an existing vertex
            merged = False
            for vertex_id, vertex_pos in vertices.items():
                if distance(point, vertex_pos) <= VERTEX_MERGE_THRESHOLD:
                    # Update vertex position to average
                    vertices[vertex_id] = (
                        (vertices[vertex_id][0] + point[0]) / 2,
                        (vertices[vertex_id][1] + point[1]) / 2
                    )
                    # Mark as intersection if this point is an intersection
                    if point in intersection_points:
                        vertex_types[vertex_id] = 'intersection'
                    merged = True
                    break
            
            if not merged:
                vertex_id = f"V{vertex_id_counter}"
                vertices[vertex_id] = point
                # Mark vertex type
                if point in intersection_points:
                    vertex_types[vertex_id] = 'intersection'
                else:
                    vertex_types[vertex_id] = 'endpoint'
                vertex_id_counter += 1

        # Step 9: Snap segments to vertices (extend/cut walls)
        snapped_segments = []
        modifications = []  # Track what was modified
        
        for cls, start_point, end_point in initial_segments:
            new_start = start_point
            new_end = end_point
            start_snapped = False
            end_snapped = False
            
            # Find closest vertices to endpoints
            closest_start_vertex = None
            closest_start_dist = float('inf')
            closest_end_vertex = None
            closest_end_dist = float('inf')
            
            for vertex_id, vertex_pos in vertices.items():
                dist_to_start = distance(start_point, vertex_pos)
                dist_to_end = distance(end_point, vertex_pos)
                
                if dist_to_start < closest_start_dist and dist_to_start <= SNAP_THRESHOLD:
                    closest_start_dist = dist_to_start
                    closest_start_vertex = (vertex_id, vertex_pos)
                
                if dist_to_end < closest_end_dist and dist_to_end <= SNAP_THRESHOLD:
                    closest_end_dist = dist_to_end
                    closest_end_vertex = (vertex_id, vertex_pos)
            
            # Snap start point
            if closest_start_vertex and closest_start_dist <= SNAP_THRESHOLD:
                vertex_id, vertex_pos = closest_start_vertex
                # Try to extend/cut to vertex
                temp_start, temp_end, modified = extend_line_to_point(start_point, end_point, vertex_pos)
                if modified:
                    new_start = temp_start
                    start_snapped = True
                    modifications.append(f"Snapped start to {vertex_id}")
            
            # Snap end point
            if closest_end_vertex and closest_end_dist <= SNAP_THRESHOLD:
                vertex_id, vertex_pos = closest_end_vertex
                # Try to extend/cut to vertex
                temp_start, temp_end, modified = extend_line_to_point(new_start, end_point, vertex_pos)
                if modified:
                    new_end = temp_end
                    end_snapped = True
                    modifications.append(f"Snapped end to {vertex_id}")
            
            snapped_segments.append((cls, new_start, new_end, start_snapped, end_snapped))

        # Step 10: Update vertex positions after snapping and build connections
        final_vertices = {}
        vertex_connections = defaultdict(set)
        final_vertex_types = {}
        
        # Recalculate vertices from snapped segments and intersections
        all_snapped_points = []
        for cls, start_point, end_point, _, _ in snapped_segments:
            all_snapped_points.extend([start_point, end_point])
        
        # Re-add intersection points
        all_snapped_points.extend(intersection_points)
        
        vertex_id_counter = 0
        for point in all_snapped_points:
            merged = False
            for vertex_id, vertex_pos in final_vertices.items():
                if distance(point, vertex_pos) <= VERTEX_MERGE_THRESHOLD:
                    final_vertices[vertex_id] = (
                        (final_vertices[vertex_id][0] + point[0]) / 2,
                        (final_vertices[vertex_id][1] + point[1]) / 2
                    )
                    # Update type if this is an intersection
                    if point in intersection_points:
                        final_vertex_types[vertex_id] = 'intersection'
                    merged = True
                    break
            
            if not merged:
                vertex_id = f"V{vertex_id_counter}"
                final_vertices[vertex_id] = point
                if point in intersection_points:
                    final_vertex_types[vertex_id] = 'intersection'
                else:
                    final_vertex_types[vertex_id] = 'endpoint'
                vertex_id_counter += 1

        # Build connections
        for cls, start_point, end_point, _, _ in snapped_segments:
            start_vertex_id = None
            end_vertex_id = None
            
            for vertex_id, vertex_pos in final_vertices.items():
                if distance(start_point, vertex_pos) <= VERTEX_MERGE_THRESHOLD:
                    start_vertex_id = vertex_id
                if distance(end_point, vertex_pos) <= VERTEX_MERGE_THRESHOLD:
                    end_vertex_id = vertex_id
            
            if start_vertex_id and end_vertex_id and start_vertex_id != end_vertex_id:
                vertex_connections[start_vertex_id].add(end_vertex_id)
                vertex_connections[end_vertex_id].add(start_vertex_id)

        # Step 11: Draw everything
        
        # Draw vertex connections first
        for vertex_id, connected_ids in vertex_connections.items():
            vertex_pos = final_vertices[vertex_id]
            for connected_id in connected_ids:
                if connected_id > vertex_id:  # Avoid drawing same connection twice
                    connected_pos = final_vertices[connected_id]
                    cv2.line(canvas, 
                            (int(vertex_pos[0]), int(vertex_pos[1])), 
                            (int(connected_pos[0]), int(connected_pos[1])),
                            color=connection_color, 
                            thickness=connection_thickness)

        # Draw snapped segments
        for i, (cls, start_point, end_point, start_snapped, end_snapped) in enumerate(snapped_segments):
            pt1 = (int(start_point[0]), int(start_point[1]))
            pt2 = (int(end_point[0]), int(end_point[1]))
            
            # Choose color based on class
            if cls == "Wall":
                color = wall_color
            elif cls == "Window":
                color = window_color
            else:
                color = wall_color
            
            # Draw the main line
            cv2.line(canvas, pt1, pt2, color=color, thickness=line_thickness)
            
            # Highlight snapped portions
            if start_snapped:
                cv2.circle(canvas, pt1, radius=8, color=extended_color, thickness=3)
            if end_snapped:
                cv2.circle(canvas, pt2, radius=8, color=extended_color, thickness=3)
            
            # Add labels
            mid_point = ((pt1[0] + pt2[0]) // 2, (pt1[1] + pt2[1]) // 2)
            cv2.putText(canvas, f"{cls}-{i}", (mid_point[0] + 10, mid_point[1] - 10),
                        fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                        fontScale=0.7, color=(0, 0, 0), thickness=2)
            
            # Add length
            length = distance(start_point, end_point)
            cv2.putText(canvas, f"L:{int(length)}", (mid_point[0] + 10, mid_point[1] + 15),
                        fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                        fontScale=0.5, color=(128, 0, 128), thickness=1)

        # Draw vertices on top with different colors for intersections
        for vertex_id, vertex_pos in final_vertices.items():
            pt = (int(vertex_pos[0]), int(vertex_pos[1]))
            
            # Use different color for intersection vertices
            vertex_type = final_vertex_types.get(vertex_id, 'endpoint')
            if vertex_type == 'intersection':
                color = intersection_color
                # Draw larger circle for intersections
                cv2.circle(canvas, pt, radius=vertex_radius + 3, color=color, thickness=-1)
                cv2.circle(canvas, pt, radius=vertex_radius + 3, color=(0, 0, 0), thickness=2)
            else:
                color = vertex_color
                cv2.circle(canvas, pt, radius=vertex_radius, color=color, thickness=-1)
                cv2.circle(canvas, pt, radius=vertex_radius, color=(0, 0, 0), thickness=2)
            
            # Add connection count for intersection vertices
            connection_count = len(vertex_connections[vertex_id])
            if vertex_type == 'intersection' and connection_count > 2:
                cv2.putText(canvas, f"{vertex_id}({connection_count})", (pt[0] - 20, pt[1] - 20),
                            fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                            fontScale=0.6, color=(0, 0, 0), thickness=2)
            else:
                cv2.putText(canvas, vertex_id, (pt[0] - 15, pt[1] + 5),
                            fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                            fontScale=0.6, color=(0, 0, 0), thickness=2)

        # Step 12: Add comprehensive summary
        intersection_count = sum(1 for vtype in final_vertex_types.values() if vtype == 'intersection')
        endpoint_count = len(final_vertices) - intersection_count
        
        summary_text = [
            f"Original segments: {len(norm_segments)}",
            f"Merged segments: {len(initial_segments)}",
            f"Snapped segments: {len(snapped_segments)}",
            f"Total vertices: {len(final_vertices)}",
            f"  - Endpoints: {endpoint_count}",
            f"  - Intersections: {intersection_count}",
            f"Connections: {sum(len(conns) for conns in vertex_connections.values()) // 2}",
            f"Modifications: {len(modifications)}"
        ]
        
        # Summary background
        summary_bg_height = len(summary_text) * 30 + 20
        cv2.rectangle(canvas, (10, 10), (480, summary_bg_height), (240, 240, 240), -1)
        cv2.rectangle(canvas, (10, 10), (480, summary_bg_height), (0, 0, 0), 2)
        
        for i, text in enumerate(summary_text):
            cv2.putText(canvas, text, (20, 35 + i * 30),
                        fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                        fontScale=0.7, color=(0, 0, 0), thickness=2)

        # Legend
        legend_start_y = summary_bg_height + 30
        legend_items = [
            ("Walls", wall_color),
            ("Windows", window_color),
            ("Endpoint Vertices", vertex_color),
            ("Intersection Vertices", intersection_color),
            ("Connections", connection_color),
            ("Snapped Points", extended_color)
        ]
        
        legend_bg_height = len(legend_items) * 30 + 40
        cv2.rectangle(canvas, (10, legend_start_y), (320, legend_start_y + legend_bg_height), (250, 250, 250), -1)
        cv2.rectangle(canvas, (10, legend_start_y), (320, legend_start_y + legend_bg_height), (0, 0, 0), 2)
        
        cv2.putText(canvas, "Legend:", (20, legend_start_y + 25),
                    fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                    fontScale=0.7, color=(0, 0, 0), thickness=2)
        
        for i, (label, color) in enumerate(legend_items):
            y_pos = legend_start_y + 45 + i * 25
            cv2.rectangle(canvas, (25, y_pos - 8), (40, y_pos + 8), color, -1)
            cv2.rectangle(canvas, (25, y_pos - 8), (40, y_pos + 8), (0, 0, 0), 1)
            cv2.putText(canvas, label, (50, y_pos + 5),
                        fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                        fontScale=0.5, color=(0, 0, 0), thickness=1)

        cv2.imwrite(image_path, canvas)
        logger.info(f"Saved enhanced YOLO visualization to: {image_path}")
        logger.info(f"Found {intersection_count} line intersections")
        logger.info(f"Applied {len(modifications)} snapping modifications")
        logger.info(f"Final result: {len(final_vertices)} vertices ({endpoint_count} endpoints, {intersection_count} intersections), {len(snapped_segments)} segments")








    # def visualize_stage(self, session_id: int, stage_name: str, data: Dict[str, Any]) -> None:
    #     """
    #     MODIFIED: Visualize intermediate stages with bounding boxes for most items.
    #     - Walls are drawn as thick lines.
    #     - Doors have special line-and-marker visualization.
    #     - All other items (Windows, Furniture, etc.) are drawn as filled rectangles.
    #     """

    #     objects = data.get("detected_objects", [])
    #     # --- Auto-visualize YOLO walls/doors/windows for global_detection stage ---
    #     if "global_detection" in stage_name.lower() and objects:
    #         try:
    #             self.visualize_yolo_lines_opencv(session_id=session_id, detected_objects=objects)
    #         except Exception as e:
    #             logger.warning(f"Failed to auto-generate YOLO line image for global_detection: {e}", exc_info=True)

    #     try:
    #         session_dir = os.path.join(self.output_dir, str(session_id))
    #         os.makedirs(session_dir, exist_ok=True)
    #         image_path = os.path.join(session_dir, f"{stage_name}.png")

    #         logger.info(f"Visualizing stage {stage_name} for session {session_id}")

    #         if self._is_2layer_format(data):
    #             logger.info(f"Detected 2-layer format at root level for stage {stage_name}")
    #             self._visualize_2layer_format(data, image_path)
    #             return
    #         elif "json_output" in data and self._is_2layer_format(data["json_output"]):
    #             logger.info(f"Detected 2-layer format in json_output for stage {stage_name}")
    #             self._visualize_2layer_format(data["json_output"], image_path)
    #             return

    #         objects = data.get("detected_objects", [])
    #         if not objects and "json_output" in data:
    #             objects = data["json_output"].get("detected_objects", [])

    #         if not objects:
    #             logger.warning(f"No valid visualization structure in stage {stage_name} for session {session_id}")
    #             return

    #         fig, ax = plt.subplots(figsize=(20, 16))
    #         ax.set_aspect("equal")
    #         ax.invert_yaxis()
    #         ax.grid(True, linestyle="--", alpha=0.4)
    #         class_counts = Counter()

    #         for obj in objects:
    #             raw_class_name = obj.get("class_name", "unknown")
    #             proper_class_name = self._get_class_name(raw_class_name)
    #             color = self.class_colors.get(proper_class_name, "#808080")
    #             class_counts[proper_class_name] += 1

    #             # Case 1: Draw Walls as thick lines
    #             if proper_class_name == "Wall":
    #                 start, end = obj.get("start_point"), obj.get("end_point")
    #                 if start and end:
    #                     ax.plot([start["x"], end["x"]], [start["y"], end["y"]],
    #                             color=color, linewidth=6, alpha=0.8)
    #                 else:
    #                     logger.warning(f"Wall object missing start/end points: {obj}")
                
    #             elif proper_class_name == "Window":
    #                 start, end = obj.get("start_point"), obj.get("end_point")
    #                 if start and end:
    #                     ax.plot([start["x"], end["x"]], [start["y"], end["y"]],
    #                             color=color, linewidth=6, alpha=0.8)
    #                 else:
    #                     logger.warning(f"Wall object missing start/end points: {obj}")


    #             # Case 2: Special visualization for Doors
    #             # elif proper_class_name == "Door":
    #             #     start, end = obj.get("start_point"), obj.get("end_point")
    #             #     if start and end:
    #             #         x1, y1 = start["x"], start["y"]
    #             #         x2, y2 = end["x"], end["y"]
    #             #         ax.plot([x1, x2], [y1, y2], color=color, linewidth=4)
    #             #         ax.plot(x1, y1, 'go', markersize=8)
    #             #         ax.text(x1 + 5, y1 - 5, f"Start ({int(x1)}, {int(y1)})", fontsize=9, color="green", bbox=dict(boxstyle="round,pad=0.2", facecolor="white", alpha=0.7))
    #             #         ax.plot(x2, y2, 'bo', markersize=8)
    #             #         ax.text(x2 + 5, y2 - 5, f"End ({int(x2)}, {int(y2)})", fontsize=9, color="blue", bbox=dict(boxstyle="round,pad=0.2", facecolor="white", alpha=0.7))
    #             #         ax.text((x1 + x2) / 2, (y1 + y2) / 2 - 15, proper_class_name, color=color, fontsize=10, weight='bold', bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.85))
    #             #     else:
    #             #         logger.warning(f"Door object missing start/end points: {obj}")
                
    #             # Case 3: Draw all other items as bounding boxes
    #             else:
    #                 bbox = obj.get("bounding_box")
    #                 if bbox and all(k in bbox for k in ['x1', 'y1', 'x2', 'y2']):
    #                     x1, y1, x2, y2 = bbox['x1'], bbox['y1'], bbox['x2'], bbox['y2']
    #                     width = abs(x2 - x1)
    #                     height = abs(y2 - y1)
    #                     bottom_left_x = min(x1, x2)
    #                     bottom_left_y = min(y1, y2)
                        
    #                     rect = patches.Rectangle(
    #                         (bottom_left_x, bottom_left_y),
    #                         width, height,
    #                         linewidth=1.5,
    #                         edgecolor='black',
    #                         facecolor=color,
    #                         alpha=0.75
    #                     )
    #                     ax.add_patch(rect)

    #                     center_x = bottom_left_x + width / 2
    #                     center_y = bottom_left_y + height / 2
    #                     ax.text(center_x, center_y, proper_class_name,
    #                             color='white', fontsize=8, weight='bold',
    #                             ha='center', va='center')
    #                 else:
    #                     logger.warning(f"Object '{proper_class_name}' is missing a valid bounding_box. Cannot draw rectangle.")


    #         self._add_class_legend(ax, class_counts, stage_name)
    #         ax.set_title(f"Detection Results: {stage_name}", fontsize=18, fontweight='bold', pad=20)
    #         plt.tight_layout()
    #         plt.savefig(image_path, dpi=200, bbox_inches='tight', facecolor='white')
    #         plt.close()
    #         logger.info(f"Saved enhanced visualization for stage '{stage_name}' to {image_path}")
    #     except Exception as e:
    #         logger.error(f"Failed to visualize stage {stage_name} for session {session_id}: {e}", exc_info=True)


    # def visualize_stage(self, session_id: int, stage_name: str, data: Dict[str, Any]) -> None:
    #     """
    #     MODIFIED: Visualize intermediate stages with bounding boxes for most items.
    #     - Walls are drawn as thick lines.
    #     - Doors AND Windows are both drawn as thick lines (same treatment).
    #     - All other items (Furniture, etc.) are drawn as filled rectangles.
    #     """

    #     objects = data.get("detected_objects", [])
    #     # --- Auto-visualize YOLO walls/doors/windows for global_detection stage ---
    #     if "global_detection" in stage_name.lower() and objects:
    #         try:
    #             self.visualize_yolo_lines_opencv(session_id=session_id, detected_objects=objects)
    #         except Exception as e:
    #             logger.warning(f"Failed to auto-generate YOLO line image for global_detection: {e}", exc_info=True)

    #     try:
    #         session_dir = os.path.join(self.output_dir, str(session_id))
    #         os.makedirs(session_dir, exist_ok=True)
    #         image_path = os.path.join(session_dir, f"{stage_name}.png")

    #         logger.info(f"Visualizing stage {stage_name} for session {session_id}")

    #         if self._is_2layer_format(data):
    #             logger.info(f"Detected 2-layer format at root level for stage {stage_name}")
    #             self._visualize_2layer_format(data, image_path)
    #             return
    #         elif "json_output" in data and self._is_2layer_format(data["json_output"]):
    #             logger.info(f"Detected 2-layer format in json_output for stage {stage_name}")
    #             self._visualize_2layer_format(data["json_output"], image_path)
    #             return

    #         objects = data.get("detected_objects", [])
    #         if not objects and "json_output" in data:
    #             objects = data["json_output"].get("detected_objects", [])

    #         if not objects:
    #             logger.warning(f"No valid visualization structure in stage {stage_name} for session {session_id}")
    #             return

    #         fig, ax = plt.subplots(figsize=(20, 16))
    #         ax.set_aspect("equal")
    #         ax.invert_yaxis()
    #         ax.grid(True, linestyle="--", alpha=0.4)
    #         class_counts = Counter()

    #         for obj in objects:
    #             raw_class_name = obj.get("class_name", "unknown")
    #             proper_class_name = self._get_class_name(raw_class_name)
    #             color = self.class_colors.get(proper_class_name, "#808080")
    #             class_counts[proper_class_name] += 1

    #             # Case 1: Draw Walls, Windows, AND Doors as thick lines
    #             if proper_class_name in ["Wall", "Window", "Door"]:
    #                 start, end = obj.get("start_point"), obj.get("end_point")
    #                 if start and end:
    #                     # Use different line widths to distinguish between them
    #                     if proper_class_name == "Wall":
    #                         linewidth = 6
    #                     elif proper_class_name == "Window":
    #                         linewidth = 6
    #                     else:  # Door
    #                         linewidth = 6
                        
    #                     ax.plot([start["x"], end["x"]], [start["y"], end["y"]],
    #                             color=color, linewidth=linewidth, alpha=0.8)
                        
    #                     # Optional: Add text label at the midpoint for doors to distinguish them
    #                     if proper_class_name == "Door":
    #                         mid_x = (start["x"] + end["x"]) / 2
    #                         mid_y = (start["y"] + end["y"]) / 2
    #                         ax.text(mid_x, mid_y - 15, "DOOR", color=color, fontsize=8, 
    #                             weight='bold', ha='center',
    #                             bbox=dict(boxstyle="round,pad=0.2", facecolor='white', alpha=0.8))
    #                 else:
    #                     logger.warning(f"{proper_class_name} object missing start/end points: {obj}")

    #             # Case 2: Draw all other items as bounding boxes
    #             else:
    #                 bbox = obj.get("bounding_box")
    #                 if bbox and all(k in bbox for k in ['x1', 'y1', 'x2', 'y2']):
    #                     x1, y1, x2, y2 = bbox['x1'], bbox['y1'], bbox['x2'], bbox['y2']
    #                     width = abs(x2 - x1)
    #                     height = abs(y2 - y1)
    #                     bottom_left_x = min(x1, x2)
    #                     bottom_left_y = min(y1, y2)
                        
    #                     rect = patches.Rectangle(
    #                         (bottom_left_x, bottom_left_y),
    #                         width, height,
    #                         linewidth=1.5,
    #                         edgecolor='black',
    #                         facecolor=color,
    #                         alpha=0.75
    #                     )
    #                     ax.add_patch(rect)

    #                     center_x = bottom_left_x + width / 2
    #                     center_y = bottom_left_y + height / 2
    #                     ax.text(center_x, center_y, proper_class_name,
    #                             color='white', fontsize=8, weight='bold',
    #                             ha='center', va='center')
    #                 else:
    #                     logger.warning(f"Object '{proper_class_name}' is missing a valid bounding_box. Cannot draw rectangle.")

    #         self._add_class_legend(ax, class_counts, stage_name)
    #         ax.set_title(f"Detection Results: {stage_name}", fontsize=18, fontweight='bold', pad=20)
    #         plt.tight_layout()
    #         plt.savefig(image_path, dpi=200, bbox_inches='tight', facecolor='white')
    #         plt.close()
    #         logger.info(f"Saved enhanced visualization for stage '{stage_name}' to {image_path}")
    #     except Exception as e:
    #         logger.error(f"Failed to visualize stage {stage_name} for session {session_id}: {e}", exc_info=True)


    def visualize_stage(self, session_id: int, stage_name: str, data: Dict[str, Any]) -> None:
        """
        MODIFIED: Visualize intermediate stages with consistent line treatment for walls, windows, and doors.
        - Walls, Windows, and Doors are ALL drawn as thick lines (no special markers for doors).
        - All other items (Furniture, etc.) are drawn as filled rectangles.
        """

        objects = data.get("detected_objects", [])
        # --- Auto-visualize YOLO walls/doors/windows for global_detection stage ---
        if "global_detection" in stage_name.lower() and objects:
            try:
                self.visualize_yolo_lines_opencv(session_id=session_id, detected_objects=objects)
            except Exception as e:
                logger.warning(f"Failed to auto-generate YOLO line image for global_detection: {e}", exc_info=True)

        try:
            session_dir = os.path.join(self.output_dir, str(session_id))
            os.makedirs(session_dir, exist_ok=True)
            image_path = os.path.join(session_dir, f"{stage_name}.png")

            logger.info(f"Visualizing stage {stage_name} for session {session_id}")

            if self._is_2layer_format(data):
                logger.info(f"Detected 2-layer format at root level for stage {stage_name}")
                self._visualize_2layer_format(data, image_path)
                return
            elif "json_output" in data and self._is_2layer_format(data["json_output"]):
                logger.info(f"Detected 2-layer format in json_output for stage {stage_name}")
                self._visualize_2layer_format(data["json_output"], image_path)
                return

            objects = data.get("detected_objects", [])
            if not objects and "json_output" in data:
                objects = data["json_output"].get("detected_objects", [])

            if not objects:
                logger.warning(f"No valid visualization structure in stage {stage_name} for session {session_id}")
                return

            fig, ax = plt.subplots(figsize=(20, 16))
            ax.set_aspect("equal")
            ax.invert_yaxis()
            ax.grid(True, linestyle="--", alpha=0.4)
            class_counts = Counter()

            for obj in objects:
                raw_class_name = obj.get("class_name", "unknown")
                proper_class_name = self._get_class_name(raw_class_name)
                color = self.class_colors.get(proper_class_name, "#808080")
                class_counts[proper_class_name] += 1

                # UNIFIED HANDLING: Draw Walls, Windows, AND Doors as thick lines (NO special cases)
                if proper_class_name in ["Wall", "Window", "Door"]:
                    start, end = obj.get("start_point"), obj.get("end_point")
                    if start and end:
                        ax.plot([start["x"], end["x"]], [start["y"], end["y"]],
                                color=color, linewidth=6, alpha=0.8)
                    else:
                        logger.warning(f"{proper_class_name} object missing start/end points: {obj}")
                        # Fallback: if no start/end points, try to draw from bounding box
                        bbox = obj.get("bounding_box")
                        if bbox and all(k in bbox for k in ['x1', 'y1', 'x2', 'y2']):
                            # Convert bounding box to line (use center points of opposite edges)
                            x1, y1, x2, y2 = bbox['x1'], bbox['y1'], bbox['x2'], bbox['y2']
                            # Draw line from center of left edge to center of right edge
                            if abs(x2 - x1) > abs(y2 - y1):  # Horizontal orientation
                                start_x, start_y = x1, (y1 + y2) / 2
                                end_x, end_y = x2, (y1 + y2) / 2
                            else:  # Vertical orientation
                                start_x, start_y = (x1 + x2) / 2, y1
                                end_x, end_y = (x1 + x2) / 2, y2
                            ax.plot([start_x, end_x], [start_y, end_y],
                                    color=color, linewidth=6, alpha=0.8)

                # Draw all other items as bounding box rectangles
                else:
                    bbox = obj.get("bounding_box")
                    if bbox and all(k in bbox for k in ['x1', 'y1', 'x2', 'y2']):
                        x1, y1, x2, y2 = bbox['x1'], bbox['y1'], bbox['x2'], bbox['y2']
                        width = abs(x2 - x1)
                        height = abs(y2 - y1)
                        bottom_left_x = min(x1, x2)
                        bottom_left_y = min(y1, y2)
                        
                        rect = patches.Rectangle(
                            (bottom_left_x, bottom_left_y),
                            width, height,
                            linewidth=1.5,
                            edgecolor='black',
                            facecolor=color,
                            alpha=0.75
                        )
                        ax.add_patch(rect)

                        center_x = bottom_left_x + width / 2
                        center_y = bottom_left_y + height / 2
                        ax.text(center_x, center_y, proper_class_name,
                                color='white', fontsize=8, weight='bold',
                                ha='center', va='center')
                    else:
                        logger.warning(f"Object '{proper_class_name}' is missing a valid bounding_box. Cannot draw rectangle.")

            self._add_class_legend(ax, class_counts, stage_name)
            ax.set_title(f"Detection Results: {stage_name}", fontsize=18, fontweight='bold', pad=20)
            plt.tight_layout()
            plt.savefig(image_path, dpi=200, bbox_inches='tight', facecolor='white')
            plt.close()
            logger.info(f"Saved enhanced visualization for stage '{stage_name}' to {image_path}")
        except Exception as e:
            logger.error(f"Failed to visualize stage {stage_name} for session {session_id}: {e}", exc_info=True)


    def _get_class_name(self, raw_class_name: str) -> str:
        """Convert raw class name to proper class name"""
        if raw_class_name.startswith("class_"):
            try:
                class_index = int(raw_class_name.split("_")[1])
                if 0 <= class_index < len(self.yolo_classes):
                    return self.yolo_classes[class_index]
            except (ValueError, IndexError):
                pass
        
        for class_name in self.yolo_classes:
            if raw_class_name.lower() == class_name.lower():
                return class_name
        
        return raw_class_name

    def visualize_final_2layer(self, session_id: int, data: Dict[str, Any]) -> None:
        """Specific method for visualizing final 2-layer output"""
        self.visualize_stage(session_id, "04_final_output", data)

    def _is_2layer_format(self, data: Dict[str, Any]) -> bool:
        """Check if data is in 2-layer format"""
        if not isinstance(data, dict) or "layers" not in data or not isinstance(data["layers"], dict):
            return False
        if "layer-1" not in data["layers"] or not isinstance(data["layers"]["layer-1"], dict):
            return False
        layer_1 = data["layers"]["layer-1"]
        return all(key in layer_1 for key in ["vertices", "lines"])

    # def _visualize_2layer_format(self, data: Dict[str, Any], image_path: str):
    #     """Visualize 2-layer format data with walls, holes, and item objects (22 classes)"""
    #     try:
    #         layer = data["layers"]["layer-1"]
    #         vertices = layer.get("vertices", {})
    #         lines = layer.get("lines", {})
    #         holes = layer.get("holes", {})
    #         items = layer.get("items", {})

    #         canvas_width = data.get("width", 4000)
    #         canvas_height = data.get("height", 4000)

    #         fig, ax = plt.subplots(figsize=(24, 20))
    #         ax.set_aspect("equal")
    #         ax.grid(True, linestyle="--", alpha=0.3)
    #         ax.set_xlim(0, canvas_width)
    #         ax.set_ylim(0, canvas_height)
    #         ax.invert_yaxis()

    #         class_counts = Counter()
    #         walls_drawn = 0

    #         # --- Draw Walls ---
    #         for line_id, line in lines.items():
    #             if line.get("type") == "wall":
    #                 vertex_ids = line.get("vertices", [])
    #                 if len(vertex_ids) >= 2:
    #                     v1, v2 = vertices.get(vertex_ids[0]), vertices.get(vertex_ids[1])
    #                     if v1 and v2:
    #                         wall_color = self.class_colors.get("Wall", "#2C3E50")
    #                         ax.plot([v1["x"], v2["x"]], [v1["y"], v2["y"]], color=wall_color, linewidth=6, alpha=0.9)
    #                         walls_drawn += 1
    #                         class_counts["Wall"] += 1
                            
    #                         # --- Draw Holes (doors/windows) on the wall ---
    #                         for hole_id in line.get("holes", []):
    #                             hole = holes.get(hole_id)
    #                             if hole:
    #                                 offset = hole.get("offset", 0.5)
    #                                 hx = v1["x"] + offset * (v2["x"] - v1["x"])
    #                                 hy = v1["y"] + offset * (v2["y"] - v1["y"])
    #                                 hole_type = hole.get("type", "").lower()
    #                                 if "door" in hole_type:
    #                                     color, marker, size, class_name = self.class_colors.get("Door", "#E74C3C"), "s", 20, "Door"
    #                                 elif "window" in hole_type:
    #                                     color, marker, size, class_name = self.class_colors.get("Window", "#3498DB"), "o", 18, "Window"
    #                                 else:
    #                                     color, marker, size, class_name = "#2ECC71", "^", 16, "Hole"
    #                                 class_counts[class_name] += 1
    #                                 ax.plot(hx, hy, marker=marker, color=color, markersize=size, markeredgecolor='black', markeredgewidth=2, alpha=0.9)

    #         # --- Draw Vertices ---
    #         vertices_drawn = 0
    #         for vertex in vertices.values():
    #             ax.plot(vertex["x"], vertex["y"], "ko", markersize=4, alpha=0.7)
    #             vertices_drawn += 1
            
    #         # --- Draw Items as Rectangles ---
    #         for item_id, item in items.items():
    #             item_type = self._get_class_name(item.get("type", "unknown"))
    #             cx, cy = item.get("x", 0), item.get("y", 0)
    #             width, height = item.get("width", 50), item.get("height", 50)
    #             bottom_left_x, bottom_left_y = cx - width / 2, cy - height / 2
    #             color = self.class_colors.get(item_type, "#7f8c8d")

    #             rect = patches.Rectangle((bottom_left_x, bottom_left_y), width, height, linewidth=2,
    #                                      edgecolor='black', facecolor=color, alpha=0.8, zorder=10)
    #             ax.add_patch(rect)
                
    #             ax.text(cx, cy, item_type, fontsize=9, color='white', weight='bold', ha='center', va='center')
    #             class_counts[item_type] += 1

    #         # --- Legend and Title ---
    #         self._add_class_legend(ax, class_counts, "Final Floor Plan")
    #         total_objects = sum(class_counts.values())
    #         ax.set_title(f"Final 2-Layer Floor Plan\nTotal Objects: {total_objects} | Vertices: {vertices_drawn}",
    #                      fontsize=22, fontweight='bold', pad=30)
    #         ax.set_xticks([]); ax.set_yticks([])
    #         for spine in ax.spines.values():
    #             spine.set_edgecolor('black'); spine.set_linewidth(3)

    #         plt.tight_layout()
    #         plt.savefig(image_path, dpi=300, bbox_inches='tight', facecolor='white', edgecolor='black')
    #         plt.close()

    #         logger.info(f"Successfully visualized 2-layer format: {walls_drawn} walls, "
    #                     f"{vertices_drawn} vertices, {total_objects} total objects")
    #     except Exception as e:
    #         logger.error(f"Error in _visualize_2layer_format: {e}", exc_info=True)
    #         fig, ax = plt.subplots(figsize=(12, 8))
    #         ax.text(0.5, 0.5, f"Visualization Error\n{str(e)}", ha='center', va='center', fontsize=16, color='red')
    #         plt.savefig(image_path, dpi=200, bbox_inches='tight')
    #         plt.close()

    def _visualize_2layer_format(self, data: Dict[str, Any], image_path: str):
        """
        MODIFIED: Visualize 2-layer format data, correctly creating gaps in walls for holes.
        """
        try:
            layer = data["layers"]["layer-1"]
            vertices = layer.get("vertices", {})
            lines = layer.get("lines", {})
            holes = layer.get("holes", {})
            items = layer.get("items", {})

            canvas_width = data.get("width", 4000)
            canvas_height = data.get("height", 4000)

            fig, ax = plt.subplots(figsize=(24, 20))
            ax.set_aspect("equal")
            ax.grid(True, linestyle="--", alpha=0.3)
            ax.set_xlim(0, canvas_width)
            ax.set_ylim(0, canvas_height)
            ax.invert_yaxis()

            class_counts = Counter()
            
            # --- Draw Walls with Gaps for Holes ---
            for line_id, line in lines.items():
                if line.get("type") != "wall":
                    continue
                
                vertex_ids = line.get("vertices", [])
                if len(vertex_ids) < 2:
                    continue

                v1, v2 = vertices.get(vertex_ids[0]), vertices.get(vertex_ids[1])
                if not v1 or not v2:
                    continue

                wall_color = self.class_colors.get("Wall", "#2C3E50")
                class_counts["Wall"] += 1

                line_holes = [holes.get(h_id) for h_id in line.get("holes", []) if h_id in holes]

                if not line_holes:
                    # No holes, draw the full wall line
                    ax.plot([v1["x"], v2["x"]], [v1["y"], v2["y"]], color=wall_color, linewidth=6, alpha=0.9)
                else:
                    # --- Logic to create gaps in the wall ---
                    line_length = ((v2["x"] - v1["x"])**2 + (v2["y"] - v1["y"])**2)**0.5
                    if line_length < 1e-6: continue

                    # Create a list of "events" along the wall: start, end, and hole boundaries
                    break_points = [(0.0, 'wall_segment'), (1.0, 'wall_segment')]
                    for hole in line_holes:
                        hole_width = hole["properties"]["width"]["length"]
                        hole_offset_center = hole["offset"]
                        
                        # Convert absolute width to a fractional offset
                        half_width_offset = (hole_width / 2.0) / line_length
                        
                        start_offset = max(0.0, hole_offset_center - half_width_offset)
                        end_offset = min(1.0, hole_offset_center + half_width_offset)
                        
                        break_points.append((start_offset, 'hole_boundary'))
                        break_points.append((end_offset, 'hole_boundary'))
                    
                    # Sort points by their position along the wall
                    break_points.sort()

                    # Draw the segments between the break points
                    for i in range(len(break_points) - 1):
                        start_offset = break_points[i][0]
                        end_offset = break_points[i+1][0]
                        
                        # We draw a wall segment if the midpoint is not inside a hole
                        mid_point_offset = (start_offset + end_offset) / 2.0
                        
                        is_gap = False
                        for hole in line_holes:
                            hole_width = hole["properties"]["width"]["length"]
                            half_width_offset = (hole_width / 2.0) / line_length
                            hole_start = hole["offset"] - half_width_offset
                            hole_end = hole["offset"] + half_width_offset
                            if hole_start < mid_point_offset < hole_end:
                                is_gap = True
                                break
                        
                        if not is_gap:
                            p_start_x = v1["x"] + start_offset * (v2["x"] - v1["x"])
                            p_start_y = v1["y"] + start_offset * (v2["y"] - v1["y"])
                            p_end_x = v1["x"] + end_offset * (v2["x"] - v1["x"])
                            p_end_y = v1["y"] + end_offset * (v2["y"] - v1["y"])
                            ax.plot([p_start_x, p_end_x], [p_start_y, p_end_y], color=wall_color, linewidth=6, alpha=0.9)

                # --- Draw Hole Icons (doors/windows) ---
                for hole in line_holes:
                    offset = hole.get("offset", 0.5)
                    hx = v1["x"] + offset * (v2["x"] - v1["x"])
                    hy = v1["y"] + offset * (v2["y"] - v1["y"])
                    hole_type = hole.get("type", "").lower()
                    if "door" in hole_type:
                        color, marker, size, class_name = self.class_colors.get("Door", "#E74C3C"), "s", 20, "Door"
                    elif "window" in hole_type:
                        color, marker, size, class_name = self.class_colors.get("Window", "#3498DB"), "o", 18, "Window"
                    else:
                        color, marker, size, class_name = "#2ECC71", "^", 16, "Hole"
                    class_counts[class_name] += 1
                    ax.plot(hx, hy, marker=marker, color=color, markersize=size, markeredgecolor='black', markeredgewidth=2, alpha=0.9, zorder=12)

            # --- Draw Vertices ---
            for vertex in vertices.values():
                ax.plot(vertex["x"], vertex["y"], "ko", markersize=4, alpha=0.7)
            
            # --- Draw Items as Rectangles ---
            for item_id, item in items.items():
                item_type = self._get_class_name(item.get("type", "unknown"))
                # Use properties for dimensions if available, fallback to root level
                props = item.get("properties", {})
                width = props.get("width", {}).get("length", item.get("width", 50))
                height = props.get("depth", {}).get("length", item.get("height", 50))
                
                cx, cy = item.get("x", 0), item.get("y", 0)
                rotation = item.get("rotation", 0)
                color = self.class_colors.get(item_type, "#7f8c8d")

                # Create a rectangle centered at (0,0) and then transform it
                rect = patches.Rectangle((-width / 2, -height / 2), width, height, linewidth=1.5,
                                            edgecolor='black', facecolor=color, alpha=0.8, zorder=10)
                
                transform = matplotlib.transforms.Affine2D().rotate_deg_around(0, 0, rotation).translate(cx, cy) + ax.transData
                rect.set_transform(transform)
                ax.add_patch(rect)
                
                ax.text(cx, cy, item_type, fontsize=9, color='white', weight='bold', ha='center', va='center', zorder=11)
                class_counts[item_type] += 1

            # --- Legend and Title ---
            self._add_class_legend(ax, class_counts, "Final Floor Plan")
            total_objects = sum(class_counts.values())
            ax.set_title(f"Final 2-Layer Floor Plan\nTotal Objects: {total_objects} | Vertices: {len(vertices)}",
                            fontsize=22, fontweight='bold', pad=30)
            ax.set_xticks([]); ax.set_yticks([])
            for spine in ax.spines.values():
                spine.set_edgecolor('black'); spine.set_linewidth(3)

            plt.tight_layout()
            plt.savefig(image_path, dpi=300, bbox_inches='tight', facecolor='white', edgecolor='black')
            plt.close()

            logger.info(f"Successfully visualized 2-layer format with gaps for holes.")
        except Exception as e:
            logger.error(f"Error in _visualize_2layer_format: {e}", exc_info=True)
            fig, ax = plt.subplots(figsize=(12, 8))
            ax.text(0.5, 0.5, f"Visualization Error\n{str(e)}", ha='center', va='center', fontsize=16, color='red')
            plt.savefig(image_path, dpi=200, bbox_inches='tight')
            plt.close()

    def _add_class_legend(self, ax, class_counts: Counter, title: str):
        """Add a comprehensive legend showing class counts and colors"""
        if not class_counts:
            return
            
        sorted_classes = sorted(class_counts.items(), key=lambda x: x[1], reverse=True)
        
        legend_elements = [patches.Patch(color=self.class_colors.get(class_name, "#808080"), label=f"{class_name}: {count}")
                           for class_name, count in sorted_classes]
        
        legend = ax.legend(handles=legend_elements, 
                          loc='center left', 
                          bbox_to_anchor=(1.02, 0.5),
                          fontsize=12,
                          title=f"Detected Classes ({len(sorted_classes)} types)",
                          title_fontsize=14,
                          frameon=True,
                          fancybox=True,
                          shadow=True)
        
        legend.get_frame().set_facecolor('white')
        legend.get_frame().set_alpha(0.9)
        legend.get_frame().set_edgecolor('black')
        legend.get_frame().set_linewidth(1)
        
        total_count = sum(class_counts.values())
        ax.text(1.02, 0.02, f"Total Objects: {total_count}", 
                transform=ax.transAxes, fontsize=12, fontweight='bold',
                bbox=dict(boxstyle="round,pad=0.3", facecolor='lightblue', alpha=0.7))

    def create_color_reference_chart(self, session_id: int) -> None:
        """Create a reference chart showing all class colors"""
        try:
            session_dir = os.path.join(self.output_dir, str(session_id))
            os.makedirs(session_dir, exist_ok=True)
            image_path = os.path.join(session_dir, "color_reference.png")
            
            fig, ax = plt.subplots(figsize=(12, 16))
            
            y_pos = 0
            for i, (class_name, color) in enumerate(self.class_colors.items()):
                rect = patches.Rectangle((0, y_pos), 1, 0.8, facecolor=color, edgecolor='black', linewidth=1)
                ax.add_patch(rect)
                ax.text(1.2, y_pos + 0.4, f"{i}: {class_name}", fontsize=12, va='center', fontweight='bold')
                ax.text(4, y_pos + 0.4, f"(class_{i})", fontsize=10, va='center', color='gray', style='italic')
                y_pos += 1
            
            ax.set_xlim(0, 6)
            ax.set_ylim(0, len(self.class_colors))
            ax.set_title("YOLO Class Color Reference", fontsize=16, fontweight='bold', pad=20)
            ax.axis('off')
            
            plt.tight_layout()
            plt.savefig(image_path, dpi=200, bbox_inches='tight', facecolor='white')
            plt.close()
            
            logger.info(f"Created color reference chart at {image_path}")
        except Exception as e:
            logger.error(f"Failed to create color reference chart: {e}", exc_info=True)
