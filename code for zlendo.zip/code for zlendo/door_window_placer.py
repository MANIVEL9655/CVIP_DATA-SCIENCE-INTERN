# import numpy as np
# import trimesh
# import math
# from typing import Dict, Any, Optional, List
# from dataclasses import dataclass
# from PIL import Image
# import os

# @dataclass
# class HoleInfo:
#     center: np.ndarray
#     start: np.ndarray
#     end: np.ndarray
#     direction: np.ndarray
#     normal: np.ndarray
#     width: float
#     height: float
#     thickness: float
#     altitude: float
#     wall_thickness: float
#     wall_start: np.ndarray
#     wall_end: np.ndarray
#     wall_length: float
#     hole_id: str  # Added hole_id to store the identifier

# class DoorWindowPlacer:
#     def __init__(self, assets_config: Dict[str, Any]):
#         self.assets = assets_config

#     def calculate_hole_position(self, hole_data: Dict, line_data: Dict, vertices_data: Dict) -> Optional[HoleInfo]:
#         """Calculate hole position and dimensions"""
#         try:
#             v_ids = line_data.get('vertices', [])
#             if len(v_ids) != 2:
#                 return None

#             v1, v2 = vertices_data[v_ids[0]], vertices_data[v_ids[1]]
#             p1 = np.array([v1['x']/100.0, -v1['y']/100.0])
#             p2 = np.array([v2['x']/100.0, -v2['y']/100.0])

#             vec = p2 - p1
#             length = np.linalg.norm(vec)
#             if length == 0:
#                 return None

#             direction = vec / length
#             normal = np.array([-direction[1], direction[0]])

#             props = hole_data.get('properties', {})
#             return HoleInfo(
#                 center=p1 + direction * (length * hole_data.get('offset', 0.5)),
#                 start=p1,
#                 end=p2,
#                 direction=direction,
#                 normal=normal,
#                 width=float(props.get('width', {}).get('length', 80))/100.0,
#                 height=float(props.get('height', {}).get('length', 210))/100.0,
#                 thickness=float(props.get('thickness', {}).get('length', 10))/100.0,
#                 altitude=float(props.get('altitude', {}).get('length', 0))/100.0,
#                 wall_thickness=float(line_data.get('properties', {}).get('thickness', {}).get('length', 20))/100.0,
#                 wall_start=p1,
#                 wall_end=p2,
#                 wall_length=length,
#                 hole_id=hole_data.get('id', '')
#             )
#         except Exception as e:
#             print(f"Error calculating hole position: {e}")
#             return None

#     def create_door_window_meshes(self, holes_data: Dict, lines_data: Dict, vertices_data: Dict) -> List[trimesh.Trimesh]:
#         """Create all door and window meshes"""
#         meshes = []
#         for hole_id, hole_data in holes_data.items():
#             line_id = hole_data.get('line')
#             if not line_id or line_id not in lines_data:
#                 continue

#             line_data = lines_data[line_id]
#             hole_type = hole_data.get('type', '').lower()

#             try:
#                 if 'door' in hole_type:
#                     mesh = self._create_door_mesh(hole_data, line_data, vertices_data)
#                 elif 'window' in hole_type:
#                     mesh = self._create_window_mesh(hole_data, line_data, vertices_data)
#                 else:
#                     continue

#                 if mesh:
#                     meshes.append(mesh)
#             except Exception as e:
#                 print(f"Error creating {hole_type} {hole_id}: {e}")

#         return meshes

#     def _create_door_mesh(self, hole_data: Dict, line_data: Dict, vertices_data: Dict) -> Optional[trimesh.Trimesh]:
#         """Create a door mesh"""
#         hole_info = self.calculate_hole_position(hole_data, line_data, vertices_data)
#         if not hole_info:
#             return None

#         # Try to load door asset
#         door_mesh = self._load_asset('door')
#         if not door_mesh:
#             # Fallback to simple box
#             door_mesh = trimesh.creation.box(
#                 extents=[hole_info.width, hole_info.height, hole_info.wall_thickness * 0.8]
#             )
#             door_mesh.visual.face_colors = [139, 69, 19, 255]  # Brown

#         return self._position_mesh(door_mesh, hole_info)

#     def _create_window_mesh(self, hole_data: Dict, line_data: Dict, vertices_data: Dict) -> Optional[trimesh.Trimesh]:
#         """Create a window mesh"""
#         hole_info = self.calculate_hole_position(hole_data, line_data, vertices_data)
#         if not hole_info:
#             return None

#         # Try to load window asset
#         window_mesh = self._load_asset('window')
#         if not window_mesh:
#             # Fallback to simple box
#             window_mesh = trimesh.creation.box(
#                 extents=[hole_info.width, hole_info.height, hole_info.wall_thickness * 0.6]
#             )
#             window_mesh.visual.face_colors = [135, 206, 235, 76]  # Semi-transparent blue

#         return self._position_mesh(window_mesh, hole_info)

#     def _position_mesh(self, mesh: trimesh.Trimesh, hole_info: HoleInfo) -> Optional[trimesh.Trimesh]:
#         """Position and scale a mesh based on hole info"""
#         try:
#             # Scale mesh to match hole dimensions
#             bbox = mesh.bounds
#             original_size = bbox[1] - bbox[0]
#             if any(s <= 0 for s in original_size):
#                 return None

#             # Determine thickness factor based on mesh type (detected from metadata or visual)
#             thickness_factor = 0.8 if np.mean(mesh.visual.face_colors[:, :3]) < 200 else 0.6
            
#             scale_factors = np.array([
#                 hole_info.width / original_size[0],
#                 hole_info.height / original_size[1],
#                 (hole_info.wall_thickness * thickness_factor) / original_size[2]
#             ])
#             mesh.apply_scale(scale_factors)

#             # Center mesh at origin
#             mesh.vertices -= mesh.centroid

#             # Rotate to match wall direction
#             angle = math.atan2(hole_info.direction[1], hole_info.direction[0])
#             rotation = trimesh.transformations.rotation_matrix(angle, [0, 1, 0])
#             mesh.apply_transform(rotation)

#             # Position in wall
#             mesh.vertices[:, 0] += hole_info.center[0]
#             mesh.vertices[:, 1] += hole_info.altitude + hole_info.height / 2
#             mesh.vertices[:, 2] += hole_info.center[1]

#             # Add metadata
#             mesh.metadata = {
#                 'source': hole_info.hole_id,
#                 'type': 'door' if thickness_factor == 0.8 else 'window',
#                 'thickness': hole_info.wall_thickness * thickness_factor
#             }

#             return mesh
#         except Exception as e:
#             print(f"Error positioning mesh: {e}")
#             return None

#     def _load_asset(self, asset_type: str) -> Optional[trimesh.Trimesh]:
#         """Load a 3D asset with textures"""
#         try:
#             asset_info = self.assets.get(asset_type)
#             if not asset_info or not os.path.exists(asset_info['obj']):
#                 return None

#             mesh = trimesh.load(asset_info['obj'])
#             if isinstance(mesh, trimesh.Scene):
#                 mesh = next(iter(mesh.geometry.values()))

#             if 'texture' in asset_info and os.path.exists(asset_info['texture']):
#                 try:
#                     diffuse_img = Image.open(asset_info['texture'])
#                     material = trimesh.visual.texture.SimpleMaterial(
#                         image=diffuse_img,
#                         diffuse=[255, 255, 255, 255]
#                     )
#                     if hasattr(mesh.visual, 'uv'):
#                         mesh.visual = trimesh.visual.TextureVisuals(
#                             uv=mesh.visual.uv,
#                             image=diffuse_img,
#                             material=material
#                         )
#                 except Exception as e:
#                     print(f"Error loading texture: {e}")

#             return mesh
#         except Exception as e:
#             print(f"Error loading asset {asset_type}: {e}")
#             return None





import numpy as np
import trimesh
import math
from typing import Dict, Any, Optional, List
from dataclasses import dataclass
from PIL import Image
import os
from trimesh.visual.texture import SimpleMaterial, TextureVisuals
from trimesh.visual.material import PBRMaterial

@dataclass
class HoleInfo:
    center: np.ndarray
    start: np.ndarray
    end: np.ndarray
    direction: np.ndarray
    normal: np.ndarray
    width: float
    height: float
    thickness: float
    altitude: float
    wall_thickness: float
    wall_start: np.ndarray
    wall_end: np.ndarray
    wall_length: float
    hole_id: str

class DoorWindowPlacer:
    def __init__(self, assets_config: Dict[str, Any]):
        self.assets = assets_config

    def cm_to_m(self, value_dict, key='length'):
        """Convert cm to meters - handles both dict and direct values"""
        if isinstance(value_dict, dict):
            return float(value_dict.get(key, 0)) / 100.0
        return float(value_dict or 0) / 100.0

    def calculate_hole_position(self, hole_data: Dict, line_data: Dict, vertices_data: Dict) -> Optional[HoleInfo]:
        """Calculate hole position and dimensions using the same logic as working version"""
        try:
            v_ids = line_data.get('vertices', [])
            if len(v_ids) != 2 or not all(v_id in vertices_data for v_id in v_ids):
                return None

            v1, v2 = vertices_data[v_ids[0]], vertices_data[v_ids[1]]
            p1 = np.array([v1['x']/100.0, -v1['y']/100.0])  # Flip Y coordinate
            p2 = np.array([v2['x']/100.0, -v2['y']/100.0])  # Flip Y coordinate

            vec = p2 - p1
            length = np.linalg.norm(vec)
            if length == 0:
                return None

            direction = vec / length
            normal = np.array([-direction[1], direction[0]])

            # Get hole properties using the same method as working version
            hole_width = self.cm_to_m(hole_data['properties']['width'])
            hole_height = self.cm_to_m(hole_data['properties']['height'])
            hole_thickness = self.cm_to_m(hole_data['properties']['thickness'])
            hole_altitude = self.cm_to_m(hole_data['properties']['altitude'])
            wall_thickness = self.cm_to_m(line_data['properties']['thickness'])
            
            # Calculate offset along the wall (0.0 = start, 1.0 = end)
            offset = hole_data.get('offset', 0.5)
            
            # Calculate hole center position along the wall
            hole_center = p1 + direction * (length * offset)
            
            # Calculate hole bounds along the wall
            hole_start = hole_center - direction * (hole_width / 2 + 0.001)
            hole_end = hole_center + direction * (hole_width / 2 + 0.001)

            return HoleInfo(
                center=hole_center,
                start=hole_start,
                end=hole_end,
                direction=direction,
                normal=normal,
                width=hole_width,
                height=hole_height,
                thickness=max(hole_thickness, wall_thickness),
                altitude=hole_altitude,
                wall_thickness=wall_thickness,
                wall_start=p1,
                wall_end=p2,
                wall_length=length,
                hole_id=hole_data.get('id', '')
            )
        except Exception as e:
            print(f"Error calculating hole position: {e}")
            return None

    def load_door_mesh(self, scale=1.0):
        """Load door mesh with proper material handling"""
        asset_info = self.assets.get('door')
        if not asset_info:
            return None
        
        obj_path = asset_info['obj']
        if not os.path.exists(obj_path):
            print(f"Warning: door OBJ file not found at {obj_path}")
            return None
        
        try:
            mesh = trimesh.load(obj_path, force='mesh')
            if isinstance(mesh, trimesh.Scene):
                mesh = next(iter(mesh.geometry.values()))
            
            mesh.apply_scale(scale)
            
            # Apply textures
            if os.path.exists(asset_info['diffuse']):
                try:
                    diffuse_img = Image.open(asset_info['diffuse'])
                    material = PBRMaterial(
                        name="door_material",
                        baseColorTexture=diffuse_img,
                        doubleSided=True
                    )
                    
                    if hasattr(mesh.visual, 'uv') and mesh.visual.uv is not None:
                        mesh.visual = TextureVisuals(
                            uv=mesh.visual.uv,
                            image=diffuse_img,
                            material=material
                        )
                    else:
                        mesh.visual.material = material
                        
                except Exception as e:
                    print(f"Warning: Could not load texture for door: {e}")
                    mesh.visual.face_colors = [139, 69, 19, 255]
            else:
                mesh.visual.face_colors = [139, 69, 19, 255]
            
            return mesh
            
        except Exception as e:
            print(f"Error loading door mesh: {e}")
            return None

    def load_window_mesh(self, scale=1.0):
        """Load window mesh with proper material handling and transparency"""
        asset_info = self.assets.get('window')
        if not asset_info:
            return None
        
        obj_path = asset_info['obj']
        if not os.path.exists(obj_path):
            print(f"Warning: window OBJ file not found at {obj_path}")
            return None
        
        try:
            mesh = trimesh.load(obj_path, force='mesh')
            if isinstance(mesh, trimesh.Scene):
                mesh = next(iter(mesh.geometry.values()))
            
            mesh.apply_scale(scale)
            
            if os.path.exists(asset_info['diffuse']):
                try:
                    diffuse_img = Image.open(asset_info['diffuse'])
                    
                    if diffuse_img.mode not in ('RGBA', 'LA'):
                        diffuse_img = diffuse_img.convert('RGBA')
                    
                    # Calculate transparency
                    alpha_channel = diffuse_img.getchannel('A')
                    alpha_array = np.array(alpha_channel)
                    alpha_factor = np.mean(alpha_array) / 255.0
                    
                    material = PBRMaterial(
                        name="window_material",
                        baseColorTexture=diffuse_img,
                        baseColorFactor=[1.0, 1.0, 1.0, alpha_factor],
                        alphaMode='BLEND',
                        doubleSided=True
                    )
                    
                    if hasattr(mesh.visual, 'uv') and mesh.visual.uv is not None:
                        mesh.visual = TextureVisuals(
                            uv=mesh.visual.uv,
                            image=diffuse_img,
                            material=material
                        )
                    else:
                        mesh.visual.material = material
                        
                except Exception as e:
                    print(f"Warning: Could not load texture for window: {e}")
                    mesh.visual.face_colors = [135, 206, 235, 76]
            else:
                mesh.visual.face_colors = [135, 206, 235, 76]
            
            return mesh
            
        except Exception as e:
            print(f"Error loading window mesh: {e}")
            return None

    def create_door_window_meshes(self, holes_data: Dict, lines_data: Dict, vertices_data: Dict) -> List[trimesh.Trimesh]:
        """Create all door and window meshes using the exact same logic as working version"""
        print("Creating door and window meshes...")
        
        door_meshes = []
        window_meshes = []
        
        for hole_id, hole_data in holes_data.items():
            line_id = hole_data.get('line')
            if not line_id or line_id not in lines_data:
                print(f"  -> Skipping hole {hole_id}: no valid line reference")
                continue
                
            line_data = lines_data[line_id]
            hole_type = hole_data.get('type', '').lower()
            
            try:
                if 'door' in hole_type:
                    door_mesh = self._create_door_mesh(hole_data, line_data, vertices_data)
                    if door_mesh:
                        door_meshes.append(door_mesh)
                        print(f"  -> Created door: {hole_id}")
                elif 'window' in hole_type:
                    window_mesh = self._create_window_mesh(hole_data, line_data, vertices_data)
                    if window_mesh:
                        window_meshes.append(window_mesh)
                        print(f"  -> Created window: {hole_id}")
            except Exception as e:
                print(f"  -> Error creating {hole_type} {hole_id}: {e}")

        return door_meshes + window_meshes

    def _create_door_mesh(self, hole_data: Dict, line_data: Dict, vertices_data: Dict) -> Optional[trimesh.Trimesh]:
        """Create door mesh using exact same logic as working version"""
        hole_info_dict = self.calculate_hole_position(hole_data, line_data, vertices_data)
        if not hole_info_dict:
            return None

        # Convert dict to values for compatibility
        hole_info = {
            'center': hole_info_dict.center,
            'start': hole_info_dict.start,
            'end': hole_info_dict.end,
            'direction': hole_info_dict.direction,
            'normal': hole_info_dict.normal,
            'width': hole_info_dict.width,
            'height': hole_info_dict.height,
            'thickness': hole_info_dict.thickness,
            'altitude': hole_info_dict.altitude,
            'wall_thickness': hole_info_dict.wall_thickness
        }

        door_mesh = self.load_door_mesh()
        if not door_mesh:
            door_mesh = trimesh.creation.box(
                extents=[hole_info['width'], hole_info['height'], hole_info['wall_thickness']]
            )
            door_mesh.visual.face_colors = [139, 69, 19, 255]

        bbox = door_mesh.bounds
        original_size = bbox[1] - bbox[0]
        if any(s <= 0 for s in original_size):
            return None

        # Calculate reduced thickness for door
        door_thickness = hole_info['wall_thickness'] * 0.8
        
        scale_factors = np.array([
            hole_info['width'] / original_size[0],
            hole_info['height'] / original_size[1],
            door_thickness / original_size[2]
        ])
        door_mesh.apply_scale(scale_factors)

        # Center mesh at origin
        door_mesh.vertices -= door_mesh.centroid

        # Rotate to match wall direction
        angle = math.atan2(hole_info['direction'][1], hole_info['direction'][0])
        rotation = trimesh.transformations.rotation_matrix(angle, [0, 1, 0])
        door_mesh.apply_transform(rotation)

        # Final positioning
        door_mesh.vertices[:, 0] += hole_info['center'][0]
        door_mesh.vertices[:, 1] += hole_info['altitude'] + hole_info['height'] / 2
        door_mesh.vertices[:, 2] += hole_info['center'][1]

        # Store metadata
        door_mesh.metadata = {
            'source': hole_data['id'], 
            'type': 'door',
            'door_thickness': door_thickness,
            'wall_thickness': hole_info['wall_thickness']
        }

        return door_mesh

    def _create_window_mesh(self, hole_data: Dict, line_data: Dict, vertices_data: Dict) -> Optional[trimesh.Trimesh]:
        """Create window mesh using exact same logic as working version"""
        hole_info_dict = self.calculate_hole_position(hole_data, line_data, vertices_data)
        if not hole_info_dict:
            return None

        # Convert dict to values for compatibility
        hole_info = {
            'center': hole_info_dict.center,
            'start': hole_info_dict.start,
            'end': hole_info_dict.end,
            'direction': hole_info_dict.direction,
            'normal': hole_info_dict.normal,
            'width': hole_info_dict.width,
            'height': hole_info_dict.height,
            'thickness': hole_info_dict.thickness,
            'altitude': hole_info_dict.altitude,
            'wall_thickness': hole_info_dict.wall_thickness
        }

        window_mesh = self.load_window_mesh()
        if not window_mesh:
            window_mesh = trimesh.creation.box(
                extents=[hole_info['width'], hole_info['height'], hole_info['wall_thickness']]
            )
            window_mesh.visual.face_colors = [135, 206, 235, 76]

        bbox = window_mesh.bounds
        original_size = bbox[1] - bbox[0]
        if any(s <= 0 for s in original_size):
            return None

        # Calculate reduced thickness for window
        window_thickness = hole_info['wall_thickness'] * 0.6

        scale_factors = np.array([
            hole_info['width'] / original_size[0],
            hole_info['height'] / original_size[1],
            window_thickness / original_size[2]
        ])
        window_mesh.apply_scale(scale_factors)

        # Center mesh at origin
        window_mesh.vertices -= window_mesh.centroid

        # Rotate to align with wall
        angle = math.atan2(hole_info['direction'][1], hole_info['direction'][0])
        rotation = trimesh.transformations.rotation_matrix(angle, [0, 1, 0])
        window_mesh.apply_transform(rotation)

        # Position window
        window_mesh.vertices[:, 0] += hole_info['center'][0]
        window_mesh.vertices[:, 1] += hole_info['altitude'] + hole_info['height'] / 2
        window_mesh.vertices[:, 2] += hole_info['center'][1]

        # Store metadata
        window_mesh.metadata = {
            'source': hole_data['id'], 
            'type': 'window',
            'window_thickness': window_thickness,
            'wall_thickness': hole_info['wall_thickness']
        }

        return window_mesh

    def _load_asset(self, asset_type: str) -> Optional[trimesh.Trimesh]:
        """Load a 3D asset with textures - use the specific load functions"""
        if asset_type == 'door':
            return self.load_door_mesh()
        elif asset_type == 'window':
            return self.load_window_mesh()
        else:
            return None

    def _position_mesh(self, mesh: trimesh.Trimesh, hole_info: HoleInfo) -> Optional[trimesh.Trimesh]:
        """Position and scale a mesh based on hole info - this is now handled by create_door_mesh/create_window_mesh"""
        # This method is kept for compatibility but the logic is moved to specific mesh creation methods
        return mesh