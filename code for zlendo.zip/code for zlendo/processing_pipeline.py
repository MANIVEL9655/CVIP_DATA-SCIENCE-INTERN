# processing_pipeline.py

import logging
import os
import json
import time
from collections import OrderedDict
from datetime import datetime
from database_manager import db_manager
from ai_engine_controller import AIEngineController
from global_detector import GlobalDetector
from geometric_refiner import GeometricRefiner
from spatial_optimizer import SpatialOptimizer
from final_validator import WallConstructor
from visualization_service import VisualizationService
from models import ProjectStatus, SessionStatus

logger = logging.getLogger(__name__)

# Get exports directory from environment or use default
EXPORTS_DIRECTORY = os.getenv("EXPORTS_PATH", "exports")
os.makedirs(EXPORTS_DIRECTORY, exist_ok=True)

def create_2layer_export_file(session_id: int, final_json: dict) -> str:
    """
    Create the 2layer export file and return the file path.
    This function handles the file creation and formatting.
    """
    try:
        # Ensure we have the proper structure
        if "layers" not in final_json or "layer-1" not in final_json["layers"]:
            raise ValueError("Missing layers or layer-1 in final JSON")

        layer = final_json["layers"]["layer-1"]

        # Construct final JSON with exact field order for 2layer compatibility
        export_json = OrderedDict()
        export_json["unit"] = "cm"
        export_json["layers"] = {
            "layer-1": OrderedDict({
                "id": "layer-1",
                "altitude": 0,
                "order": 0,
                "opacity": 1,
                "name": "default",
                "visible": True,
                "vertices": layer.get("vertices", {}),
                "lines": layer.get("lines", {}),
                "holes": layer.get("holes", {}),
                "items": layer.get("items", {}),
                "areas": layer.get("areas", {})
            })
        }
        export_json["grids"] = {
            "h1": {
                "id": "h1",
                "type": "horizontal-streak",
                "properties": {
                    "step": 20,
                    "colors": ["#808080", "#ddd", "#ddd", "#ddd", "#ddd"]
                }
            },
            "v1": {
                "id": "v1",
                "type": "vertical-streak",
                "properties": {
                    "step": 20,
                    "colors": ["#808080", "#ddd", "#ddd", "#ddd", "#ddd"]
                }
            }
        }
        export_json["selectedLayer"] = "layer-1"
        export_json["groups"] = {}
        export_json["width"] = 4000
        export_json["height"] = 4000
        export_json["meta"] = {
            "generated_by": "AI_Processing_Pipeline_v2.1",
            "session_id": session_id,
            "export_timestamp": datetime.now().isoformat(),
            "format_version": "2.1"
        }
        export_json["guides"] = {
            "horizontal": {},
            "vertical": {},
            "circular": {}
        }

        # Save the export file
        export_file_path = os.path.join(EXPORTS_DIRECTORY, f"session_{session_id}_final.json")
        
        with open(export_file_path, "w") as f:
            json.dump(export_json, f, indent=2)
        
        logger.info(f"Export file created: {export_file_path}")
        return export_file_path

    except Exception as e:
        logger.error(f"Failed to create export file for session {session_id}: {e}", exc_info=True)
        raise


def run_complete_pipeline_sync(project_id: int, image_path: str, config: dict) -> dict:
    """
    Runs the complete processing pipeline synchronously and returns the result.
    This function blocks until the entire pipeline is completed.
    
    Returns:
        dict: {
            "success": bool,
            "session_id": int,
            "stages_completed": int,
            "processing_time_seconds": float,
            "export_file_path": str (if successful),
            "error_message": str (if failed)
        }
    """
    start_time = time.time()
    session_id = None
    stages_completed = 0
    
    # Initialize components
    ai_engine = AIEngineController(db_manager)
    detector = GlobalDetector(ai_engine, db_manager)
    refiner = GeometricRefiner(db_manager)
    optimizer = SpatialOptimizer(db_manager)
    validator = WallConstructor(db_manager)
    visualizer = VisualizationService()

    try:
        # 1. Create a Processing Session
        with db_manager.get_session() as db:
            session = db_manager.create_processing_session(
                db, project_id, config.get("ai_model_flags", {}), config.get("processing_config", {})
            )
            session_id = session.id
            db_manager.update_project_status(db, project_id, ProjectStatus.PROCESSING)
            db_manager.update_session_status(db, session_id, SessionStatus.PROCESSING, current_stage=1)
        logger.info(f"Pipeline started for session ID: {session_id}")

        # 2. Stage 1: Global Detection
        logger.info(f"Starting Stage 1: Global Detection for session {session_id}")
        with db_manager.get_session() as db:
            stage1_result = detector.process(session_id, image_path, config.get("ai_model_flags", {}))
        global_json = stage1_result['json_output']
        visualizer.visualize_stage(session_id, "01_global_detection", global_json)
        with db_manager.get_session() as db:
            db_manager.update_session_status(db, session_id, SessionStatus.PROCESSING, current_stage=2)
        stages_completed = 1
        logger.info(f"Stage 1 (Global Detection) completed for session {session_id}")

        # 3. Stage 2: Geometric Refinement
        logger.info(f"Starting Stage 2: Geometric Refinement for session {session_id}")
        with db_manager.get_session() as db:
            stage2_result = refiner.process(db, session_id, global_json)
        refined_json = stage2_result['json_output']
        visualizer.visualize_stage(session_id, "02_geometric_refinement", refined_json)
        with db_manager.get_session() as db:
            db_manager.update_session_status(db, session_id, SessionStatus.PROCESSING, current_stage=3)
        stages_completed = 2
        logger.info(f"Stage 2 (Geometric Refinement) completed for session {session_id}")

        # 4. Stage 3: Spatial Optimization
        logger.info(f"Starting Stage 3: Spatial Optimization for session {session_id}")
        with db_manager.get_session() as db:
            stage3_result = optimizer.process_stage(session_id, refined_json)
        optimized_json = stage3_result['json_output']
        visualizer.visualize_stage(session_id, "03_spatial_optimization", optimized_json)
        with db_manager.get_session() as db:
            db_manager.update_session_status(db, session_id, SessionStatus.PROCESSING, current_stage=4)
        stages_completed = 3
        logger.info(f"Stage 3 (Spatial Optimization) completed for session {session_id}")

        # 5. Stage 4: Final Validation and Conversion
        logger.info(f"Starting Stage 4: Final Validation for session {session_id}")
        with db_manager.get_session() as db:
            # final_2layer_json = validator.process_stage(session_id, optimized_json)
            # final_2layer_json = validator.process_stage_with_t_junctions(session_id, optimized_json)
            final_2layer_json = validator.process_stage_final(session_id, optimized_json)

            # Save Stage 4 JSON to the database
            stage4 = db_manager.create_json_stage(
                db,
                session_id=session_id,
                stage_number=4,
                stage_name="final_validation",
                stage_type="local",
                input_json=optimized_json
            )

            db_manager.update_json_stage(
                db,
                stage_id=stage4.id,
                update_data={
                    "output_json": final_2layer_json,
                    "status": "completed"
                }
            )

        # Final visualization
        visualizer.visualize_final_2layer(session_id, final_2layer_json)
        stages_completed = 4
        logger.info(f"Stage 4 (Final Validation) completed for session {session_id}")

        # 6. Create Export File and Update Database
        logger.info(f"Creating export file for session {session_id}")
        export_file_path = create_2layer_export_file(session_id, final_2layer_json)
        file_size_bytes = os.path.getsize(export_file_path) if os.path.exists(export_file_path) else 0
        
        # Update session with export information
        with db_manager.get_session() as db:
            from repositories import ProcessingSessionRepository
            session_repo = ProcessingSessionRepository(db)
            session_repo.update_export_info(
                session_id=session_id,
                export_file_path=export_file_path,
                export_file_size_bytes=file_size_bytes,
                export_format_version="2.1"
            )
        
        logger.info(f"Export file created and database updated: {export_file_path} ({file_size_bytes} bytes)")

        # 7. Finalize Session and Project Status
        with db_manager.get_session() as db:
            db_manager.update_session_status(db, session_id, SessionStatus.COMPLETED, current_stage=4)
            db_manager.update_project_status(db, project_id, ProjectStatus.COMPLETED)
        
        processing_time = time.time() - start_time
        logger.info(f"Pipeline successfully completed for session ID: {session_id} in {processing_time:.2f} seconds")

        return {
            "success": True,
            "session_id": session_id,
            "stages_completed": stages_completed,
            "processing_time_seconds": round(processing_time, 2),
            "export_file_path": export_file_path
        }

    except Exception as e:
        processing_time = time.time() - start_time
        error_message = str(e)
        logger.error(f"Pipeline failed for project {project_id}: {error_message}", exc_info=True)
        
        if session_id:
            with db_manager.get_session() as db:
                db_manager.update_session_status(db, session_id, SessionStatus.FAILED)
                db_manager.update_project_status(db, project_id, ProjectStatus.FAILED)
                db_manager.save_debug_log(db, session_id, 'critical', 'PipelineCoordinator', f"Pipeline failed: {error_message}")

        return {
            "success": False,
            "session_id": session_id,
            "stages_completed": stages_completed,
            "processing_time_seconds": round(processing_time, 2),
            "error_message": error_message
        }


def run_full_pipeline(project_id: int, image_path: str, config: dict):
    """
    Original function - creates session then runs pipeline (asynchronous).
    Kept for backward compatibility with other parts of the system.
    """
    # Initialize components
    ai_engine = AIEngineController(db_manager)
    detector = GlobalDetector(ai_engine, db_manager)
    refiner = GeometricRefiner(db_manager)
    optimizer = SpatialOptimizer(db_manager)
    validator = WallConstructor(db_manager)
    visualizer = VisualizationService()

    session_id = None

    try:
        # 1. Create a Processing Session
        with db_manager.get_session() as db:
            session = db_manager.create_processing_session(
                db, project_id, config.get("ai_model_flags", {}), config.get("processing_config", {})
            )
            session_id = session.id
            db_manager.update_project_status(db, project_id, ProjectStatus.PROCESSING)
            db_manager.update_session_status(db, session_id, SessionStatus.PROCESSING, current_stage=1)
        logger.info(f"Pipeline started for session ID: {session_id}")

        # 2. Stage 1: Global Detection
        with db_manager.get_session() as db:
            stage1_result = detector.process(session_id, image_path, config.get("ai_model_flags", {}))
        global_json = stage1_result['json_output']
        visualizer.visualize_stage(session_id, "01_global_detection", global_json)
        with db_manager.get_session() as db:
            db_manager.update_session_status(db, session_id, SessionStatus.PROCESSING, current_stage=2)
        logger.info(f"Stage 1 (Global Detection) completed for session {session_id}")

        # 3. Stage 2: Geometric Refinement
        with db_manager.get_session() as db:
            stage2_result = refiner.process(db, session_id, global_json)
        refined_json = stage2_result['json_output']
        visualizer.visualize_stage(session_id, "02_geometric_refinement", refined_json)
        with db_manager.get_session() as db:
            db_manager.update_session_status(db, session_id, SessionStatus.PROCESSING, current_stage=3)
        logger.info(f"Stage 2 (Geometric Refinement) completed for session {session_id}")

        # 4. Stage 3: Spatial Optimization
        with db_manager.get_session() as db:
            stage3_result = optimizer.process_stage(session_id, refined_json)
        optimized_json = stage3_result['json_output']
        visualizer.visualize_stage(session_id, "03_spatial_optimization", optimized_json)
        with db_manager.get_session() as db:
            db_manager.update_session_status(db, session_id, SessionStatus.PROCESSING, current_stage=4)
        logger.info(f"Stage 3 (Spatial Optimization) completed for session {session_id}")

        # 5. Stage 4: Final Validation and Conversion
        with db_manager.get_session() as db:
            final_2layer_json = validator.process_stage(session_id, optimized_json)

            # Save Stage 4 JSON to the database
            stage4 = db_manager.create_json_stage(
                db,
                session_id=session_id,
                stage_number=4,
                stage_name="final_validation",
                stage_type="local",
                input_json=optimized_json
            )

            db_manager.update_json_stage(
                db,
                stage_id=stage4.id,
                update_data={
                    "output_json": final_2layer_json,
                    "status": "completed"
                }
            )

        # Final visualization
        visualizer.visualize_final_2layer(session_id, final_2layer_json)
        logger.info(f"Stage 4 (Final Validation) completed for session {session_id}")

        # 6. Create Export File and Update Database
        try:
            export_file_path = create_2layer_export_file(session_id, final_2layer_json)
            file_size_bytes = os.path.getsize(export_file_path) if os.path.exists(export_file_path) else 0
            
            # Update session with export information
            with db_manager.get_session() as db:
                from repositories import ProcessingSessionRepository
                session_repo = ProcessingSessionRepository(db)
                session_repo.update_export_info(
                    session_id=session_id,
                    export_file_path=export_file_path,
                    export_file_size_bytes=file_size_bytes,
                    export_format_version="2.1"
                )
            
            logger.info(f"Export file created and database updated: {export_file_path} ({file_size_bytes} bytes)")
            
        except Exception as e:
            logger.error(f"Failed to create export file, but pipeline completed: {e}")
            # Don't fail the entire pipeline if export creation fails

        # 7. Finalize Session and Project Status
        with db_manager.get_session() as db:
            db_manager.update_session_status(db, session_id, SessionStatus.COMPLETED, current_stage=4)
            db_manager.update_project_status(db, project_id, ProjectStatus.COMPLETED)
        logger.info(f"Pipeline successfully completed for session ID: {session_id}")

    except Exception as e:
        logger.error(f"Pipeline failed for project {project_id}: {e}", exc_info=True)
        if session_id:
            with db_manager.get_session() as db:
                db_manager.update_session_status(db, session_id, SessionStatus.FAILED)
                db_manager.update_project_status(db, project_id, ProjectStatus.FAILED)
                db_manager.save_debug_log(db, session_id, 'critical', 'PipelineCoordinator', f"Pipeline failed: {e}")


# Additional utility functions for session management

def get_session_progress(session_id: int) -> dict:
    """
    Get the current progress of a processing session.
    Useful for frontend progress tracking.
    """
    try:
        with db_manager.get_session() as db:
            from repositories import ProcessingSessionRepository
            session_repo = ProcessingSessionRepository(db)
            session = session_repo.get_by_id(session_id)
            
            if not session:
                return {"error": "Session not found"}
            
            stage_names = {
                1: "Global Detection",
                2: "Geometric Refinement", 
                3: "Spatial Optimization",
                4: "Final Validation"
            }
            
            progress_percentage = 0
            if session.status == SessionStatus.COMPLETED:
                progress_percentage = 100
            elif session.status == SessionStatus.PROCESSING:
                progress_percentage = (session.current_stage - 1) * 25
            elif session.status == SessionStatus.FAILED:
                progress_percentage = 0
            
            return {
                "session_id": session.id,
                "status": session.status.value,
                "current_stage": session.current_stage,
                "current_stage_name": stage_names.get(session.current_stage, "Unknown"),
                "progress_percentage": progress_percentage,
                "created_at": session.created_at,
                "updated_at": session.updated_at,
                "export_available": bool(session.export_file_path and os.path.exists(session.export_file_path))
            }
            
    except Exception as e:
        logger.error(f"Error getting session progress for {session_id}: {e}")
        return {"error": f"Failed to get progress: {str(e)}"}


def cleanup_failed_session(session_id: int) -> bool:
    """
    Clean up resources from a failed processing session.
    """
    try:
        with db_manager.get_session() as db:
            from repositories import ProcessingSessionRepository
            session_repo = ProcessingSessionRepository(db)
            session = session_repo.get_by_id(session_id)
            
            if not session:
                return False
                
            # Clean up any partial export files
            if session.export_file_path and os.path.exists(session.export_file_path):
                try:
                    os.remove(session.export_file_path)
                    logger.info(f"Cleaned up partial export file: {session.export_file_path}")
                except Exception as e:
                    logger.warning(f"Failed to clean up export file: {e}")
            
            # Update session to mark cleanup complete
            session_repo.update_export_info(
                session_id=session_id,
                export_file_path=None,
                export_file_size_bytes=0,
                export_format_version=None
            )
            
            logger.info(f"Cleanup completed for failed session {session_id}")
            return True
            
    except Exception as e:
        logger.error(f"Error during session cleanup {session_id}: {e}")
        return False


def retry_failed_session(project_id: int, failed_session_id: int, config: dict) -> int:
    """
    Retry a failed processing session with a new session.
    Returns the new session ID.
    """
    try:
        # Get project info
        with db_manager.get_session() as db:
            from repositories import ProjectRepository
            project_repo = ProjectRepository(db)
            project = project_repo.get_by_id(project_id)
            
            if not project:
                raise ValueError(f"Project {project_id} not found")
            
            if not project.original_image_path or not os.path.exists(project.original_image_path):
                raise ValueError("Project image file not found")
            
            # Clean up the failed session
            cleanup_failed_session(failed_session_id)
            
            # Create new session
            new_session = db_manager.create_processing_session(
                db, 
                project_id, 
                config.get("ai_model_flags", {}), 
                config.get("processing_config", {})
            )
            
            logger.info(f"Created retry session {new_session.id} for failed session {failed_session_id}")
            
            return new_session.id
            
    except Exception as e:
        logger.error(f"Error retrying failed session {failed_session_id}: {e}")
        raise