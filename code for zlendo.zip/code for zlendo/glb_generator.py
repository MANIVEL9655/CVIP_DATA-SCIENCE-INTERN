import os
import json
import numpy as np
import trimesh
import math
import requests
import tempfile
from typing import Dict, Any, List, Optional
from pathlib import Path
from shapely.geometry import Polygon, MultiPolygon, Point
from shapely.ops import unary_union
from PIL import Image
from trimesh.visual.texture import SimpleMaterial, TextureVisuals
from trimesh.visual.material import PBRMaterial
from azure.storage.blob import BlobServiceClient

# Azure Blob Storage Configuration
# AZURE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=zrealtystoragedev;AccountKey=i9DcV7twOLmapWQmZb7Lsit42H51U7SwIzvPIlXgxLR55nQWKonsOpVLm+/80DtEEeKv4dqkewF1+AStQA197Q==;EndpointSuffix=core.windows.net"
ASSETS_API_URL = "http://103.16.202.150:4456/assets/"

# Use the same asset paths structure as the working version
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

ASSET_PATHS = {
    'door': {
        'obj': os.path.join(BASE_DIR, 'door', 'Z_door.obj'),
        'mtl': os.path.join(BASE_DIR, 'door', 'Z_door.mtl'),
        'diffuse': os.path.join(BASE_DIR, 'door', 'texture 1.png'),
        'normal': os.path.join(BASE_DIR, 'door', 'thumbnail.png')
    },
    'window': {
        'obj': os.path.join(BASE_DIR, 'window', 'Z_Window4.obj'),
        'mtl': os.path.join(BASE_DIR, 'window', 'Z_Window4.mtl'),
        'diffuse': os.path.join(BASE_DIR, 'window', 'Z_Window4_texture.png'),
        'normal': os.path.join(BASE_DIR, 'window', 'Z_Window4.png')
    },
    # 'wall_outer': {
    #     'diffuse': os.path.join(BASE_DIR, 'wall', 'painted.jpg'),
    #     'normal': os.path.join(BASE_DIR, 'wall', 'painted-normal.jpg')
    # },
    'wall_outer': {
        'diffuse': os.path.join(BASE_DIR, 'wall', 'Z_Brickwall.png'),
        'normal': os.path.join(BASE_DIR, 'wall', 'Z_Brickwall_Normal.png')
    },
    'wall_inner': {
        'diffuse': os.path.join(BASE_DIR, 'wall', 'Z_Brickwall.png'),
        'normal': os.path.join(BASE_DIR, 'wall', 'Z_Brickwall_Normal.png')
    }
}

def sanitize_mesh(mesh: trimesh.Trimesh) -> trimesh.Trimesh:
    """
    Clean up a mesh to avoid NaN in glTF export.
    """
    # Fix vertices
    if mesh.vertices is not None:
        mesh.vertices = np.nan_to_num(mesh.vertices, nan=0.0, posinf=0.0, neginf=0.0)

    # Fix normals
    if mesh.vertex_normals is not None and len(mesh.vertex_normals) > 0:
        mesh.vertex_normals = np.nan_to_num(mesh.vertex_normals, nan=0.0, posinf=0.0, neginf=0.0)
        norms = np.linalg.norm(mesh.vertex_normals, axis=1)
        bad = norms == 0
        if bad.any():
            mesh.vertex_normals[bad] = [0, 0, 1]

    # Fix faces
    if mesh.faces is not None:
        valid_faces = ~np.any(np.isnan(mesh.faces), axis=1)
        mesh.faces = mesh.faces[valid_faces]

    mesh.remove_unreferenced_vertices()
    return mesh

class AzureAssetManager:
    def __init__(self, connection_string: str, assets_api_url: str):
        self.connection_string = connection_string
        self.assets_api_url = assets_api_url
        conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
        if not conn_str:
            raise ValueError("Missing AZURE_STORAGE_CONNECTION_STRING environment variable")
        self.assets_api_url = assets_api_url
        self.blob_service_client = BlobServiceClient.from_connection_string(conn_str)
        # self.blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        self.temp_dir = tempfile.mkdtemp()
        self.downloaded_assets = {}
        self.assets_data = {}
        
    def authenticate_and_get_assets(self):
        """Authenticate and fetch assets data from the API"""
        try:
            print("Authenticating with API...")
            
            # Login to get access token
            login_resp = requests.post(
                "http://103.16.202.150:4456/auth/login",
                data={"username": "Zlendo", "password": "Zlendo@123"},
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=10
            )
            login_resp.raise_for_status()
            token = login_resp.json().get("access_token")
            
            if not token:
                raise ValueError("No access_token returned from login API")
            
            # Get API key
            api_key_resp = requests.get(
                "http://103.16.202.150:4456/users/me/api-key",
                headers={"Authorization": f"Bearer {token}"},
                timeout=10
            )
            api_key_resp.raise_for_status()
            api_key_json = api_key_resp.json()
            
            # Handle possible API key formats
            if isinstance(api_key_json, str):
                api_key = api_key_json.strip()
            elif isinstance(api_key_json, dict):
                api_key = api_key_json.get("api_key") or api_key_json.get("X-API-Key")
            elif isinstance(api_key_json, list) and api_key_json:
                api_key = api_key_json[0].get("api_key") or api_key_json[0].get("X-API-Key")
            else:
                api_key = None
                
            if not api_key:
                raise ValueError("Could not find API key in response")
            
            # Fetch assets
            response = requests.get(
                self.assets_api_url,
                headers={"X-API-Key": api_key},
                timeout=10
            )
            response.raise_for_status()
            self.assets_data = {item["3D_asset_name"]: item for item in response.json()}
            
            print(f"Successfully loaded {len(self.assets_data)} assets from API")
            return True
            
        except Exception as e:
            print(f"Failed to authenticate and get assets: {e}")
            return False
    
    # def download_blob_file(self, blob_url: str, local_filename: str) -> Optional[str]:
    #     """Download a file from Azure Blob Storage"""
    #     try:
    #         # Extract container and blob name from URL
    #         url_parts = blob_url.split('/')
    #         container_name = url_parts[-3]  # Should be '3dassets'
    #         blob_name = '/'.join(url_parts[-2:])  # path/to/file
            
    #         blob_client = self.blob_service_client.get_blob_client(
    #             container=container_name, 
    #             blob=blob_name
    #         )
            
    #         local_path = os.path.join(self.temp_dir, local_filename)
    #         os.makedirs(os.path.dirname(local_path), exist_ok=True)
            
    #         with open(local_path, "wb") as download_file:
    #             download_file.write(blob_client.download_blob().readall())
            
    #         return local_path
            
    #     except Exception as e:
    #         print(f"Error downloading {blob_url}: {e}")
    #         return None


    def download_blob_file(self, blob_url: str, local_filename: str) -> Optional[str]:
        """Download a file from Azure Blob Storage"""
        try:
            # --- START of CORRECTION ---
            # The container is always '3dassets'. The blob name is the path after that.
            container_name = '3dassets'
            
            # Find the beginning of the path part of the URL
            path_start_index = blob_url.find(f"/{container_name}/")
            if path_start_index == -1:
                print(f"Could not parse blob URL: {blob_url}")
                return None
                
            # The blob name is everything after '/3dassets/'
            blob_name = blob_url[path_start_index + len(f"/{container_name}/"):]
            # --- END of CORRECTION ---

            blob_client = self.blob_service_client.get_blob_client(
                container=container_name,
                blob=blob_name
            )

            local_path = os.path.join(self.temp_dir, local_filename)
            os.makedirs(os.path.dirname(local_path), exist_ok=True)

            with open(local_path, "wb") as download_file:
                download_file.write(blob_client.download_blob().readall())

            return local_path

        except Exception as e:
            print(f"Error downloading {blob_url}: {e}")
            return None
    
    def get_asset_files(self, asset_name: str) -> Dict[str, str]:
        """Download and return local paths for asset files"""
        if asset_name in self.downloaded_assets:
            return self.downloaded_assets[asset_name]
        
        if asset_name not in self.assets_data:
            return {}
        
        asset_info = self.assets_data[asset_name]
        file_paths = asset_info.get("3D_asset_file_paths_urls", {})
        metadata = asset_info.get("3D_asset_metadata", {})
        
        local_paths = {}
        
        # Download OBJ file
        if file_paths.get("OBJ_File_URL"):
            obj_path = self.download_blob_file(
                file_paths["OBJ_File_URL"], 
                f"{asset_name}/{asset_name}.obj"
            )
            if obj_path:
                local_paths["obj"] = obj_path
        
        # Download MTL file
        if file_paths.get("MTL_File_URL"):
            mtl_path = self.download_blob_file(
                file_paths["MTL_File_URL"], 
                f"{asset_name}/{asset_name}.mtl"
            )
            if mtl_path:
                local_paths["mtl"] = mtl_path
        
        # Download texture
        if metadata.get("texture_url"):
            texture_path = self.download_blob_file(
                metadata["texture_url"], 
                f"{asset_name}/{asset_name}_texture.png"
            )
            if texture_path:
                local_paths["texture"] = texture_path
        
        # Download thumbnail
        if asset_info.get("2D_asset_thumbnail_url"):
            thumb_path = self.download_blob_file(
                asset_info["2D_asset_thumbnail_url"], 
                f"{asset_name}/{asset_name}_thumb.png"
            )
            if thumb_path:
                local_paths["thumbnail"] = thumb_path
        
        self.downloaded_assets[asset_name] = local_paths
        return local_paths
    
    def get_asset_dimensions(self, asset_name: str) -> Dict[str, float]:
        """Get asset dimensions in meters"""
        if asset_name not in self.assets_data:
            return {"width": 1.0, "height": 1.0, "depth": 1.0}
        
        metadata = self.assets_data[asset_name].get("3D_asset_metadata", {})
        dimensions = metadata.get("dimensions", {})
        
        return {
            "width": float(dimensions.get("width", 100)) / 100.0,  # Convert cm to m
            "height": float(dimensions.get("height", 100)) / 100.0,
            "depth": float(dimensions.get("thickness", 100)) / 100.0
        }

class GLBGenerator:
    def __init__(self, assets_config: Dict[str, Any] = None):
        self.assets = assets_config or ASSET_PATHS
        conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
        # self.azure_manager = AzureAssetManager(AZURE_CONNECTION_STRING, ASSETS_API_URL)
        self.azure_manager = AzureAssetManager(conn_str, ASSETS_API_URL)
        
        # Initialize Azure assets
        if not self.azure_manager.authenticate_and_get_assets():
            print("Warning: Could not load Azure assets, using fallback assets only")
        
        # Original class mapping with added fallbacks to ensure completeness
        self.class_mapping = {
            "wall": "wall", "door": "Z_Door3", "window": "Z_Window4",
            "table": ["Z_Table1", "Z_Table2", "Z_Table3"],
            "dining": "Z_Diningset",
            "sofa": ["Z_Sofa1", "Z_Sofa2"],
            "sink": ["Z_Kitchensink", "Z_Sink", "Z_Sinkandcabinet"],
            "bathtub": ["Z_Bathtub1", "Z_Bathtub2"],
            "western_t": "Z_ToiletW",
            "indian_t": "Z_ToiletI",
            "stove": "Z_Stove",
            "cabinet": "Z_Cabinets",
            "fridge": ["Z_Fridge", "Z_Fridge2"],
            "cupboard": "Z_Cupboard",
            "flower_pot": "Z_Flowerpot",
            "w_machine": "Z_Washingmachine",
            "tv": "Z_TV",
            "ac": "Z_AC",
            "steps": "Z_Steps",
            "chair": ["Z_Chair1", "Z_Chair2", "Z_Chair3", "Z_Chair4", "Z_Chair5"],
            "balcony": ["Z_Balcony1", "Z_Balcony2"],
            "armchair": ["Z_Armchair1", "Z_Armchair2", "Z_Armchair3", "Z_Armchair4", "Z_Armchair5"],
            "bed": ["Z_Bed1", "Z_Bed2", "Z_Bed3"],
            "bedside_table": "Z_Bedsidetable1",
            "flower_vase": "Z_Flowervase",
            "urinal": "Z_Urinal",
            "treadmill": "Z_Treadmill",
            "man": "Z_Man"
        }
        
        # --- NEW: Create a reverse mapping for specific asset names ---
        self.reverse_class_mapping = {}
        for generic_name, asset_list in self.class_mapping.items():
            if isinstance(asset_list, str):
                asset_list = [asset_list]
            for asset_name in asset_list:
                # Store it lowercase for case-insensitive matching
                self.reverse_class_mapping[asset_name.lower()] = asset_name
        
        # Add original single-value mappings to the reverse map as well for robustness
        # This handles cases like 'z_toiletw' which may not be in a list
        for key, value in self.class_mapping.items():
            if isinstance(value, str) and value.lower() not in self.reverse_class_mapping:
                 self.reverse_class_mapping[value.lower()] = value
        
        # Add keys themselves if they look like asset names
        for key in self.class_mapping.keys():
            if key.startswith('z_') and key not in self.reverse_class_mapping:
                self.reverse_class_mapping[key] = self.class_mapping[key]
        # --- END NEW ---

        # Wall proximity rules for furniture placement
        self.wall_placement_rules = {
            # Existing rules
            "Z_Bed1": {"min_wall_distance": 30, "preferred_wall_distance": 50, "can_touch_wall": True},
            "Z_Sofa1": {"min_wall_distance": 20, "preferred_wall_distance": 40, "can_touch_wall": True},
            "Z_TV": {"min_wall_distance": 5, "preferred_wall_distance": 10, "can_touch_wall": True},
            "Z_Fridge2": {"min_wall_distance": 5, "preferred_wall_distance": 15, "can_touch_wall": True},
            
            # New rules for Azure assets
            "Z_Armchair1": {"min_wall_distance": 20, "preferred_wall_distance": 30, "can_touch_wall": True},
            "Z_Armchair2": {"min_wall_distance": 20, "preferred_wall_distance": 30, "can_touch_wall": True},
            "Z_Armchair3": {"min_wall_distance": 25, "preferred_wall_distance": 35, "can_touch_wall": True},
            "Z_Armchair4": {"min_wall_distance": 30, "preferred_wall_distance": 40, "can_touch_wall": True},
            "Z_Armchair5": {"min_wall_distance": 25, "preferred_wall_distance": 35, "can_touch_wall": True},
            
            "Z_Bed2": {"min_wall_distance": 30, "preferred_wall_distance": 50, "can_touch_wall": True},
            "Z_Bed3": {"min_wall_distance": 40, "preferred_wall_distance": 60, "can_touch_wall": True},
            "Z_Bedsidetable1": {"min_wall_distance": 10, "preferred_wall_distance": 20, "can_touch_wall": True},
            
            "Z_Chair2": {"min_wall_distance": 30, "preferred_wall_distance": 40, "can_touch_wall": False},
            "Z_Chair3": {"min_wall_distance": 30, "preferred_wall_distance": 40, "can_touch_wall": False},
            "Z_Chair4": {"min_wall_distance": 35, "preferred_wall_distance": 45, "can_touch_wall": False},
            "Z_Chair5": {"min_wall_distance": 25, "preferred_wall_distance": 35, "can_touch_wall": False},
            
            "Z_Fridge": {"min_wall_distance": 5, "preferred_wall_distance": 15, "can_touch_wall": True},
            "Z_Flowervase": {"min_wall_distance": 10, "preferred_wall_distance": 20, "can_touch_wall": False},
            "Z_Sofa2": {"min_wall_distance": 30, "preferred_wall_distance": 50, "can_touch_wall": True},
            
            "Z_Table2": {"min_wall_distance": 40, "preferred_wall_distance": 60, "can_touch_wall": False},
            "Z_Table3": {"min_wall_distance": 40, "preferred_wall_distance": 60, "can_touch_wall": False},
            
            "Z_Bathtub1": {"min_wall_distance": 5, "preferred_wall_distance": 15, "can_touch_wall": True},
            "Z_Sink": {"min_wall_distance": 5, "preferred_wall_distance": 10, "can_touch_wall": True},
            "Z_Sinkandcabinet": {"min_wall_distance": 5, "preferred_wall_distance": 10, "can_touch_wall": True},
            "Z_Urinal": {"min_wall_distance": 10, "preferred_wall_distance": 20, "can_touch_wall": True},
            
            "Z_Treadmill": {"min_wall_distance": 50, "preferred_wall_distance": 80, "can_touch_wall": False},
            "Z_Man": {"min_wall_distance": 30, "preferred_wall_distance": 40, "can_touch_wall": False},
            "Z_Balcony2": {"min_wall_distance": 0, "preferred_wall_distance": 5, "can_touch_wall": True}
        }

    def cm_to_m(self, value_dict, key='length'):
        """Convert cm to meters - handles both dict and direct values"""
        if isinstance(value_dict, dict):
            return float(value_dict.get(key, 0)) / 100.0
        return float(value_dict or 0) / 100.0

    def load_azure_mesh(self, asset_name: str, scale: float = 1.0) -> Optional[trimesh.Trimesh]:
        """Load mesh from Azure blob storage"""
        try:
            asset_files = self.azure_manager.get_asset_files(asset_name)
            
            if not asset_files.get("obj"):
                print(f"No OBJ file found for {asset_name}")
                return None
            
            # Load the mesh
            mesh = trimesh.load(asset_files["obj"], force='mesh')
            if isinstance(mesh, trimesh.Scene):
                # If scene, try to get the largest mesh
                if mesh.geometry:
                    mesh = max(mesh.geometry.values(), key=lambda g: g.volume if hasattr(g, 'volume') else 0)
                else:
                    return None # Empty scene

            # --- NaN FIX: VALIDATION STEP ---
            # Check if the mesh is valid and has a non-zero volume/area.
            if mesh is None or mesh.is_empty:
                print(f"Warning: Loaded mesh for '{asset_name}' is empty. Skipping.")
                return None

            # Check for invalid bounding box dimensions to prevent NaN errors
            bounds_size = mesh.bounds[1] - mesh.bounds[0]
            if any(s < 1e-6 for s in bounds_size):
                print(f"Warning: Loaded mesh for '{asset_name}' has an invalid bounding box (a dimension is zero). Size: {bounds_size}. Skipping.")
                return None
            # --- END FIX ---

            # Note: We are not applying a generic scale here anymore.
            # Scaling should be done based on the item's purpose.
            # The create_furniture_mesh function does not scale Azure assets, which is correct.
            
            # Apply texture if available
            if asset_files.get("texture"):
                try:
                    texture_img = Image.open(asset_files["texture"])
                    
                    material = PBRMaterial(
                        name=f"{asset_name}_material",
                        baseColorTexture=texture_img,
                        roughnessFactor=0.7,
                        metallicFactor=0.0,
                        doubleSided=True
                    )
                    
                    # Generate UV coordinates if not present or incorrect length
                    if hasattr(mesh.visual, 'uv') and mesh.visual.uv is not None and len(mesh.visual.uv) == len(mesh.vertices):
                        mesh.visual = TextureVisuals(
                            uv=mesh.visual.uv,
                            image=texture_img,
                            material=material
                        )
                    else:
                        uv_coords = self.generate_basic_uv_coordinates(mesh)
                        # Another check for NaN from UV generation
                        if np.isnan(uv_coords).any():
                           print(f"Warning: UV generation for '{asset_name}' resulted in NaN values. Using default color.")
                           mesh.visual.face_colors = self.get_default_color_for_asset(asset_name)
                        else:
                           mesh.visual = TextureVisuals(
                               uv=uv_coords,
                               image=texture_img,
                               material=material
                           )
                        
                except Exception as e:
                    print(f"Could not apply texture to {asset_name}: {e}")
                    mesh.visual.face_colors = self.get_default_color_for_asset(asset_name)
            else:
                mesh.visual.face_colors = self.get_default_color_for_asset(asset_name)
            
            return mesh
            
        except Exception as e:
            print(f"Error loading Azure mesh {asset_name}: {e}")
            return None

    def generate_basic_uv_coordinates(self, mesh):
        """Generate basic UV coordinates for meshes without UVs"""
        vertices = mesh.vertices
        bounds = mesh.bounds
        size = bounds[1] - bounds[0]
        
        if size[0] == 0 or size[1] == 0 or size[2] == 0:
            return np.zeros((len(vertices), 2))
        
        # Use the two largest dimensions for UV mapping
        dimensions = [(size[0], 0), (size[1], 1), (size[2], 2)]
        dimensions.sort(reverse=True, key=lambda x: x[0])
        
        u_axis = dimensions[0][1]
        v_axis = dimensions[1][1]
        
        uv_coords = np.zeros((len(vertices), 2))
        
        for i, vertex in enumerate(vertices):
            u = (vertex[u_axis] - bounds[0][u_axis]) / size[u_axis]
            v = (vertex[v_axis] - bounds[0][v_axis]) / size[v_axis]
            uv_coords[i] = [u, v]
        
        return uv_coords

    def get_default_color_for_asset(self, asset_name: str) -> List[int]:
        """Get default color based on asset category"""
        if "chair" in asset_name.lower() or "armchair" in asset_name.lower():
            return [139, 69, 19, 255]  # Brown for furniture
        elif "bed" in asset_name.lower():
            return [255, 255, 255, 255]  # White for beds
        elif "table" in asset_name.lower():
            return [160, 82, 45, 255]  # Saddle brown for tables
        elif "sofa" in asset_name.lower():
            return [105, 105, 105, 255]  # Gray for sofas
        elif "fridge" in asset_name.lower():
            return [255, 255, 255, 255]  # White for appliances
        elif "sink" in asset_name.lower() or "bathtub" in asset_name.lower():
            return [240, 240, 240, 255]  # Off-white for bathroom fixtures
        elif "door" in asset_name.lower():
            return [139, 69, 19, 255]  # Brown for doors
        elif "window" in asset_name.lower():
            return [200, 220, 255, 128]  # Light blue transparent for windows
        else:
            return [128, 128, 128, 255]  # Gray default


    # def create_furniture_mesh(self, item_type: str, position: np.ndarray, rotation: float = 0.0, scale=1.0) -> Optional[trimesh.Trimesh]:
    #     """Create furniture mesh at specified position with scaling support"""
    #     mesh = None
        
    #     # First, try to get asset candidates from class mapping
    #     asset_candidates = self.class_mapping.get(item_type, [])
        
    #     if isinstance(asset_candidates, str):
    #         asset_candidates = [asset_candidates]
    #     elif not isinstance(asset_candidates, list):
    #         asset_candidates = [str(asset_candidates)]
        
    #     # If no mapping found, treat the item_type as a direct asset name
    #     if not asset_candidates:
    #         asset_candidates = [item_type]
        
    #     print(f"Attempting to load furniture '{item_type}' with candidates: {asset_candidates}")
        
    #     # Try to load from Azure first
    #     for asset_name in asset_candidates:
    #         print(f"  -> Trying to load Azure asset: {asset_name}")
            
    #         # Check if this asset exists in Azure assets data
    #         if asset_name in self.azure_manager.assets_data:
    #             mesh = self.load_azure_mesh(asset_name)
    #             if mesh:
    #                 print(f"  -> Successfully loaded Azure asset: {asset_name}")
    #                 break
    #             else:
    #                 print(f"  -> Failed to load Azure asset: {asset_name}")
    #         else:
    #             print(f"  -> Asset {asset_name} not found in Azure assets data")
        
    #     # If Azure loading failed, try to find similar assets
    #     if mesh is None and asset_candidates:
    #         print(f"  -> Searching for similar assets in Azure...")
    #         candidate_name = asset_candidates[0].lower()
            
    #         # Search through available Azure assets for partial matches
    #         for azure_asset_name in self.azure_manager.assets_data.keys():
    #             azure_name_lower = azure_asset_name.lower()
                
    #             # Check for exact match or partial match
    #             if (candidate_name == azure_name_lower or 
    #                 candidate_name in azure_name_lower or 
    #                 azure_name_lower in candidate_name):
                    
    #                 print(f"  -> Found similar asset: {azure_asset_name}")
    #                 mesh = self.load_azure_mesh(azure_asset_name)
    #                 if mesh:
    #                     print(f"  -> Successfully loaded similar asset: {azure_asset_name}")
    #                     break
        
    #     # Fallback to creating basic mesh if Azure loading fails
    #     if mesh is None:
    #         print(f"  -> Fallback: Creating primitive box for '{item_type}'")
    #         asset_for_dims = asset_candidates[0] if asset_candidates else item_type
    #         dimensions = self.azure_manager.get_asset_dimensions(asset_for_dims)
            
    #         # Use reasonable default dimensions if not found
    #         width = dimensions.get("width", 1.0)
    #         height = dimensions.get("height", 1.0) 
    #         depth = dimensions.get("depth", 1.0)
            
    #         # Set some reasonable defaults for common furniture types
    #         if 'bed' in item_type.lower():
    #             width, height, depth = 2.0, 0.6, 1.0
    #         elif 'sofa' in item_type.lower():
    #             width, height, depth = 2.0, 0.8, 0.8
    #         elif 'table' in item_type.lower():
    #             width, height, depth = 1.2, 0.75, 0.8
    #         elif 'chair' in item_type.lower():
    #             width, height, depth = 0.6, 0.9, 0.6
            
    #         mesh = trimesh.creation.box(extents=[width, height, depth])
    #         mesh.visual.face_colors = self.get_default_color_for_asset(item_type)

    #     # Final check to ensure a mesh object exists
    #     if mesh is None:
    #         print(f"Error: Could not create any mesh for item type '{item_type}'. Skipping.")
    #         return None

    #     # Position and transform the mesh
    #     try:
    #         # Center the mesh and move its base to y=0
    #         mesh.vertices -= mesh.centroid
    #         min_y = mesh.bounds[0][1]
    #         mesh.vertices[:, 1] -= min_y

    #         # Apply scaling
    #         if isinstance(scale, np.ndarray):
    #             # Per-axis scaling (numpy array with [x, y, z] values)
    #             print(f"  -> Applying per-axis scaling: {scale}")
    #             mesh.apply_scale(scale)
    #         elif isinstance(scale, (list, tuple)) and len(scale) == 3:
    #             # Per-axis scaling (list/tuple with [x, y, z] values)
    #             scale_array = np.array(scale)
    #             print(f"  -> Applying per-axis scaling: {scale_array}")
    #             mesh.apply_scale(scale_array)
    #         elif scale != 1.0:
    #             # Uniform scaling
    #             print(f"  -> Applying uniform scaling: {scale}")
    #             mesh.apply_scale(scale)

    #         # Apply rotation
    #         if rotation != 0:
    #             rotation_matrix = trimesh.transformations.rotation_matrix(rotation, [0, 1, 0])
    #             mesh.apply_transform(rotation_matrix)

    #         # Position the mesh
    #         mesh.vertices[:, 0] += position[0]
    #         mesh.vertices[:, 1] += position[1]
    #         mesh.vertices[:, 2] += position[2]

    #         mesh.metadata = {
    #             'type': 'furniture',
    #             'item_type': item_type,
    #             'scale': scale,
    #             'source': 'azure_asset' if asset_candidates[0] in self.azure_manager.assets_data else 'fallback_box'
    #         }
            
    #         return mesh
            
    #     except Exception as e:
    #         print(f"Error positioning mesh for '{item_type}': {e}")
    #         return None

    def place_items_from_json(self, items_data: Dict[str, Any]) -> List[trimesh.Trimesh]:
        """Creates and places meshes for items defined in the JSON data with scaling support."""
        item_meshes = []
        if not items_data:
            return []

        print(f"Placing {len(items_data)} items from JSON data...")
        for item_id, item_data in items_data.items():
            try:
                item_type = item_data.get('type')
                if not item_type:
                    print(f"Warning: Skipping item {item_id} because it has no 'type'.")
                    continue
                
                # --- FIX: Make lookup more robust ---
                item_type_lower = item_type.lower()
                
                # First, check if the item_type is a specific asset name (e.g., 'z_bed1')
                if item_type_lower in self.reverse_class_mapping:
                    # If so, use the proper-cased asset name from the reverse map
                    actual_item_type = self.reverse_class_mapping[item_type_lower]
                # Second, check if it's a generic type (e.g., 'bed')
                elif item_type_lower in self.class_mapping:
                    actual_item_type = item_type_lower
                else:
                    # If neither, we'll log a warning and use the original type
                    print(f"Warning: No asset mapping found for item type '{item_type}'. A fallback box will be created.")
                    actual_item_type = item_type_lower
                # --- END FIX ---

                # Convert position from cm to meters (and flip y-axis)
                pos_x = self.cm_to_m(item_data.get('x', 0))
                pos_z = -self.cm_to_m(item_data.get('y', 0)) # JSON 'y' is our 'z'
                pos_y = 0.0 # Altitude from floor

                # Convert rotation from degrees to radians
                rotation_deg = float(item_data.get('rotation', 0.0))
                rotation_rad = math.radians(rotation_deg)

                # Get scale from JSON data (default to 1.0 if not specified)
                scale = item_data.get('scale', 1.0)
                if isinstance(scale, dict):
                    # Handle per-axis scaling: {"x": 1.0, "y": 1.0, "z": 1.0}
                    scale_x = float(scale.get('x', 1.0))
                    scale_y = float(scale.get('y', 1.0)) 
                    scale_z = float(scale.get('z', 1.0))
                    scale = np.array([scale_x, scale_y, scale_z])
                    print(f"Item {item_id}: Using per-axis scaling {scale}")
                elif isinstance(scale, (list, tuple)) and len(scale) == 3:
                    # Handle array-style scaling [x, y, z]
                    scale = np.array([float(s) for s in scale])
                    print(f"Item {item_id}: Using per-axis scaling {scale}")
                else:
                    # Handle uniform scaling
                    scale = float(scale)
                    if scale != 1.0:
                        print(f"Item {item_id}: Using uniform scaling {scale}")

                # Create the furniture mesh with scaling
                mesh = self.create_furniture_mesh(
                    item_type=actual_item_type,
                    position=np.array([pos_x, pos_y, pos_z]),
                    rotation=rotation_rad,
                    scale=scale
                )

                if mesh:
                    # Add metadata about the item
                    mesh.metadata.update({
                        'item_id': item_id,
                        'original_scale': scale,
                        'position': [pos_x, pos_y, pos_z],
                        'rotation_degrees': rotation_deg
                    })
                    item_meshes.append(mesh)
                    print(f"Successfully created scaled mesh for item {item_id}")

            except Exception as e:
                print(f"Error processing item {item_id}: {e}")
                continue
        
        print(f"Successfully created {len(item_meshes)} item meshes with scaling")
        return item_meshes

    # def create_furniture_mesh(self, item_type: str, position: np.ndarray, rotation: float = 0.0, scale=1.0) -> Optional[trimesh.Trimesh]:
    #     """Create furniture mesh at specified position with scaling support"""
    #     mesh = None
        
    #     # First, try to get asset candidates from class mapping
    #     asset_candidates = self.class_mapping.get(item_type, [])
        
    #     if isinstance(asset_candidates, str):
    #         asset_candidates = [asset_candidates]
    #     elif not isinstance(asset_candidates, list):
    #         asset_candidates = [str(asset_candidates)]
        
    #     # If no mapping found, treat the item_type as a direct asset name
    #     if not asset_candidates:
    #         asset_candidates = [item_type]
        
    #     print(f"Attempting to load furniture '{item_type}' with candidates: {asset_candidates}")
        
    #     # Try to load from Azure first
    #     for asset_name in asset_candidates:
    #         print(f"  -> Trying to load Azure asset: {asset_name}")
            
    #         # Check if this asset exists in Azure assets data
    #         if asset_name in self.azure_manager.assets_data:
    #             mesh = self.load_azure_mesh(asset_name)
    #             if mesh:
    #                 print(f"  -> Successfully loaded Azure asset: {asset_name}")
    #                 break
    #             else:
    #                 print(f"  -> Failed to load Azure asset: {asset_name}")
    #         else:
    #             print(f"  -> Asset {asset_name} not found in Azure assets data")
        
    #     # If Azure loading failed, try to find similar assets
    #     if mesh is None and asset_candidates:
    #         print(f"  -> Searching for similar assets in Azure...")
    #         candidate_name = asset_candidates[0].lower()
            
    #         # Search through available Azure assets for partial matches
    #         for azure_asset_name in self.azure_manager.assets_data.keys():
    #             azure_name_lower = azure_asset_name.lower()
                
    #             # Check for exact match or partial match
    #             if (candidate_name == azure_name_lower or 
    #                 candidate_name in azure_name_lower or 
    #                 azure_name_lower in candidate_name):
                    
    #                 print(f"  -> Found similar asset: {azure_asset_name}")
    #                 mesh = self.load_azure_mesh(azure_asset_name)
    #                 if mesh:
    #                     print(f"  -> Successfully loaded similar asset: {azure_asset_name}")
    #                     break
        
    #     # Fallback to creating basic mesh if Azure loading fails
    #     if mesh is None:
    #         print(f"  -> Fallback: Creating primitive box for '{item_type}'")
    #         asset_for_dims = asset_candidates[0] if asset_candidates else item_type
    #         dimensions = self.azure_manager.get_asset_dimensions(asset_for_dims)
            
    #         # Use reasonable default dimensions if not found
    #         width = dimensions.get("width", 1.0)
    #         height = dimensions.get("height", 1.0) 
    #         depth = dimensions.get("depth", 1.0)
            
    #         # Set some reasonable defaults for common furniture types
    #         if 'bed' in item_type.lower():
    #             width, height, depth = 2.0, 0.6, 1.0
    #         elif 'sofa' in item_type.lower():
    #             width, height, depth = 2.0, 0.8, 0.8
    #         elif 'table' in item_type.lower():
    #             width, height, depth = 1.2, 0.75, 0.8
    #         elif 'chair' in item_type.lower():
    #             width, height, depth = 0.6, 0.9, 0.6
            
    #         mesh = trimesh.creation.box(extents=[width, height, depth])
    #         mesh.visual.face_colors = self.get_default_color_for_asset(item_type)

    #     # Final check to ensure a mesh object exists
    #     if mesh is None:
    #         print(f"Error: Could not create any mesh for item type '{item_type}'. Skipping.")
    #         return None

    #     # Position and transform the mesh
    #     try:
    #         # Center the mesh and move its base to y=0
    #         mesh.vertices -= mesh.centroid
    #         min_y = mesh.bounds[0][1]
    #         mesh.vertices[:, 1] -= min_y

    #         # Apply scaling FIRST (before rotation and positioning)
    #         if isinstance(scale, np.ndarray):
    #             # Per-axis scaling (numpy array with [x, y, z] values)
    #             print(f"  -> Applying per-axis scaling: {scale}")
    #             mesh.apply_scale(scale)
    #         elif isinstance(scale, (list, tuple)) and len(scale) == 3:
    #             # Per-axis scaling (list/tuple with [x, y, z] values)
    #             scale_array = np.array(scale)
    #             print(f"  -> Applying per-axis scaling: {scale_array}")
    #             mesh.apply_scale(scale_array)
    #         elif isinstance(scale, (int, float)) and scale != 1.0:
    #             # Uniform scaling
    #             print(f"  -> Applying uniform scaling: {scale}")
    #             mesh.apply_scale(scale)

    #         # Apply rotation AFTER scaling
    #         if rotation != 0:
    #             rotation_matrix = trimesh.transformations.rotation_matrix(rotation, [0, 1, 0])
    #             mesh.apply_transform(rotation_matrix)

    #         # Position the mesh LAST
    #         mesh.vertices[:, 0] += position[0]
    #         mesh.vertices[:, 1] += position[1]
    #         mesh.vertices[:, 2] += position[2]

    #         mesh.metadata = {
    #             'type': 'furniture',
    #             'item_type': item_type,
    #             'scale': scale,
    #             'applied_scale': scale,
    #             'source': 'azure_asset' if (asset_candidates and asset_candidates[0] in self.azure_manager.assets_data) else 'fallback_box'
    #         }
            
    #         return mesh
            
    #     except Exception as e:
    #         print(f"Error positioning mesh for '{item_type}': {e}")
    #         return None

    def create_furniture_mesh(self, item_type: str, position: np.ndarray, rotation: float = 0.0, target_dimensions: Optional[Dict[str, float]] = None) -> Optional[trimesh.Trimesh]:
        """
        Creates and positions a furniture mesh, scaling it to match target dimensions.
        """
        mesh = None
        
        # Determine asset candidates from mapping, or use the item_type directly
        asset_candidates = self.class_mapping.get(item_type, [])
        if isinstance(asset_candidates, str):
            asset_candidates = [asset_candidates]
        if not asset_candidates:
            asset_candidates = [item_type]

        # Try to load the best-matching asset from Azure
        for asset_name in asset_candidates:
            if asset_name in self.azure_manager.assets_data:
                mesh = self.load_azure_mesh(asset_name)
                if mesh:
                    print(f"  -> Successfully loaded Azure asset '{asset_name}' for type '{item_type}'.")
                    break
        
        # If no asset was loaded, create a fallback box
        if mesh is None:
            print(f"  -> Fallback: Creating a primitive box for '{item_type}'.")
            # Use target dimensions for the box if available, otherwise default
            width = target_dimensions.get("width", 1.0) if target_dimensions else 1.0
            height = target_dimensions.get("height", 1.0) if target_dimensions else 1.0
            depth = target_dimensions.get("depth", 1.0) if target_dimensions else 1.0
            mesh = trimesh.creation.box(extents=[width, height, depth])
            mesh.visual.face_colors = self.get_default_color_for_asset(item_type)
            # Since the box is already the correct size, we don't need to scale it further
            target_dimensions = None

        if mesh is None:
            print(f"Error: Could not create any mesh for item type '{item_type}'. Skipping.")
            return None

        # --- SCALING AND TRANSFORMATION LOGIC ---
        try:
            # First, get the original size of the loaded mesh
            original_bounds = mesh.bounds
            original_size = original_bounds[1] - original_bounds[0]

            # Move mesh to origin to ensure scaling is uniform
            mesh.apply_translation(-mesh.centroid)
            
            # Calculate and apply scaling if target dimensions are provided
            if target_dimensions:
                # Safety check to prevent division by zero (NaN error)
                if any(s < 1e-6 for s in original_size):
                    print(f"Warning: Original mesh for '{item_type}' has a zero dimension {original_size}. Cannot scale accurately.")
                else:
                    scale_vector = [
                        target_dimensions['width'] / original_size[0],
                        target_dimensions['height'] / original_size[1],
                        target_dimensions['depth'] / original_size[2]
                    ]
                    print(f"  -> Applying calculated scale {scale_vector} to match target dimensions.")
                    mesh.apply_scale(scale_vector)

            # Move the base of the mesh to the floor (y=0)
            min_y = mesh.bounds[0][1]
            mesh.apply_translation([0, -min_y, 0])

            # Apply rotation
            if rotation != 0:
                rotation_matrix = trimesh.transformations.rotation_matrix(rotation, [0, 1, 0])
                mesh.apply_transform(rotation_matrix)

            # Finally, move the mesh to its final position
            mesh.apply_translation(position)

            mesh.metadata = { 'type': 'furniture', 'item_type': item_type }
            return mesh
            
        except Exception as e:
            print(f"Error transforming mesh for '{item_type}': {e}")
            return None
    # # Alternative debug version of the main placement function
    # def place_items_from_json_with_debug(self, items_data: Dict[str, Any]) -> List[trimesh.Trimesh]:
    #     """Enhanced version with debugging and scaling support"""
    #     # First, debug available assets
    #     self.debug_azure_assets()
        
    #     item_meshes = []
    #     if not items_data:
    #         return []

    #     print(f"Placing {len(items_data)} items from JSON data...")
        
    #     for item_id, item_data in items_data.items():
    #         try:
    #             item_type = item_data.get('type')
    #             if not item_type:
    #                 print(f"Warning: Skipping item {item_id} because it has no 'type'.")
    #                 continue
                
    #             print(f"\n--- Processing item {item_id} of type '{item_type}' ---")
                
    #             # Enhanced lookup logic
    #             item_type_lower = item_type.lower()
    #             actual_item_type = item_type  # Default to original
                
    #             # Check direct Azure asset existence first
    #             if item_type in self.azure_manager.assets_data:
    #                 actual_item_type = item_type
    #                 print(f"Found direct Azure asset match: {item_type}")
    #             elif item_type_lower in self.reverse_class_mapping:
    #                 actual_item_type = self.reverse_class_mapping[item_type_lower] 
    #                 print(f"Found reverse mapping: {item_type_lower} -> {actual_item_type}")
    #             elif item_type_lower in self.class_mapping:
    #                 actual_item_type = item_type_lower
    #                 print(f"Found in class mapping: {item_type_lower}")
    #             else:
    #                 print(f"No mapping found for '{item_type}', will search Azure assets...")

    #             # Convert position from cm to meters
    #             pos_x = self.cm_to_m(item_data.get('x', 0))
    #             pos_z = -self.cm_to_m(item_data.get('y', 0))
    #             pos_y = 0.0

    #             # Convert rotation
    #             rotation_deg = float(item_data.get('rotation', 0.0))
    #             rotation_rad = math.radians(rotation_deg)

    #             # Get scale from JSON data (default to 1.0 if not specified)
    #             scale = item_data.get('scale', 1.0)
    #             if isinstance(scale, dict):
    #                 # Handle per-axis scaling: {"x": 1.0, "y": 1.0, "z": 1.0}
    #                 scale_x = float(scale.get('x', 1.0))
    #                 scale_y = float(scale.get('y', 1.0)) 
    #                 scale_z = float(scale.get('z', 1.0))
    #                 scale = np.array([scale_x, scale_y, scale_z])
    #                 print(f"Item {item_id}: Using per-axis scaling {scale}")
    #             elif isinstance(scale, (list, tuple)) and len(scale) == 3:
    #                 # Handle array-style scaling [x, y, z]
    #                 scale = np.array([float(s) for s in scale])
    #                 print(f"Item {item_id}: Using per-axis scaling {scale}")
    #             else:
    #                 # Handle uniform scaling
    #                 scale = float(scale)
    #                 if scale != 1.0:
    #                     print(f"Item {item_id}: Using uniform scaling {scale}")

    #             # Create the mesh with scaling
    #             mesh = self.create_furniture_mesh(
    #                 item_type=actual_item_type,
    #                 position=np.array([pos_x, pos_y, pos_z]),
    #                 rotation=rotation_rad,
    #                 scale=scale
    #             )

    #             if mesh:
    #                 # Add additional metadata for debugging
    #                 mesh.metadata.update({
    #                     'item_id': item_id,
    #                     'debug': True,
    #                     'original_scale': scale,
    #                     'position': [pos_x, pos_y, pos_z],
    #                     'rotation_degrees': rotation_deg
    #                 })
    #                 item_meshes.append(mesh)
    #                 print(f"Successfully created mesh for {item_id} with scale {scale}")
    #             else:
    #                 print(f"Failed to create mesh for {item_id}")

    #         except Exception as e:
    #             print(f"Error processing item {item_id}: {e}")
    #             continue
        
    #     return item_meshes

    def place_items_from_json(self, items_data: Dict[str, Any]) -> List[trimesh.Trimesh]:
        """
        Creates and places meshes for items defined in the JSON data,
        using dimensions from the item's properties for scaling.
        """
        item_meshes = []
        if not items_data:
            return []

        print(f"Placing {len(items_data)} items from JSON data...")
        for item_id, item_data in items_data.items():
            try:
                item_type = item_data.get('type')
                if not item_type:
                    print(f"Warning: Skipping item {item_id} because it has no 'type'.")
                    continue
                
                # --- Robust Item Type Lookup ---
                item_type_lower = item_type.lower()
                actual_item_type = item_type 
                if item_type_lower in self.reverse_class_mapping:
                    actual_item_type = self.reverse_class_mapping[item_type_lower]
                elif item_type_lower in self.class_mapping:
                    actual_item_type = item_type_lower
                else:
                    print(f"Warning: No asset mapping found for item type '{item_type}'.")
                
                # --- Extract Target Dimensions from JSON ---
                properties = item_data.get('properties', {})
                target_dims = {
                    "width": self.cm_to_m(properties.get('width', {})),
                    "depth": self.cm_to_m(properties.get('depth', {})), # JSON depth is our Z-axis
                    "height": self.cm_to_m(properties.get('height', {}))
                }

                # Position and Rotation
                pos_x = self.cm_to_m(item_data.get('x', 0))
                pos_z = -self.cm_to_m(item_data.get('y', 0)) # JSON 'y' is our 'z'
                pos_y = self.cm_to_m(properties.get('altitude', {'length': 0})) # Altitude from properties

                rotation_deg = float(item_data.get('rotation', 0.0))
                rotation_rad = math.radians(rotation_deg)

                # Create the furniture mesh with target dimensions for scaling
                mesh = self.create_furniture_mesh(
                    item_type=actual_item_type,
                    position=np.array([pos_x, pos_y, pos_z]),
                    rotation=rotation_rad,
                    target_dimensions=target_dims
                )

                if mesh:
                    mesh.metadata.update({'item_id': item_id})
                    item_meshes.append(mesh)

            except Exception as e:
                print(f"Error processing item {item_id}: {e}")
                continue
        
        return item_meshes

    def auto_place_furniture(self, areas_data: Dict, vertices_data: Dict, lines_data: Dict) -> List[trimesh.Trimesh]:
        """Automatically place furniture in rooms based on room type and available space"""
        furniture_meshes = []
        
        for area_id, area_data in areas_data.items():
            area_type = area_data.get('properties', {}).get('type', '').lower()
            
            # Get room polygon
            vertex_ids = area_data.get('vertices', [])
            if len(vertex_ids) < 3:
                continue
                
            room_points = []
            for v_id in vertex_ids:
                if v_id in vertices_data:
                    room_points.append([
                        vertices_data[v_id]['x'] / 100.0,
                        -vertices_data[v_id]['y'] / 100.0
                    ])
            
            if len(room_points) < 3:
                continue
            
            try:
                room_polygon = Polygon(room_points)
                if not room_polygon.is_valid:
                    continue
                
                room_center = room_polygon.centroid
                room_bounds = room_polygon.bounds
                room_area = room_polygon.area
                
                # Place furniture based on room type
                furniture_items = self.get_furniture_for_room_type(area_type, room_area)
                
                for item_type, count in furniture_items.items():
                    for i in range(count):
                        # Find suitable position
                        position = self.find_furniture_position(
                            room_polygon, item_type, existing_positions=[]
                        )
                        
                        if position:
                            furniture_mesh = self.create_furniture_mesh(
                                item_type, 
                                np.array([position[0], 0.0, position[1]]),
                                rotation=np.random.uniform(0, 2*np.pi),
                                scale=1.0  # Default scale for auto-placed items
                            )
                            
                            if furniture_mesh:
                                furniture_meshes.append(furniture_mesh)
            
            except Exception as e:
                print(f"Error placing furniture in room {area_id}: {e}")
                continue
        
        return furniture_meshes

    def get_furniture_for_room_type(self, room_type: str, room_area: float) -> Dict[str, int]:
        """Get appropriate furniture for different room types"""
        furniture_sets = {
            'bedroom': {
                'bed': 1,
                'bedside_table': 2 if room_area > 10 else 1,
                'chair': 1 if room_area > 15 else 0,
                'table': 1 if room_area > 20 else 0
            },
            'living': {
                'sofa': 1,
                'table': 1,
                'chair': 2 if room_area > 20 else 1,
                'tv': 1 if room_area > 15 else 0,
                'flower_vase': 1 if room_area > 10 else 0
            },
            'kitchen': {
                'fridge': 1,
                'sink': 1,
                'table': 1 if room_area > 10 else 0,
                'chair': 2 if room_area > 15 else 0
            },
            'bathroom': {
                'sink': 1,
                'bathtub': 1 if room_area > 5 else 0,
                'w_machine': 1 if room_area > 8 else 0
            },
            'balcony': {
                'chair': 2 if room_area > 5 else 1,
                'table': 1 if room_area > 8 else 0,
                'flower_vase': 1
            }
        }
        
        # Default furniture for unknown room types
        default_furniture = {
            'chair': 1,
            'table': 1 if room_area > 10 else 0
        }
        
        return furniture_sets.get(room_type, default_furniture)

    def find_furniture_position(self, room_polygon: Polygon, item_type: str, existing_positions: List) -> Optional[tuple]:
        """Find suitable position for furniture item within room"""
        try:
            bounds = room_polygon.bounds
            
            # --- START of CORRECTION ---
            # Get the asset name or list of names from the mapping
            asset_candidates = self.class_mapping.get(item_type, item_type)
            
            # If it's a list, just pick the first asset to get dimensions
            if isinstance(asset_candidates, list) and asset_candidates:
                asset_name_for_dims = asset_candidates[0]
            else:
                asset_name_for_dims = asset_candidates
            
            # Get item dimensions for collision detection
            dimensions = self.azure_manager.get_asset_dimensions(asset_name_for_dims)
            # --- END of CORRECTION ---

            max_attempts = 50
            for _ in range(max_attempts):
                # Generate random position within room bounds
                x = np.random.uniform(bounds[0] + dimensions["width"]/2,
                                    bounds[2] - dimensions["width"]/2)
                y = np.random.uniform(bounds[1] + dimensions["depth"]/2,
                                    bounds[3] - dimensions["depth"]/2)

                point = Point(x, y)

                # Check if point is inside room
                if not room_polygon.contains(point):
                    continue

                # Check collision with existing furniture
                collision = False
                for existing_pos in existing_positions:
                    distance = np.sqrt((x - existing_pos[0])**2 + (y - existing_pos[1])**2)
                    min_distance = max(dimensions["width"], dimensions["depth"]) + 0.5
                    if distance < min_distance:
                        collision = True
                        break

                if not collision:
                    existing_positions.append((x, y))
                    return (x, y)

            return None

        except Exception as e:
            print(f"Error finding position for {item_type}: {e}")
            return None

    def load_door_mesh(self, scale=1.0):
        """Load door mesh with proper material handling"""
        # Try Azure assets first
        door_mesh = self.load_azure_mesh("Z_Door3", scale)
        if door_mesh:
            return door_mesh
            
        # Fallback to local assets
        asset_info = self.assets.get('door')
        if not asset_info or not os.path.exists(asset_info['obj']):
            return None
        
        try:
            mesh = trimesh.load(asset_info['obj'], force='mesh')
            if isinstance(mesh, trimesh.Scene):
                mesh = next(iter(mesh.geometry.values()))
            
            mesh.apply_scale(scale)
            
            # Apply textures
            if os.path.exists(asset_info['diffuse']):
                try:
                    diffuse_img = Image.open(asset_info['diffuse'])
                    material = PBRMaterial(
                        name="door_material",
                        baseColorTexture=diffuse_img,
                        doubleSided=True
                    )
                    
                    if hasattr(mesh.visual, 'uv') and mesh.visual.uv is not None:
                        mesh.visual = TextureVisuals(
                            uv=mesh.visual.uv,
                            image=diffuse_img,
                            material=material
                        )
                    else:
                        mesh.visual.material = material
                        
                except Exception as e:
                    print(f"Warning: Could not load texture for door: {e}")
                    mesh.visual.face_colors = [139, 69, 19, 255]
            else:
                mesh.visual.face_colors = [139, 69, 19, 255]
            
            return mesh
            
        except Exception as e:
            print(f"Error loading door mesh: {e}")
            return None

    def generate_window_uv_coordinates(self, mesh):
        """Generate proper UV coordinates for window mesh"""
        try:
            vertices = mesh.vertices
            bounds = mesh.bounds
            size = bounds[1] - bounds[0]
            
            if size[0] == 0 or size[1] == 0 or size[2] == 0:
                return np.zeros((len(vertices), 2))
            
            # Determine which axis is width and which is height
            width_axis = 0 if size[0] > size[2] else 2
            height_axis = 1
            
            uv_coords = np.zeros((len(vertices), 2))
            
            for i, vertex in enumerate(vertices):
                # Normalize coordinates to 0-1 range
                u = (vertex[width_axis] - bounds[0][width_axis]) / size[width_axis]
                v = (vertex[height_axis] - bounds[0][height_axis]) / size[height_axis]
                
                # Clamp to 0-1 range
                u = max(0.0, min(1.0, u))
                v = max(0.0, min(1.0, v))
                
                uv_coords[i] = [u, v]
            
            return uv_coords
            
        except Exception as e:
            print(f"Error generating window UV coordinates: {e}")
            return np.zeros((len(mesh.vertices), 2))

    def create_window_frame_and_glass(self, hole_info):
        """Create separate window frame and glass components with proper textures"""
        window_meshes = []
        
        # Window frame dimensions
        frame_width = 0.05  # 5cm frame width
        glass_thickness = 0.01  # 1cm glass thickness
        
        width = hole_info['width']
        height = hole_info['height']
        thickness = hole_info['wall_thickness']
        
        # Create window frame (hollow rectangle)
        outer_frame = trimesh.creation.box(extents=[width, height, thickness * 0.3])
        inner_cutout = trimesh.creation.box(extents=[width - 2*frame_width, height - 2*frame_width, thickness * 0.4])
        
        try:
            # Create frame by boolean difference
            frame_mesh = outer_frame.difference(inner_cutout)
            
            # Apply window frame texture from Azure
            window_asset = self.load_azure_mesh("Z_Window4")
            if window_asset:
                frame_mesh.visual = window_asset.visual
            else:
                frame_mesh.visual.face_colors = [139, 69, 19, 255]  # Brown frame
            
            window_meshes.append(('frame', frame_mesh))
            
        except:
            # Fallback: create frame as separate pieces if boolean fails
            # Top frame
            top_frame = trimesh.creation.box(extents=[width, frame_width, thickness * 0.3])
            top_frame.vertices[:, 1] += (height - frame_width) / 2
            self.apply_window_frame_texture(top_frame)
            window_meshes.append(('frame_top', top_frame))
            
            # Bottom frame
            bottom_frame = trimesh.creation.box(extents=[width, frame_width, thickness * 0.3])
            bottom_frame.vertices[:, 1] -= (height - frame_width) / 2
            self.apply_window_frame_texture(bottom_frame)
            window_meshes.append(('frame_bottom', bottom_frame))
            
            # Left frame
            left_frame = trimesh.creation.box(extents=[frame_width, height - 2*frame_width, thickness * 0.3])
            left_frame.vertices[:, 0] -= (width - frame_width) / 2
            self.apply_window_frame_texture(left_frame)
            window_meshes.append(('frame_left', left_frame))
            
            # Right frame
            right_frame = trimesh.creation.box(extents=[frame_width, height - 2*frame_width, thickness * 0.3])
            right_frame.vertices[:, 0] += (width - frame_width) / 2
            self.apply_window_frame_texture(right_frame)
            window_meshes.append(('frame_right', right_frame))
        
        # Create glass pane (transparent)
        glass_pane = trimesh.creation.box(extents=[width - 2*frame_width, height - 2*frame_width, glass_thickness])
        
        # Apply transparent glass material
        try:
            # Create transparent glass material
            glass_material = PBRMaterial(
                name="glass_material",
                baseColorFactor=[0.8, 0.9, 1.0, 0.3],  # Light blue tint with 30% opacity
                metallicFactor=0.0,
                roughnessFactor=0.1,
                alphaMode='BLEND',
                doubleSided=True
            )
            glass_pane.visual.material = glass_material
        except:
            # Fallback: use transparent color
            glass_pane.visual.face_colors = [200, 220, 255, 76]  # Light blue, 30% opacity
        
        window_meshes.append(('glass', glass_pane))
        
        return window_meshes

    def apply_window_frame_texture(self, mesh):
        """Apply window frame texture to a mesh"""
        # Try Azure asset first
        window_asset = self.load_azure_mesh("Z_Window4")
        if window_asset and hasattr(window_asset.visual, 'material'):
            mesh.visual = window_asset.visual
        else:
            mesh.visual.face_colors = [139, 69, 19, 255]  # Brown frame

    def load_window_mesh(self, scale=1.0):
        """Load window mesh with proper transparency and texture handling"""
        # Try Azure assets first
        for window_name in ["Z_Window4", "Z_Window5"]:
            window_mesh = self.load_azure_mesh(window_name, scale)
            if window_mesh:
                # Make it transparent
                try:
                    if hasattr(window_mesh.visual, 'material'):
                        if hasattr(window_mesh.visual.material, 'baseColorFactor'):
                            # Modify existing material to be transparent
                            window_mesh.visual.material.baseColorFactor = [1.0, 1.0, 1.0, 0.4]
                            window_mesh.visual.material.alphaMode = 'BLEND'
                        else:
                            window_mesh.visual.face_colors = [200, 220, 255, 102]
                    else:
                        window_mesh.visual.face_colors = [200, 220, 255, 102]
                except:
                    window_mesh.visual.face_colors = [200, 220, 255, 102]
                
                return window_mesh
        
        # Fallback to local assets
        asset_info = self.assets.get('window')
        if not asset_info or not os.path.exists(asset_info['obj']):
            return None
        
        try:
            loaded_mesh = trimesh.load(asset_info['obj'], force='mesh')
            
            if isinstance(loaded_mesh, trimesh.Scene):
                mesh = next(iter(loaded_mesh.geometry.values()))
            elif isinstance(loaded_mesh, list):
                mesh = loaded_mesh[0] if loaded_mesh else None
            else:
                mesh = loaded_mesh
            
            if mesh is None:
                return None
            
            mesh.apply_scale(scale)
            
            # Apply window texture with improved handling
            if os.path.exists(asset_info['diffuse']):
                try:
                    diffuse_img = Image.open(asset_info['diffuse'])
                    
                    # Ensure image has alpha channel for transparency
                    if diffuse_img.mode not in ('RGBA', 'LA'):
                        diffuse_img = diffuse_img.convert('RGBA')
                    
                    # Create window material with transparency
                    material = PBRMaterial(
                        name="window_material",
                        baseColorTexture=diffuse_img,
                        baseColorFactor=[1.0, 1.0, 1.0, 0.4],  # More transparent
                        metallicFactor=0.0,
                        roughnessFactor=0.1,  # Shiny glass
                        alphaMode='BLEND',
                        doubleSided=True
                    )
                    
                    # Generate or use existing UV coordinates
                    if hasattr(mesh.visual, 'uv') and mesh.visual.uv is not None and len(mesh.visual.uv) == len(mesh.vertices):
                        # Use existing UV coordinates
                        mesh.visual = TextureVisuals(
                            uv=mesh.visual.uv,
                            image=diffuse_img,
                            material=material
                        )
                    else:
                        # Generate new UV coordinates
                        uv_coords = self.generate_window_uv_coordinates(mesh)
                        mesh.visual = TextureVisuals(
                            uv=uv_coords,
                            image=diffuse_img,
                            material=material
                        )
                        
                except Exception as e:
                    print(f"Warning: Could not load texture for window: {e}")
                    mesh.visual.face_colors = [200, 220, 255, 102]  # Light blue, 40% opacity
            else:
                mesh.visual.face_colors = [200, 220, 255, 102]  # Light blue, 40% opacity
            
            return mesh
            
        except Exception as e:
            print(f"Error loading window mesh: {e}")
            return None

    def calculate_hole_position(self, hole_data, line_data, vertices_data):
        """Calculate the exact position and dimensions of a hole in a wall"""
        v_ids = line_data.get('vertices', [])
        if len(v_ids) != 2 or not all(v_id in vertices_data for v_id in v_ids):
            return None
            
        v1, v2 = vertices_data[v_ids[0]], vertices_data[v_ids[1]]
        p1 = np.array([v1['x']/100.0, -v1['y']/100.0])
        p2 = np.array([v2['x']/100.0, -v2['y']/100.0])
        
        vec = p2 - p1
        length = np.linalg.norm(vec)
        if length == 0:
            return None
            
        direction = vec / length
        normal = np.array([-direction[1], direction[0]])
        
        # Get hole properties using the same method as working version
        hole_width = self.cm_to_m(hole_data['properties']['width'])
        hole_height = self.cm_to_m(hole_data['properties']['height'])
        hole_thickness = self.cm_to_m(hole_data['properties']['thickness'])
        hole_altitude = self.cm_to_m(hole_data['properties']['altitude'])
        wall_thickness = self.cm_to_m(line_data['properties']['thickness'])
        
        offset = hole_data.get('offset', 0.5)
        hole_center = p1 + direction * (length * offset)
        hole_start = hole_center - direction * (hole_width / 2 + 0.001)
        hole_end = hole_center + direction * (hole_width / 2 + 0.001)
        
        return {
            'center': hole_center,
            'start': hole_start,
            'end': hole_end,
            'direction': direction,
            'normal': normal,
            'width': hole_width,
            'height': hole_height,
            'thickness': max(hole_thickness, wall_thickness),
            'altitude': hole_altitude,
            'wall_thickness': wall_thickness,
            'wall_start': p1,
            'wall_end': p2,
            'wall_length': length
        }

   
    def create_door_mesh(self, hole_data, line_data, vertices_data):
        """Create and position door mesh with reduced thickness"""
        hole_info = self.calculate_hole_position(hole_data, line_data, vertices_data)
        if not hole_info:
            return None

        door_mesh = self.load_door_mesh()
        if not door_mesh:
            door_mesh = trimesh.creation.box(
                extents=[hole_info['width'], hole_info['height'], hole_info['wall_thickness']]
            )
            door_mesh.visual.face_colors = [139, 69, 19, 255]

        bbox = door_mesh.bounds
        original_size = bbox[1] - bbox[0]
        
        # --- NaN FIX ---
        # Check for zero dimensions to prevent division by zero (NaN error)
        if any(s < 1e-6 for s in original_size):
            print(f"Warning: Skipping door mesh for hole {hole_data['id']} due to invalid original dimensions: {original_size}")
            return None
        # --- END FIX ---

        door_thickness = hole_info['wall_thickness'] * 0.8
        
        scale_factors = np.array([
            hole_info['width'] / original_size[0],
            hole_info['height'] / original_size[1],
            door_thickness / original_size[2]
        ])
        door_mesh.apply_scale(scale_factors)

        door_mesh.vertices -= door_mesh.centroid

        angle = math.atan2(hole_info['direction'][1], hole_info['direction'][0])
        rotation = trimesh.transformations.rotation_matrix(angle, [0, 1, 0])
        door_mesh.apply_transform(rotation)

        door_mesh.vertices[:, 0] += hole_info['center'][0]
        door_mesh.vertices[:, 1] += hole_info['altitude'] + hole_info['height'] / 2
        door_mesh.vertices[:, 2] += hole_info['center'][1]

        door_mesh.metadata = {
            'source': hole_data['id'], 
            'type': 'door',
            'door_thickness': door_thickness,
            'wall_thickness': hole_info['wall_thickness']
        }

        return door_mesh

   
    def create_window_mesh(self, hole_data, line_data, vertices_data):
        """Create and position window mesh with frame and transparent glass"""
        hole_info = self.calculate_hole_position(hole_data, line_data, vertices_data)
        if not hole_info:
            return []

        print(f"Creating window for hole {hole_data['id']}")

        window_mesh = self.load_window_mesh()
        
        if window_mesh:
            bbox = window_mesh.bounds
            original_size = bbox[1] - bbox[0]
            
            # --- NaN FIX ---
            if any(s < 1e-6 for s in original_size):
                print(f"Warning: Skipping window mesh for hole {hole_data['id']} due to invalid original dimensions: {original_size}")
                return []
            # --- END FIX ---

            window_thickness = hole_info['wall_thickness'] * 0.6

            scale_factors = np.array([
                hole_info['width'] / original_size[0],
                hole_info['height'] / original_size[1],
                window_thickness / original_size[2]
            ])
            window_mesh.apply_scale(scale_factors)
            window_mesh.vertices -= window_mesh.centroid

            angle = math.atan2(hole_info['direction'][1], hole_info['direction'][0])
            rotation = trimesh.transformations.rotation_matrix(angle, [0, 1, 0])
            window_mesh.apply_transform(rotation)

            window_mesh.vertices[:, 0] += hole_info['center'][0]
            window_mesh.vertices[:, 1] += hole_info['altitude'] + hole_info['height'] / 2
            window_mesh.vertices[:, 2] += hole_info['center'][1]

            window_mesh.metadata = {
                'source': hole_data['id'], 
                'type': 'window',
                'window_thickness': window_thickness,
                'wall_thickness': hole_info['wall_thickness']
            }
            
            return [window_mesh]
        else:
            # Fallback to creating custom window if loading fails
            window_components = self.create_window_frame_and_glass(hole_info)
            positioned_meshes = []
            
            for component_name, mesh in window_components:
                if mesh is None: continue
                mesh.vertices -= mesh.centroid
                angle = math.atan2(hole_info['direction'][1], hole_info['direction'][0])
                rotation = trimesh.transformations.rotation_matrix(angle, [0, 1, 0])
                mesh.apply_transform(rotation)
                mesh.vertices[:, 0] += hole_info['center'][0]
                mesh.vertices[:, 1] += hole_info['altitude'] + hole_info['height'] / 2
                mesh.vertices[:, 2] += hole_info['center'][1]
                mesh.metadata = {
                    'source': hole_data['id'], 
                    'type': f'window_{component_name}',
                    'wall_thickness': hole_info['wall_thickness']
                }
                positioned_meshes.append(mesh)
            
            return positioned_meshes
        
   
    # def place_items_from_json(self, items_data: Dict[str, Any]) -> List[trimesh.Trimesh]:
    #     """Creates and places meshes for items defined in the JSON data with scaling support."""
    #     item_meshes = []
    #     if not items_data:
    #         return []

    #     print(f"Placing {len(items_data)} items from JSON data...")
    #     for item_id, item_data in items_data.items():
    #         try:
    #             item_type = item_data.get('type')
    #             if not item_type:
    #                 print(f"Warning: Skipping item {item_id} because it has no 'type'.")
    #                 continue
                
    #             # --- FIX: Make lookup more robust ---
    #             item_type_lower = item_type.lower()
                
    #             # First, check if the item_type is a specific asset name (e.g., 'z_bed1')
    #             if item_type_lower in self.reverse_class_mapping:
    #                 # If so, use the proper-cased asset name from the reverse map
    #                 actual_item_type = self.reverse_class_mapping[item_type_lower]
    #             # Second, check if it's a generic type (e.g., 'bed')
    #             elif item_type_lower in self.class_mapping:
    #                 actual_item_type = item_type_lower
    #             else:
    #                 # If neither, we'll log a warning and use the original type
    #                 print(f"Warning: No asset mapping found for item type '{item_type}'. A fallback box will be created.")
    #                 actual_item_type = item_type_lower
    #             # --- END FIX ---

    #             # Convert position from cm to meters (and flip y-axis)
    #             pos_x = self.cm_to_m(item_data.get('x', 0))
    #             pos_z = -self.cm_to_m(item_data.get('y', 0)) # JSON 'y' is our 'z'
    #             pos_y = 0.0 # Altitude from floor

    #             # Convert rotation from degrees to radians
    #             rotation_deg = float(item_data.get('rotation', 0.0))
    #             rotation_rad = math.radians(rotation_deg)

    #             # Get scale from JSON data (default to 1.0 if not specified)
    #             scale = item_data.get('scale', 1.0)
    #             if isinstance(scale, dict):
    #                 # Handle per-axis scaling: {"x": 1.0, "y": 1.0, "z": 1.0}
    #                 scale_x = float(scale.get('x', 1.0))
    #                 scale_y = float(scale.get('y', 1.0)) 
    #                 scale_z = float(scale.get('z', 1.0))
    #                 scale = np.array([scale_x, scale_y, scale_z])
    #                 print(f"Item {item_id}: Using per-axis scaling {scale}")
    #             elif isinstance(scale, (list, tuple)) and len(scale) == 3:
    #                 # Handle array-style scaling [x, y, z]
    #                 scale = np.array([float(s) for s in scale])
    #                 print(f"Item {item_id}: Using per-axis scaling {scale}")
    #             else:
    #                 # Handle uniform scaling
    #                 scale = float(scale)
    #                 if scale != 1.0:
    #                     print(f"Item {item_id}: Using uniform scaling {scale}")

    #             # Create the furniture mesh with scaling
    #             mesh = self.create_furniture_mesh(
    #                 item_type=actual_item_type,
    #                 position=np.array([pos_x, pos_y, pos_z]),
    #                 rotation=rotation_rad,
    #                 scale=scale
    #             )

    #             if mesh:
    #                 item_meshes.append(mesh)

    #         except Exception as e:
    #             print(f"Error processing item {item_id}: {e}")
    #             continue
        
    #     return item_meshes

    def is_perimeter_wall(self, line_data, vertices_data, areas_data):
        """Determine if a wall is on the perimeter"""
        if not areas_data:
            return True
        
        line_id = line_data['id']
        v_ids = line_data.get('vertices', [])
        if len(v_ids) != 2:
            return True
        
        areas_using_wall = 0
        wall_vertices = set(v_ids)
        
        for area_id, area_data in areas_data.items():
            area_vertices = area_data.get('vertices', [])
            if len(area_vertices) < 3:
                continue
                
            area_vertex_list = area_vertices + [area_vertices[0]]
            
            for i in range(len(area_vertex_list) - 1):
                edge_vertices = {area_vertex_list[i], area_vertex_list[i + 1]}
                if edge_vertices == wall_vertices:
                    areas_using_wall += 1
                    break
        
        return areas_using_wall <= 1

    def create_wall_material(self, wall_type='inner'):
        """Create wall material with diffuse and normal textures"""
        asset_info = self.assets.get(f'wall_{wall_type}')
        if not asset_info:
            return None, None
        
        try:
            if os.path.exists(asset_info['diffuse']):
                diffuse_img = Image.open(asset_info['diffuse'])
                
                if os.path.exists(asset_info['normal']):
                    normal_img = Image.open(asset_info['normal'])
                    material = PBRMaterial(
                        name=f"wall_{wall_type}_material",
                        baseColorTexture=diffuse_img,
                        normalTexture=normal_img,
                        roughnessFactor=0.8,
                        metallicFactor=0.0,
                        doubleSided=True
                    )
                else:
                    material = PBRMaterial(
                        name=f"wall_{wall_type}_material",
                        baseColorTexture=diffuse_img,
                        roughnessFactor=0.8,
                        metallicFactor=0.0,
                        doubleSided=True
                    )
                
                return material, diffuse_img
            else:
                return None, None
                
        except Exception as e:
            print(f"Error loading wall {wall_type} material: {e}")
            return None, None

    def apply_wall_texture(self, mesh, wall_type='inner', uv_scale=(1.0, 1.0), wall_length=1.0, wall_height=1.0):
        """Apply texture to a wall mesh"""
        material, diffuse_img = self.create_wall_material(wall_type)
        
        if material and diffuse_img:
            try:
                uv_coords = self.generate_proper_wall_uv(mesh, wall_length, wall_height, uv_scale)
                mesh.visual = TextureVisuals(
                    uv=uv_coords,
                    image=diffuse_img,
                    material=material
                )
            except Exception as e:
                print(f"Warning: Could not apply {wall_type} wall texture: {e}")
                if wall_type == 'outer':
                    mesh.visual.face_colors = [220, 220, 220, 255]
                else:
                    mesh.visual.face_colors = [200, 180, 160, 255]
        else:
            if wall_type == 'outer':
                mesh.visual.face_colors = [220, 220, 220, 255]
            else:
                mesh.visual.face_colors = [200, 180, 160, 255]

    def generate_proper_wall_uv(self, mesh, wall_length=1.0, wall_height=1.0, uv_scale=(1.0, 1.0)):
        """Generate proper UV coordinates for wall meshes"""
        try:
            vertices = mesh.vertices
            bounds = mesh.bounds
            size = bounds[1] - bounds[0]
            
            if size[0] == 0 or size[1] == 0 or size[2] == 0:
                return np.zeros((len(vertices), 2))
            
            width_axis = 0 if size[0] > size[2] else 2
            height_axis = 1
            
            TEXTURE_SCALE = 1.0
            tiles_u = max(0.5, wall_length / TEXTURE_SCALE) * uv_scale[0]
            tiles_v = max(0.5, wall_height / TEXTURE_SCALE) * uv_scale[1]
            
            uv_coords = np.zeros((len(vertices), 2))
            
            for i, vertex in enumerate(vertices):
                u = (vertex[width_axis] - bounds[0][width_axis]) / size[width_axis]
                v = (vertex[height_axis] - bounds[0][height_axis]) / size[height_axis]
                u = u * tiles_u
                v = v * tiles_v
                uv_coords[i] = [u, v]
            
            return uv_coords
            
        except Exception as e:
            print(f"Error generating wall UV coordinates: {e}")
            return np.zeros((len(mesh.vertices), 2))

    # def process_wall(self, line_data, vertices_data, holes_data, areas_data=None):
    #     """Create a wall with door/window holes and proper texture application"""
    #     line_id = line_data['id']
    #     print(f"Processing wall: {line_id}")

    #     v_ids = line_data.get('vertices', [])
    #     if len(v_ids) != 2 or not all(v_id in vertices_data for v_id in v_ids):
    #         print(f"  -> Skipping wall {line_id} due to invalid vertices.")
    #         return [], []

    #     v1, v2 = vertices_data[v_ids[0]], vertices_data[v_ids[1]]
    #     p1 = np.array([v1['x'] / 100.0, -v1['y'] / 100.0])
    #     p2 = np.array([v2['x'] / 100.0, -v2['y'] / 100.0])

    #     props = line_data['properties']
    #     wall_height = self.cm_to_m(props['height'])
    #     wall_thickness = self.cm_to_m(props['thickness'])

    #     vec = p2 - p1
    #     length = np.linalg.norm(vec)
    #     if length == 0:
    #         return [], []

    #     direction = vec / length
    #     normal = np.array([-direction[1], direction[0]])

    #     # Determine wall type
    #     wall_type = 'outer' if self.is_perimeter_wall(line_data, vertices_data, areas_data) else 'inner'
        
    #     wall_holes = [h for h in holes_data.values() if h.get('line') == line_id]
    #     wall_meshes = []

    #     # Create base wall polygon
    #     outer_pts = [
    #         p1 - normal * wall_thickness / 2,
    #         p2 - normal * wall_thickness / 2,
    #         p2 + normal * wall_thickness / 2,
    #         p1 + normal * wall_thickness / 2
    #     ]
    #     base_wall_poly = Polygon(outer_pts)

    #     # Create hole polygons
    #     cut_polys = []
    #     hole_patch_data = []

    #     for hole in wall_holes:
    #         hole_info = self.calculate_hole_position(hole, line_data, vertices_data)
    #         if not hole_info:
    #             continue

    #         hole_poly_2d = Polygon([
    #             hole_info['start'] - normal * (wall_thickness / 2 + 0.001),
    #             hole_info['end']   - normal * (wall_thickness / 2 + 0.001),
    #             hole_info['end']   + normal * (wall_thickness / 2 + 0.001),
    #             hole_info['start'] + normal * (wall_thickness / 2 + 0.001),
    #         ])

    #         cut_polys.append(hole_poly_2d)
    #         hole_patch_data.append({
    #             'start': hole_info['start'],
    #             'end': hole_info['end'],
    #             'altitude': hole_info['altitude'],
    #             'height': hole_info['height']
    #         })

    #     # Subtract holes from wall
    #     try:
    #         main_poly = base_wall_poly.difference(unary_union(cut_polys)) if cut_polys else base_wall_poly

    #         if main_poly.is_valid and not main_poly.is_empty:
    #             polys = main_poly.geoms if isinstance(main_poly, MultiPolygon) else [main_poly]
    #             for poly in polys:
    #                 if poly.area > 0.001:
    #                     mesh = trimesh.creation.extrude_polygon(poly, wall_height)
    #                     mesh.vertices = mesh.vertices[:, [0, 2, 1]]
    #                     self.apply_wall_texture(mesh, wall_type, (1.0, 1.0), length, wall_height)
    #                     wall_meshes.append(mesh)
                        
    #     except Exception as e:
    #         print(f"  -> Error subtracting holes from wall {line_id}: {e}")
    #         return [], []

    #     # Add patches around holes
    #     for hole in hole_patch_data:
    #         start = hole['start']
    #         end = hole['end']
    #         altitude = hole['altitude']
    #         height = hole['height']

    #         hole_dir = end - start
    #         hole_len = np.linalg.norm(hole_dir)
    #         if hole_len == 0:
    #             continue
    #         hole_dir /= hole_len
    #         hole_normal = np.array([-hole_dir[1], hole_dir[0]])

    #         # Bottom patch
    #         if altitude > 0.02:
    #             bottom_poly = Polygon([
    #                 start - hole_normal * wall_thickness / 2,
    #                 end - hole_normal * wall_thickness / 2,
    #                 end + hole_normal * wall_thickness / 2,
    #                 start + hole_normal * wall_thickness / 2
    #             ])
    #             bottom_wall = trimesh.creation.extrude_polygon(bottom_poly, altitude)
    #             bottom_wall.vertices = bottom_wall.vertices[:, [0, 2, 1]]
    #             self.apply_wall_texture(bottom_wall, wall_type, (1.0, 1.0), hole_len, altitude)
    #             wall_meshes.append(bottom_wall)

    #         # Top patch
    #         hole_top = altitude + height
    #         if hole_top < wall_height - 0.02:
    #             top_poly = Polygon([
    #                 start - hole_normal * wall_thickness / 2,
    #                 end - hole_normal * wall_thickness / 2,
    #                 end + hole_normal * wall_thickness / 2,
    #                 start + hole_normal * wall_thickness / 2
    #             ])
    #             top_wall = trimesh.creation.extrude_polygon(top_poly, wall_height - hole_top)
    #             top_wall.vertices = top_wall.vertices[:, [0, 2, 1]]
    #             top_wall.vertices[:, 1] += hole_top
    #             self.apply_wall_texture(top_wall, wall_type, (1.0, 1.0), hole_len, wall_height - hole_top)
    #             wall_meshes.append(top_wall)

    #     return wall_meshes, []


    def process_wall(self, line_data, vertices_data, holes_data, areas_data=None, start_extension=0.0, end_extension=0.0):
        """
        Create a wall with door/window holes and proper texture application.
        Accepts extensions to lengthen the wall at each end for seamless corners.
        
        Args:
            line_data (dict): Data for the wall line.
            vertices_data (dict): Data for all vertices in the scene.
            holes_data (dict): Data for all holes (doors/windows).
            areas_data (dict): Data for all areas, used to determine if a wall is outer/inner.
            start_extension (float): Distance to extend the wall at its starting point.
            end_extension (float): Distance to extend the wall at its ending point.
        """
        line_id = line_data['id']
        # Optional debug print:
        # print(f"Processing wall: {line_id} with extensions Start:{start_extension}, End:{end_extension}")

        v_ids = line_data.get('vertices', [])
        if len(v_ids) != 2 or not all(v_id in vertices_data for v_id in v_ids):
            print(f"  -> Skipping wall {line_id} due to invalid vertices.")
            return [], []

        v1, v2 = vertices_data[v_ids[0]], vertices_data[v_ids[1]]
        p1 = np.array([v1['x'] / 100.0, -v1['y'] / 100.0])
        p2 = np.array([v2['x'] / 100.0, -v2['y'] / 100.0])

        props = line_data['properties']
        wall_height = self.cm_to_m(props['height'])
        wall_thickness = self.cm_to_m(props['thickness'])

        vec = p2 - p1
        length = np.linalg.norm(vec)
        if length == 0:
            return [], []

        direction = vec / length
        normal = np.array([-direction[1], direction[0]])

        # --- CORNER FIX: Apply extensions to the wall endpoints ---
        p1_extended = p1 - direction * start_extension
        p2_extended = p2 + direction * end_extension
        total_length_for_uv = length + start_extension + end_extension
        # --- END FIX ---

        # Determine wall type (inner vs. outer)
        wall_type = 'outer' if self.is_perimeter_wall(line_data, vertices_data, areas_data) else 'inner'
        
        wall_holes = [h for h in holes_data.values() if h.get('line') == line_id]
        wall_meshes = []

        # Create base wall polygon using the extended points
        outer_pts = [
            p1_extended - normal * wall_thickness / 2,
            p2_extended - normal * wall_thickness / 2,
            p2_extended + normal * wall_thickness / 2,
            p1_extended + normal * wall_thickness / 2
        ]
        base_wall_poly = Polygon(outer_pts)

        # Create polygons for holes (these are based on original wall geometry)
        cut_polys = []
        hole_patch_data = [] # Data for creating sills/lintels

        for hole in wall_holes:
            hole_info = self.calculate_hole_position(hole, line_data, vertices_data)
            if not hole_info:
                continue

            hole_poly_2d = Polygon([
                hole_info['start'] - normal * (wall_thickness / 2 + 0.001),
                hole_info['end']   - normal * (wall_thickness / 2 + 0.001),
                hole_info['end']   + normal * (wall_thickness / 2 + 0.001),
                hole_info['start'] + normal * (wall_thickness / 2 + 0.001),
            ])

            cut_polys.append(hole_poly_2d)
            hole_patch_data.append({
                'start': hole_info['start'],
                'end': hole_info['end'],
                'altitude': hole_info['altitude'],
                'height': hole_info['height']
            })

        # Subtract holes from the extended wall polygon
        try:
            main_poly = base_wall_poly.difference(unary_union(cut_polys)) if cut_polys else base_wall_poly

            if main_poly.is_valid and not main_poly.is_empty:
                polys = main_poly.geoms if isinstance(main_poly, MultiPolygon) else [main_poly]
                for poly in polys:
                    if poly.area > 0.001:
                        mesh = trimesh.creation.extrude_polygon(poly, wall_height)
                        mesh.vertices = mesh.vertices[:, [0, 2, 1]]
                        # Use the new total length for correct UV scaling
                        self.apply_wall_texture(mesh, wall_type, (1.0, 1.0), total_length_for_uv, wall_height)
                        wall_meshes.append(mesh)
                        
        except Exception as e:
            print(f"  -> Error subtracting holes from wall {line_id}: {e}")
            return [], []

        # Add patches (sills/lintels) around holes. This logic remains unchanged as it
        # operates on the original hole geometry, not the extended wall.
        for hole in hole_patch_data:
            start = hole['start']
            end = hole['end']
            altitude = hole['altitude']
            height = hole['height']

            hole_dir = end - start
            hole_len = np.linalg.norm(hole_dir)
            if hole_len == 0: continue
            hole_dir /= hole_len
            hole_normal = np.array([-hole_dir[1], hole_dir[0]])

            # Bottom patch (sill)
            if altitude > 0.02:
                bottom_poly = Polygon([
                    start - hole_normal * wall_thickness / 2,
                    end - hole_normal * wall_thickness / 2,
                    end + hole_normal * wall_thickness / 2,
                    start + hole_normal * wall_thickness / 2
                ])
                bottom_wall = trimesh.creation.extrude_polygon(bottom_poly, altitude)
                bottom_wall.vertices = bottom_wall.vertices[:, [0, 2, 1]]
                self.apply_wall_texture(bottom_wall, wall_type, (1.0, 1.0), hole_len, altitude)
                wall_meshes.append(bottom_wall)

            # Top patch (lintel)
            hole_top = altitude + height
            if hole_top < wall_height - 0.02:
                top_poly = Polygon([
                    start - hole_normal * wall_thickness / 2,
                    end - hole_normal * wall_thickness / 2,
                    end + hole_normal * wall_thickness / 2,
                    start + hole_normal * wall_thickness / 2
                ])
                top_wall = trimesh.creation.extrude_polygon(top_poly, wall_height - hole_top)
                top_wall.vertices = top_wall.vertices[:, [0, 2, 1]]
                top_wall.vertices[:, 1] += hole_top
                self.apply_wall_texture(top_wall, wall_type, (1.0, 1.0), hole_len, wall_height - hole_top)
                wall_meshes.append(top_wall)

        return wall_meshes, []

    def create_door_window_meshes(self, holes_data, lines_data, vertices_data):
        """Create door and window meshes separately"""
        print("Creating door and window meshes...")
        
        door_meshes = []
        window_meshes = []
        
        for hole_id, hole_data in holes_data.items():
            line_id = hole_data.get('line')
            if not line_id or line_id not in lines_data:
                continue
                
            line_data = lines_data[line_id]
            hole_type = hole_data.get('type', '').lower()
            
            try:
                if 'door' in hole_type:
                    door_mesh = self.create_door_mesh(hole_data, line_data, vertices_data)
                    if door_mesh:
                        door_meshes.append(door_mesh)
                elif 'window' in hole_type:
                    window_mesh_components = self.create_window_mesh(hole_data, line_data, vertices_data)
                    if window_mesh_components:
                        window_meshes.extend(window_mesh_components)
            except Exception as e:
                print(f"  -> Error creating {hole_type} {hole_id}: {e}")
        
        return door_meshes + window_meshes

    def create_comprehensive_floor_mesh(self, areas_data, vertices_data, lines_data, holes_data):
        """Create a floor mesh that covers all rooms with door holes"""
        print("Creating comprehensive floor mesh...")
        
        if not areas_data or not vertices_data:
            return None
        
        room_polygons = []
        door_hole_polygons = []
        
        for area_id, area_data in areas_data.items():
            vertex_ids = area_data.get('vertices', [])
            if len(vertex_ids) < 3:
                continue
                
            points_2d = []
            for v_id in vertex_ids:
                if v_id in vertices_data:
                    points_2d.append([
                        vertices_data[v_id]['x'] / 100.0, 
                        -vertices_data[v_id]['y'] / 100.0
                    ])
            
            if len(points_2d) < 3:
                continue
                
            try:
                room_polygon = Polygon(points_2d)
                if room_polygon.is_valid and not room_polygon.is_empty:
                    room_polygons.append(room_polygon)
            except Exception as e:
                continue
        
        # Create door holes in floor
        for hole_id, hole_data in holes_data.items():
            if hole_data.get('type') != 'door':
                continue
                
            line_id = hole_data.get('line')
            if not line_id or line_id not in lines_data:
                continue
                
            line_data = lines_data[line_id]
            hole_info = self.calculate_hole_position(hole_data, line_data, vertices_data)
            if not hole_info:
                continue
            
            # Create a thin rectangle polygon for the door hole
            door_hole_rect = [
                hole_info['start'] - hole_info['normal'] * hole_info['wall_thickness'] / 2,
                hole_info['end'] - hole_info['normal'] * hole_info['wall_thickness'] / 2,
                hole_info['end'] + hole_info['normal'] * hole_info['wall_thickness'] / 2,
                hole_info['start'] + hole_info['normal'] * hole_info['wall_thickness'] / 2
            ]
            
            try:
                door_hole = Polygon(door_hole_rect)
                if door_hole.is_valid and not door_hole.is_empty:
                    door_hole_polygons.append(door_hole)
            except Exception as e:
                print(f"Warning: Could not create polygon for door hole {hole_id}: {e}")
                continue
        
        if not room_polygons:
            print("  -> No valid room polygons found for floor creation.")
            return None
        
        try:
            # Union all room polygons to form a single floor plan
            unified_floor = unary_union(room_polygons)
            
            # If the union results in multiple disjoint polygons, take the largest one
            if isinstance(unified_floor, MultiPolygon):
                unified_floor = max(unified_floor.geoms, key=lambda p: p.area)
            
            # Subtract door holes from the unified floor
            if door_hole_polygons:
                holes_union = unary_union(door_hole_polygons)
                unified_floor = unified_floor.difference(holes_union)
            
            # Extrude the final polygon to create the floor mesh
            floor_mesh = trimesh.creation.extrude_polygon(unified_floor, height=0.02) # 2cm thick floor
            floor_mesh.vertices = floor_mesh.vertices[:, [0, 2, 1]] # Swap Y and Z axes
            
            # Ensure the floor is facing up
            if np.mean(floor_mesh.face_normals[:, 1]) < 0:
                floor_mesh.invert()
                
            floor_mesh.visual.face_colors = [200, 200, 200, 255] # Light grey floor
            return floor_mesh
            
        except Exception as e:
            print(f"  -> Could not create comprehensive floor: {e}")
            return None

    def create_basement_floor(self, vertices_data, padding=1.0):
        """Create a basement floor that fully covers the building"""
        print("Creating basement floor...")
        
        if not vertices_data:
            return None
        
        x_coords = [v['x']/100.0 for v in vertices_data.values()]
        z_coords = [-v['y']/100.0 for v in vertices_data.values()]
        
        min_x, max_x = min(x_coords), max(x_coords)
        min_z, max_z = min(z_coords), max(z_coords)
        
        basement_points = [
            [min_x - padding, min_z - padding],
            [max_x + padding, min_z - padding],
            [max_x + padding, max_z + padding],
            [min_x - padding, max_z + padding]
        ]
        
        try:
            basement_polygon = Polygon(basement_points)
            basement_mesh = trimesh.creation.extrude_polygon(basement_polygon, height=0.1)
            basement_mesh.vertices = basement_mesh.vertices[:, [0, 2, 1]]
            basement_mesh.vertices[:, 1] -= 0.15 # Position it slightly below the main floor
            
            if np.mean(basement_mesh.face_normals[:, 1]) < 0:
                basement_mesh.invert()
            
            basement_mesh.visual.face_colors = [100, 100, 100, 255] # Dark grey
            return basement_mesh
        except Exception as e:
            print(f"  -> Could not create basement floor: {e}")
            return None

    def center_scene(self, scene, vertices_data):
        """Center the scene at origin"""
        if scene.is_empty or not vertices_data:
            return scene
        
        x_coords = [v['x']/100.0 for v in vertices_data.values()]
        z_coords = [-v['y']/100.0 for v in vertices_data.values()]
        
        center_x = (min(x_coords) + max(x_coords)) / 2
        center_z = (min(z_coords) + max(z_coords)) / 2
        
        centering_transform = trimesh.transformations.translation_matrix([-center_x, 0, -center_z])
        
        scene.apply_transform(centering_transform)
        
        print(f"Centered scene at origin (offset: {-center_x:.2f}, 0, {-center_z:.2f})")
        return scene

   
    def debug_azure_assets(self):
        """Debug function to list all available Azure assets"""
        print(f"\n=== Available Azure Assets ({len(self.azure_manager.assets_data)}) ===")
        for asset_name, asset_info in self.azure_manager.assets_data.items():
            metadata = asset_info.get('3D_asset_metadata', {})
            dimensions = metadata.get('dimensions', {})
            print(f"Asset: {asset_name}")
            print(f"  - Dimensions: {dimensions}")
            print(f"  - Has OBJ: {'OBJ_File_URL' in asset_info.get('3D_asset_file_paths_urls', {})}")
            print(f"  - Has Texture: {'texture_url' in metadata}")
            print("  ---")
        print("=== End Azure Assets ===\n")

    # def place_items_from_json_with_debug(self, items_data: Dict[str, Any]) -> List[trimesh.Trimesh]:
    #     """Enhanced version with debugging"""
    #     # First, debug available assets
    #     self.debug_azure_assets()
        
    #     item_meshes = []
    #     if not items_data:
    #         return []

    #     print(f"Placing {len(items_data)} items from JSON data...")
        
    #     for item_id, item_data in items_data.items():
    #         try:
    #             item_type = item_data.get('type')
    #             if not item_type:
    #                 print(f"Warning: Skipping item {item_id} because it has no 'type'.")
    #                 continue
                
    #             print(f"\n--- Processing item {item_id} of type '{item_type}' ---")
                
    #             # Enhanced lookup logic
    #             item_type_lower = item_type.lower()
    #             actual_item_type = item_type  # Default to original
                
    #             # Check direct Azure asset existence first
    #             if item_type in self.azure_manager.assets_data:
    #                 actual_item_type = item_type
    #                 print(f"Found direct Azure asset match: {item_type}")
    #             elif item_type_lower in self.reverse_class_mapping:
    #                 actual_item_type = self.reverse_class_mapping[item_type_lower] 
    #                 print(f"Found reverse mapping: {item_type_lower} -> {actual_item_type}")
    #             elif item_type_lower in self.class_mapping:
    #                 actual_item_type = item_type_lower
    #                 print(f"Found in class mapping: {item_type_lower}")
    #             else:
    #                 print(f"No mapping found for '{item_type}', will search Azure assets...")

    #             # Convert position from cm to meters
    #             pos_x = self.cm_to_m(item_data.get('x', 0))
    #             pos_z = -self.cm_to_m(item_data.get('y', 0))
    #             pos_y = 0.0

    #             # Convert rotation
    #             rotation_deg = float(item_data.get('rotation', 0.0))
    #             rotation_rad = math.radians(rotation_deg)

    #             # Create the mesh
    #             mesh = self.create_furniture_mesh(
    #                 item_type=actual_item_type,
    #                 position=np.array([pos_x, pos_y, pos_z]),
    #                 rotation=rotation_rad
    #             )

    #             if mesh:
    #                 item_meshes.append(mesh)
    #                 print(f"Successfully created mesh for {item_id}")
    #             else:
    #                 print(f"Failed to create mesh for {item_id}")

    #         except Exception as e:
    #             print(f"Error processing item {item_id}: {e}")
    #             continue
        
    #     return item_meshes


    # def place_items_from_json_with_debug(self, items_data: Dict[str, Any]) -> List[trimesh.Trimesh]:
    #     """Enhanced version with debugging and scaling support"""
    #     # First, debug available assets
    #     self.debug_azure_assets()
        
    #     item_meshes = []
    #     if not items_data:
    #         return []

    #     print(f"Placing {len(items_data)} items from JSON data...")
        
    #     for item_id, item_data in items_data.items():
    #         try:
    #             item_type = item_data.get('type')
    #             if not item_type:
    #                 print(f"Warning: Skipping item {item_id} because it has no 'type'.")
    #                 continue
                
    #             print(f"\n--- Processing item {item_id} of type '{item_type}' ---")
                
    #             # Enhanced lookup logic
    #             item_type_lower = item_type.lower()
    #             actual_item_type = item_type  # Default to original
                
    #             # Check direct Azure asset existence first
    #             if item_type in self.azure_manager.assets_data:
    #                 actual_item_type = item_type
    #                 print(f"Found direct Azure asset match: {item_type}")
    #             elif item_type_lower in self.reverse_class_mapping:
    #                 actual_item_type = self.reverse_class_mapping[item_type_lower] 
    #                 print(f"Found reverse mapping: {item_type_lower} -> {actual_item_type}")
    #             elif item_type_lower in self.class_mapping:
    #                 actual_item_type = item_type_lower
    #                 print(f"Found in class mapping: {item_type_lower}")
    #             else:
    #                 print(f"No mapping found for '{item_type}', will search Azure assets...")

    #             # Convert position from cm to meters
    #             pos_x = self.cm_to_m(item_data.get('x', 0))
    #             pos_z = -self.cm_to_m(item_data.get('y', 0))
    #             pos_y = 0.0

    #             # Convert rotation
    #             rotation_deg = float(item_data.get('rotation', 0.0))
    #             rotation_rad = math.radians(rotation_deg)

    #             # Get scale from JSON data (default to 1.0 if not specified)
    #             scale = item_data.get('scale', 1.0)
    #             if isinstance(scale, dict):
    #                 # Handle per-axis scaling: {"x": 1.0, "y": 1.0, "z": 1.0}
    #                 scale_x = float(scale.get('x', 1.0))
    #                 scale_y = float(scale.get('y', 1.0)) 
    #                 scale_z = float(scale.get('z', 1.0))
    #                 scale = np.array([scale_x, scale_y, scale_z])
    #                 print(f"Item {item_id}: Using per-axis scaling {scale}")
    #             elif isinstance(scale, (list, tuple)) and len(scale) == 3:
    #                 # Handle array-style scaling [x, y, z]
    #                 scale = np.array([float(s) for s in scale])
    #                 print(f"Item {item_id}: Using per-axis scaling {scale}")
    #             else:
    #                 # Handle uniform scaling
    #                 scale = float(scale)
    #                 if scale != 1.0:
    #                     print(f"Item {item_id}: Using uniform scaling {scale}")

    #             # Create the mesh with scaling
    #             mesh = self.create_furniture_mesh(
    #                 item_type=actual_item_type,
    #                 position=np.array([pos_x, pos_y, pos_z]),
    #                 rotation=rotation_rad,
    #                 scale=scale
    #             )

    #             if mesh:
    #                 item_meshes.append(mesh)
    #                 print(f"Successfully created mesh for {item_id}")
    #             else:
    #                 print(f"Failed to create mesh for {item_id}")

    #         except Exception as e:
    #             print(f"Error processing item {item_id}: {e}")
    #             continue
        
    #     return item_meshes

    # def convert_json_to_glb(self, json_path: str, output_base_path: str,
    #                       scale: float = 1.0, texture_resolution: int = 1024) -> Dict[str, str]:
    #     """Main function to convert JSON to GLB and other formats"""
    #     print(f"Loading JSON from: {json_path}")
    #     try:
    #         with open(json_path, 'r') as f:
    #             data = json.load(f)
    #     except Exception as e:
    #         raise Exception(f"Failed to load JSON file: {str(e)}")

    #     try:
    #         layer = data['layers']['layer-1']
    #         vertices = layer['vertices']
    #         lines = layer['lines']
    #         holes = layer.get('holes', {})
    #         areas = layer.get('areas', {})
    #         items = layer.get('items', {}) # Get items from JSON
    #     except KeyError as e:
    #         raise Exception(f"Invalid JSON structure: missing key {str(e)}")

    #     print(f"Processing {len(vertices)} vertices, {len(lines)} lines, {len(holes)} holes, {len(areas)} areas, {len(items)} items")

    #     scene = trimesh.Scene()

    #     # 1. Add basement floor
    #     basement = self.create_basement_floor(vertices)
    #     if basement: scene.add_geometry(basement, node_name='basement')

    #     # 2. Add main floor
    #     floor_mesh = self.create_comprehensive_floor_mesh(areas, vertices, lines, holes)
    #     if floor_mesh: scene.add_geometry(floor_mesh, node_name='floor')

    #     # 3. Process walls
    #     for line_id, line in lines.items():
    #         if line.get('type') != 'wall': continue
    #         try:
    #             wall_parts, _ = self.process_wall(line, vertices, holes, areas)
    #             for i, part in enumerate(wall_parts):
    #                 if isinstance(part, trimesh.Trimesh) and not part.is_empty:
    #                     scene.add_geometry(part, node_name=f'wall_{line_id}_part_{i}')
    #         except Exception as e:
    #              print(f"Error processing wall {line_id}: {e}")

    #     # 4. Create doors and windows
    #     opening_meshes = self.create_door_window_meshes(holes, lines, vertices)
    #     for i, opening in enumerate(opening_meshes):
    #         if isinstance(opening, trimesh.Trimesh) and not opening.is_empty:
    #             node_name = f"{opening.metadata.get('type', 'opening')}_{i}"
    #             scene.add_geometry(opening, node_name=node_name)

    #     # 5. Place items defined in the JSON
    #     # item_meshes = self.place_items_from_json(items)
    #     # for i, item_mesh in enumerate(item_meshes):
    #     #     if isinstance(item_mesh, trimesh.Trimesh) and not item_mesh.is_empty:
    #     #         node_name = f"{item_mesh.metadata.get('item_type', 'item')}_{i}"
    #     #         scene.add_geometry(item_mesh, node_name=node_name)
    #     # print(f"  -> Added {len(item_meshes)} items to the scene.")

    #     # 5. Place items defined in the JSON (with debugging)
    #     item_meshes = self.place_items_from_json_with_debug(items)
    #     for i, item_mesh in enumerate(item_meshes):
    #         if isinstance(item_mesh, trimesh.Trimesh) and not item_mesh.is_empty:
    #             node_name = f"{item_mesh.metadata.get('item_type', 'item')}_{i}"
    #             scene.add_geometry(item_mesh, node_name=node_name)
    #     print(f"  -> Added {len(item_meshes)} items to the scene.")

    #     # 6. Center the entire scene
    #     scene = self.center_scene(scene, vertices)

    #     # --- FINAL NaN FIX: Fix all mesh normals before exporting ---
    #     print("Finalizing scene: fixing normals and winding...")
    #     for name, geom in scene.geometry.items():
    #         if isinstance(geom, trimesh.Trimesh):
    #             try:
    #                 geom.fix_normals()
    #             except Exception as e:
    #                 print(f"Could not fix normals for geometry '{name}': {e}")
    #     # --- END FIX ---

    #     # Export in multiple formats
    #     export_paths = {}
    #     output_dir = os.path.dirname(output_base_path)
    #     os.makedirs(output_dir, exist_ok=True)
    #     export_formats = {'glb': 'Binary glTF', 'gltf': 'glTF', 'obj': 'Wavefront OBJ'}

    #     for ext, description in export_formats.items():
    #         try:
    #             output_path = f"{output_base_path}.{ext}"
    #             scene.export(output_path, file_type=ext)
    #             if os.path.exists(output_path):
    #                 export_paths[ext] = output_path
    #                 print(f"  -> Exported {description}: {output_path}")
    #         except Exception as e:
    #             print(f"  -> Error exporting {description}: {str(e)}")

    #     if not export_paths:
    #         raise Exception("Scene generation complete, but no files were exported successfully.")

    #     return export_paths

    # def convert_json_to_glb(self, json_path: str, output_base_path: str,
    #                       scale: float = 1.0, texture_resolution: int = 1024) -> Dict[str, str]:
    #     """Main function to convert JSON to GLB and other formats"""
    #     print(f"Loading JSON from: {json_path}")
    #     try:
    #         with open(json_path, 'r') as f:
    #             data = json.load(f)
    #     except Exception as e:
    #         raise Exception(f"Failed to load JSON file: {str(e)}")

    #     try:
    #         layer = data['layers']['layer-1']
    #         vertices = layer['vertices']
    #         lines = layer['lines']
    #         holes = layer.get('holes', {})
    #         areas = layer.get('areas', {})
    #         items = layer.get('items', {})  # Get items from JSON
    #     except KeyError as e:
    #         raise Exception(f"Invalid JSON structure: missing key {str(e)}")

    #     print(f"Processing {len(vertices)} vertices, {len(lines)} lines, {len(holes)} holes, {len(areas)} areas, {len(items)} items")

    #     scene = trimesh.Scene()

    #     # 1. Add basement floor
    #     basement = self.create_basement_floor(vertices)
    #     if basement:
    #         scene.add_geometry(basement, node_name='basement')

    #     # 2. Add main floor
    #     floor_mesh = self.create_comprehensive_floor_mesh(areas, vertices, lines, holes)
    #     if floor_mesh:
    #         scene.add_geometry(floor_mesh, node_name='floor')

    #     # 3. Process walls
    #     for line_id, line in lines.items():
    #         if line.get('type') != 'wall':
    #             continue
    #         try:
    #             wall_parts, _ = self.process_wall(line, vertices, holes, areas)
    #             for i, part in enumerate(wall_parts):
    #                 if isinstance(part, trimesh.Trimesh) and not part.is_empty:
    #                     scene.add_geometry(part, node_name=f'wall_{line_id}_part_{i}')
    #         except Exception as e:
    #             print(f"Error processing wall {line_id}: {e}")

    #     # 4. Create doors and windows
    #     opening_meshes = self.create_door_window_meshes(holes, lines, vertices)
    #     for i, opening in enumerate(opening_meshes):
    #         if isinstance(opening, trimesh.Trimesh) and not opening.is_empty:
    #             node_name = f"{opening.metadata.get('type', 'opening')}_{i}"
    #             scene.add_geometry(opening, node_name=node_name)

    #     # 5. Place items defined in the JSON with correct scaling
    #     item_meshes = self.place_items_from_json(items)
    #     for i, item_mesh in enumerate(item_meshes):
    #         if isinstance(item_mesh, trimesh.Trimesh) and not item_mesh.is_empty:
    #             node_name = f"{item_mesh.metadata.get('item_type', 'item')}_{i}"
    #             scene.add_geometry(item_mesh, node_name=node_name)
    #     print(f"  -> Added {len(item_meshes)} items to the scene.")

    #     # 6. Center the entire scene
    #     scene = self.center_scene(scene, vertices)

    #     # --- FINAL NaN FIX: Fix all mesh normals before exporting ---
    #     print("Finalizing scene: fixing normals and winding...")
    #     for name, geom in scene.geometry.items():
    #         if isinstance(geom, trimesh.Trimesh):
    #             try:
    #                 # This corrects any zero-length normal vectors that cause NaN errors
    #                 geom.fix_normals()
    #             except Exception as e:
    #                 print(f"Could not fix normals for geometry '{name}': {e}")
    #     # --- END FIX ---

    #     # 7. Export in multiple formats
    #     export_paths = {}
    #     output_dir = os.path.dirname(output_base_path)
    #     os.makedirs(output_dir, exist_ok=True)
    #     export_formats = {'glb': 'Binary glTF', 'gltf': 'glTF', 'obj': 'Wavefront OBJ'}

    #     for ext, description in export_formats.items():
    #         try:
    #             output_path = f"{output_base_path}.{ext}"
    #             # Export the scene, trimesh handles textures and materials for glTF/glb
    #             scene.export(output_path, file_type=ext)
    #             if os.path.exists(output_path):
    #                 export_paths[ext] = output_path
    #                 print(f"  -> Exported {description}: {output_path}")
    #             else:
    #                 print(f"  -> Export failed for {description}, file not found.")
    #         except Exception as e:
    #             print(f"  -> Error exporting {description}: {str(e)}")

    #     if not export_paths:
    #         raise Exception("Scene generation complete, but no files were exported successfully.")

    #     return export_paths

    def create_all_wall_meshes(self, lines_data: Dict, vertices_data: Dict, holes_data: Dict, areas_data: Dict) -> List[trimesh.Trimesh]:
        """
        Creates all wall meshes with corrected corners by calculating extensions.
        This function orchestrates the wall generation process.
        """
        all_wall_meshes = []
        # Filter for only the lines that are walls
        wall_lines = {line_id: line for line_id, line in lines_data.items() if line.get('type') == 'wall'}

        for line_id, line_data in wall_lines.items():
            v_ids = line_data.get('vertices')
            if not v_ids or len(v_ids) != 2:
                continue
                
            v1_id, v2_id = v_ids[0], v_ids[1]
            v1, v2 = vertices_data[v1_id], vertices_data[v2_id]

            # --- CORNER FIX LOGIC: Calculate extensions for each end of the wall ---
            start_extension = 0.0
            end_extension = 0.0

            # Check for connecting walls at the start vertex (v1)
            for connected_line_id in v1['lines']:
                # Ensure we are not checking against the same wall
                if connected_line_id != line_id and connected_line_id in wall_lines:
                    connected_wall = wall_lines[connected_line_id]
                    thickness = self.cm_to_m(connected_wall['properties']['thickness'])
                    # Extend by half the thickness of the connecting wall
                    start_extension = thickness / 2.0
                    break 

            # Check for connecting walls at the end vertex (v2)
            for connected_line_id in v2['lines']:
                # Ensure we are not checking against the same wall
                if connected_line_id != line_id and connected_line_id in wall_lines:
                    connected_wall = wall_lines[connected_line_id]
                    thickness = self.cm_to_m(connected_wall['properties']['thickness'])
                    # Extend by half the thickness of the connecting wall
                    end_extension = thickness / 2.0
                    break
            
            # Process the individual wall with the calculated extensions
            try:
                wall_parts, _ = self.process_wall(
                    line_data, 
                    vertices_data, 
                    holes_data, 
                    areas_data,
                    start_extension,
                    end_extension
                )
                all_wall_meshes.extend(wall_parts)
            except Exception as e:
                print(f"Error processing wall {line_id} with extensions: {e}")

        return all_wall_meshes


    def convert_json_to_glb(self, json_path: str, output_base_path: str,
                            scale: float = 1.0, texture_resolution: int = 1024) -> Dict[str, str]:
        """Main function to convert JSON to GLB and other formats"""
        print(f"Loading JSON from: {json_path}")
        try:
            with open(json_path, 'r') as f:
                data = json.load(f)
        except Exception as e:
            raise Exception(f"Failed to load JSON file: {str(e)}")

        try:
            layer = data['layers']['layer-1']
            vertices = layer['vertices']
            lines = layer['lines']
            holes = layer.get('holes', {})
            areas = layer.get('areas', {})
            items = layer.get('items', {})
        except KeyError as e:
            raise Exception(f"Invalid JSON structure: missing key {str(e)}")

        print(f"Processing {len(vertices)} vertices, {len(lines)} lines, {len(holes)} holes, {len(areas)} areas, {len(items)} items")

        scene = trimesh.Scene()

        # 1. Add basement floor
        basement = self.create_basement_floor(vertices)
        if basement: scene.add_geometry(basement, node_name='basement')

        # 2. Add main floor
        floor_mesh = self.create_comprehensive_floor_mesh(areas, vertices, lines, holes)
        if floor_mesh: scene.add_geometry(floor_mesh, node_name='floor')

        # --- CORNER FIX: Use the new holistic wall creation function ---
        # 3. Process all walls with seamless corners
        all_wall_meshes = self.create_all_wall_meshes(lines, vertices, holes, areas)
        for i, part in enumerate(all_wall_meshes):
            if isinstance(part, trimesh.Trimesh) and not part.is_empty:
                scene.add_geometry(part, node_name=f'wall_part_{i}')
        # --- END FIX ---

        # 4. Create doors and windows
        opening_meshes = self.create_door_window_meshes(holes, lines, vertices)
        for i, opening in enumerate(opening_meshes):
            if isinstance(opening, trimesh.Trimesh) and not opening.is_empty:
                node_name = f"{opening.metadata.get('type', 'opening')}_{i}"
                scene.add_geometry(opening, node_name=node_name)

        # 5. Place items from JSON
        item_meshes = self.place_items_from_json(items)
        for i, item_mesh in enumerate(item_meshes):
            if isinstance(item_mesh, trimesh.Trimesh) and not item_mesh.is_empty:
                node_name = f"{item_mesh.metadata.get('item_type', 'item')}_{i}"
                scene.add_geometry(item_mesh, node_name=node_name)
        print(f"  -> Added {len(item_meshes)} items to the scene.")

        # 6. Center the entire scene
        scene = self.center_scene(scene, vertices)

        # 7. Finalize geometry before exporting
        print("Finalizing scene: fixing normals and winding...")
        for name, geom in scene.geometry.items():
            if isinstance(geom, trimesh.Trimesh):
                try:
                    geom.fix_normals()
                except Exception as e:
                    print(f"Could not fix normals for geometry '{name}': {e}")
        
        # 8. Export in multiple formats
        export_paths = {}
        output_dir = os.path.dirname(output_base_path)
        os.makedirs(output_dir, exist_ok=True)
        export_formats = {'glb': 'Binary glTF', 'gltf': 'glTF', 'obj': 'Wavefront OBJ'}

        for ext, description in export_formats.items():
            try:
                output_path = f"{output_base_path}.{ext}"
                scene.export(output_path, file_type=ext)
                if os.path.exists(output_path):
                    export_paths[ext] = output_path
                    print(f"  -> Exported {description}: {output_path}")
            except Exception as e:
                print(f"  -> Error exporting {description}: {str(e)}")

        if not export_paths:
            raise Exception("Scene generation complete, but no files were exported successfully.")

        return export_paths

# Default generator instance
default_generator = GLBGenerator()

def convert_json_to_glb(json_path: str, output_base_path: str,
                      scale: float = 1.0, texture_resolution: int = 1024) -> Dict[str, str]:
    """
    Standalone function to convert a JSON floor plan to 3D models.
    This function uses a default instance of the GLBGenerator class.
    """
    return default_generator.convert_json_to_glb(
        json_path=json_path,
        output_base_path=output_base_path,
        scale=scale,
        texture_resolution=texture_resolution
    )