# geometric_refiner.py

import os
import json
import uuid
import time
import logging
import numpy as np
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
import math

from database_manager import DatabaseManager
from models import ProjectStatus, SessionStatus

logger = logging.getLogger(__name__)

class GeometricRefiner:
    """Stage 2: Geometric consistency refinement with enhanced spatial analysis"""
    
    def __init__(self, database_manager):
        self.db_manager = database_manager
        self.stage_number = 2
        self.stage_name = "geometric_refinement"
        self.stage_type = "local"
        
        self.min_door_width_px = 20
        self.max_door_width_px = 100
        self.min_window_width_px = 15
        self.max_window_width_px = 150
        self.min_wall_thickness_px = 3
        self.max_wall_thickness_px = 25
        
        self.door_aspect_ratio_range = (1.8, 4.0)
        self.window_aspect_ratio_range = (0.5, 3.0)
        
    def process(self, db, session_id: int, global_json: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process global JSON through geometric refinement stage
        """
        start_time = time.time()
        
        try:
            logger.info(f"Starting geometric refinement for session {session_id}")
            
            objects = global_json.get('detected_objects', [])
            
            refined_objects = self._refine_object_geometry(objects)
            
            refined_json = self._build_refined_json(global_json, refined_objects)
            
            processing_time = int((time.time() - start_time) * 1000)
            
            stage_data = {
                'session_id': session_id, 'stage_number': self.stage_number, 'stage_name': self.stage_name,
                'stage_type': self.stage_type, 'input_json': global_json, 'output_json': refined_json,
                'processing_time_ms': processing_time,
                'confidence_scores': self._extract_confidence_scores(refined_json), 'status': 'completed'
            }
            self.db_manager.save_json_stage(db, stage_data)

            logger.info(f"Geometric refinement completed in {processing_time}ms")
            
            return {
                "json_output": refined_json,
                "processing_time_ms": processing_time,
                "objects_refined": len(refined_objects)
            }
            
        except Exception as e:
            logger.error(f"Error in geometric refinement: {str(e)}", exc_info=True)
            self._log_error(session_id, str(e))
            raise
    
    def _refine_object_geometry(self, objects: List[Dict]) -> List[Dict]:
        """Refine geometric properties of detected objects"""
        refined_objects = []
        for obj in objects:
            refined_obj = obj.copy()
            class_name = obj.get('class_name', '').lower()
            
            if class_name == 'door':
                refined_obj = self._refine_door_geometry(refined_obj)
            elif class_name == 'window':
                refined_obj = self._refine_window_geometry(refined_obj)
            elif class_name == 'wall':
                refined_obj = self._refine_wall_geometry(refined_obj)

            refined_obj = self._recalculate_bbox_from_dims(refined_obj)
            refined_objects.append(refined_obj)
        return refined_objects
            
    def _refine_door_geometry(self, door_obj: Dict) -> Dict:
        dims = door_obj.get('dimensions', {})
        width = dims.get('width_px', 0)
        height = dims.get('height_px', 0)
        
        width = max(self.min_door_width_px, min(self.max_door_width_px, width))
        
        aspect_ratio = height / width if width > 0 else self.door_aspect_ratio_range[0]
        height = width * max(self.door_aspect_ratio_range[0], min(self.door_aspect_ratio_range[1], aspect_ratio))
        
        door_obj['dimensions'].update({'width_px': width, 'height_px': height})
        return door_obj
    
    def _refine_window_geometry(self, window_obj: Dict) -> Dict:
        dims = window_obj.get('dimensions', {})
        width = dims.get('width_px', 0)
        height = dims.get('height_px', 0)

        width = max(self.min_window_width_px, min(self.max_window_width_px, width))
        
        aspect_ratio = height / width if width > 0 else self.window_aspect_ratio_range[0]
        height = width * max(self.window_aspect_ratio_range[0], min(self.window_aspect_ratio_range[1], aspect_ratio))
        
        window_obj['dimensions'].update({'width_px': width, 'height_px': height})
        return window_obj
    
    def _refine_wall_geometry(self, wall_obj: Dict) -> Dict:
        dims = wall_obj.get('dimensions', {})
        thickness = min(dims.get('width_px', 0), dims.get('height_px', 0))
        
        thickness = max(self.min_wall_thickness_px, min(self.max_wall_thickness_px, thickness))
        
        if dims.get('width_px', 0) < dims.get('height_px', 0):
            wall_obj['dimensions']['width_px'] = thickness
        else:
            wall_obj['dimensions']['height_px'] = thickness
        return wall_obj

    def _recalculate_bbox_from_dims(self, obj: Dict) -> Dict:
        center = obj['center_point']
        width = obj['dimensions']['width_px']
        height = obj['dimensions']['height_px']
        orientation = obj['orientation']

        obj['bounding_box']['x1'] = center['x'] - width / 2
        obj['bounding_box']['y1'] = center['y'] - height / 2
        obj['bounding_box']['x2'] = center['x'] + width / 2
        obj['bounding_box']['y2'] = center['y'] + height / 2

        if orientation == "horizontal":
            obj['start_point'] = {'x': center['x'] - width/2, 'y': center['y']}
            obj['end_point'] = {'x': center['x'] + width/2, 'y': center['y']}
        elif orientation == "vertical":
            obj['start_point'] = {'x': center['x'], 'y': center['y'] - height/2}
            obj['end_point'] = {'x': center['x'], 'y': center['y'] + height/2}
        
        return obj

    def _build_refined_json(self, global_json: Dict, refined_objects: List[Dict]) -> Dict[str, Any]:
        refined_json = global_json.copy()
        refined_json['detected_objects'] = refined_objects
        
        # Add metadata for this stage
        refined_json['metadata']['stage_number'] = self.stage_number
        refined_json['metadata']['stage_name'] = self.stage_name
        refined_json['metadata']['timestamp'] = datetime.now().isoformat()
        
        refined_json['refinement_metadata'] = {
            'stage_number': self.stage_number,
            'stage_name': self.stage_name,
            'refinement_type': 'geometric',
            'parent_stage_number': 1,
        }
        return refined_json
    
    def _extract_confidence_scores(self, json_output: Dict) -> Dict[str, float]:
        objects = json_output.get('detected_objects', [])
        if not objects: return {}
        confidences = [obj.get('confidence_score', 0.0) for obj in objects]
        return {
            'average_confidence': sum(confidences) / len(confidences) if confidences else 0,
            'min_confidence': min(confidences) if confidences else 0,
            'max_confidence': max(confidences) if confidences else 0,
        }

    def _log_error(self, session_id: int, error_message: str):
        try:
            with self.db_manager.get_session() as db:
                self.db_manager.save_debug_log(
                    db=db, session_id=session_id, log_level='error', component='geometric_refiner',
                    message=error_message, metadata=json.dumps({'stage': self.stage_name})
                )
        except Exception as e:
            logger.error(f"Error logging to database: {str(e)}")