# # database_manager.py

# from sqlalchemy import create_engine
# from sqlalchemy.orm import sessionmaker, Session
# from contextlib import contextmanager
# import os
# from typing import Generator, List, Dict, Any

# from models import Base, Project, ProcessingSession, JSONStage, DebugLog, AIModel, ProjectStatus, SessionStatus, StageStatus, LogLevel, ModelOutput
# from repositories import (
#     ProjectRepository, ProcessingSessionRepository, JSONStageRepository,
#     DebugLogRepository, ModelOutputRepository, AIModelResultRepository, ObjectClassRepository
# )
# from repositories import ObjectClassRepository

# class DatabaseManager:
#     def __init__(self, database_url: str = None):
#         if database_url is None:
#             database_url = os.getenv("DATABASE_URL", "mysql+pymysql://root:Zlendo%4007@localhost:3306/z_realty_v2_check")

#         self.engine = create_engine(
#             database_url,
#             pool_pre_ping=True,
#             echo=os.getenv("DB_ECHO", "false").lower() == "true"
#         )
#         self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)

#     def create_tables(self):
#         Base.metadata.create_all(bind=self.engine)

#     def drop_tables(self):
#         Base.metadata.drop_all(bind=self.engine)

#     @contextmanager
#     def get_session(self) -> Generator[Session, None, None]:
#         session = self.SessionLocal()
#         try:
#             yield session
#             session.commit()
#         except Exception:
#             session.rollback()
#             raise
#         finally:
#             session.close()

#     # --- Repository-Wrapping Methods ---

#     def create_project(self, db: Session, name: str, **kwargs) -> Project:
#         return ProjectRepository(db).create(name=name, **kwargs)

#     def update_project_status(self, db: Session, project_id: int, status: ProjectStatus):
#         ProjectRepository(db).update_status(project_id, status)

#     def create_processing_session(self, db: Session, project_id: int, ai_model_flags: Dict, processing_config: Dict) -> ProcessingSession:
#         return ProcessingSessionRepository(db).create(project_id, ai_model_flags, processing_config)

#     def update_session_status(self, db: Session, session_id: int, status: SessionStatus, current_stage: int = None):
#         ProcessingSessionRepository(db).update_status(session_id, status, current_stage)

#     def create_json_stage(self, db: Session, **kwargs) -> JSONStage:
#         return JSONStageRepository(db).create(**kwargs)

#     def update_json_stage(self, db: Session, stage_id: int, update_data: Dict):
#         JSONStageRepository(db).update_output(stage_id, **update_data)

#     def save_json_stage(self, db: Session, stage_data: Dict) -> JSONStage:
#         """Combined create and update for pipeline stages."""
#         stage = JSONStageRepository(db).create(
#             session_id=stage_data['session_id'],
#             stage_number=stage_data['stage_number'],
#             stage_name=stage_data['stage_name'],
#             stage_type=stage_data['stage_type'],
#             input_json=stage_data.get('input_json')
#         )
#         JSONStageRepository(db).update_output(
#             stage_id=stage.id,
#             output_json=stage_data['output_json'],
#             processing_time_ms=stage_data['processing_time_ms'],
#             confidence_scores=stage_data['confidence_scores']
#         )
#         return stage

#     def save_debug_log(self, db: Session, session_id: int, log_level: str, component: str, message: str, **kwargs):
#         log_level_enum = LogLevel[log_level.upper()]
#         return DebugLogRepository(db).create(
#             session_id=session_id,
#             log_level=log_level_enum,
#             component=component,
#             message=message,
#             **kwargs
#         )

#     def save_model_output(self, db: Session, output_data: Dict) -> ModelOutput:
#         return ModelOutputRepository(db).create(**output_data)

#     def get_model_outputs(self, db: Session, session_id: int) -> List[ModelOutput]:
#         return ModelOutputRepository(db).get_by_session(session_id)
    
#     def save_object_classes_batch(self, db: Session, objects_data: List[Dict], session_id: int, stage_id: int):
#         """Save multiple object classes in batch"""
#         repo = ObjectClassRepository(db)
#         return repo.create_batch(objects_data, session_id, stage_id)

#     def create_object_class(self, db: Session, session_id: int, stage_id: int, **kwargs):
#         """Create a single object class"""
#         return ObjectClassRepository(db).create(session_id=session_id, stage_id=stage_id, **kwargs)
        
#     def save_object_class(self, db: Session, session_id: int, stage_id: int, object_data: Dict):
#         """Save a single object class to the database"""
#         return ObjectClassRepository(db).create(session_id=session_id, stage_id=stage_id, **object_data)

# db_manager = DatabaseManager()

# # Dependency for FastAPI
# def get_db() -> Generator[Session, None, None]:
#     """FastAPI dependency for database session"""
#     session = db_manager.SessionLocal()
#     try:
#         yield session
#     finally:
#         session.close()



# database_manager.py

import os
from typing import Generator, List, Dict, Any
from contextlib import contextmanager

from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session

from models import (
    Base, Project, ProcessingSession, JSONStage, DebugLog, AIModel,
    ProjectStatus, SessionStatus, StageStatus, LogLevel, ModelOutput
)
from repositories import (
    ProjectRepository, ProcessingSessionRepository, JSONStageRepository,
    DebugLogRepository, ModelOutputRepository, AIModelResultRepository, ObjectClassRepository
)

# --- Load environment variables from .env file ---
load_dotenv()

class DatabaseManager:
    def __init__(self, database_url: str = None):
        if database_url is None:
            database_url = os.getenv("DATABASE_URL")
            if not database_url:
                raise ValueError("DATABASE_URL is not set in the environment or .env file")

        self.engine = create_engine(
            database_url,
            pool_pre_ping=True,
            echo=os.getenv("DB_ECHO", "false").lower() == "true"
        )
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)

    def create_tables(self):
        Base.metadata.create_all(bind=self.engine)

    def drop_tables(self):
        Base.metadata.drop_all(bind=self.engine)

    @contextmanager
    def get_session(self) -> Generator[Session, None, None]:
        session = self.SessionLocal()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    # --- Repository-Wrapping Methods ---

    def create_project(self, db: Session, name: str, **kwargs) -> Project:
        return ProjectRepository(db).create(name=name, **kwargs)

    def update_project_status(self, db: Session, project_id: int, status: ProjectStatus):
        ProjectRepository(db).update_status(project_id, status)

    def create_processing_session(self, db: Session, project_id: int, ai_model_flags: Dict, processing_config: Dict) -> ProcessingSession:
        return ProcessingSessionRepository(db).create(project_id, ai_model_flags, processing_config)

    def update_session_status(self, db: Session, session_id: int, status: SessionStatus, current_stage: int = None):
        ProcessingSessionRepository(db).update_status(session_id, status, current_stage)

    def create_json_stage(self, db: Session, **kwargs) -> JSONStage:
        return JSONStageRepository(db).create(**kwargs)

    def update_json_stage(self, db: Session, stage_id: int, update_data: Dict):
        JSONStageRepository(db).update_output(stage_id, **update_data)

    def save_json_stage(self, db: Session, stage_data: Dict) -> JSONStage:
        """Combined create and update for pipeline stages."""
        stage = JSONStageRepository(db).create(
            session_id=stage_data['session_id'],
            stage_number=stage_data['stage_number'],
            stage_name=stage_data['stage_name'],
            stage_type=stage_data['stage_type'],
            input_json=stage_data.get('input_json')
        )
        JSONStageRepository(db).update_output(
            stage_id=stage.id,
            output_json=stage_data['output_json'],
            processing_time_ms=stage_data['processing_time_ms'],
            confidence_scores=stage_data['confidence_scores']
        )
        return stage

    def save_debug_log(self, db: Session, session_id: int, log_level: str, component: str, message: str, **kwargs):
        log_level_enum = LogLevel[log_level.upper()]
        return DebugLogRepository(db).create(
            session_id=session_id,
            log_level=log_level_enum,
            component=component,
            message=message,
            **kwargs
        )

    def save_model_output(self, db: Session, output_data: Dict) -> ModelOutput:
        return ModelOutputRepository(db).create(**output_data)

    def get_model_outputs(self, db: Session, session_id: int) -> List[ModelOutput]:
        return ModelOutputRepository(db).get_by_session(session_id)
    
    def save_object_classes_batch(self, db: Session, objects_data: List[Dict], session_id: int, stage_id: int):
        """Save multiple object classes in batch"""
        repo = ObjectClassRepository(db)
        return repo.create_batch(objects_data, session_id, stage_id)

    def create_object_class(self, db: Session, session_id: int, stage_id: int, **kwargs):
        """Create a single object class"""
        return ObjectClassRepository(db).create(session_id=session_id, stage_id=stage_id, **kwargs)
        
    def save_object_class(self, db: Session, session_id: int, stage_id: int, object_data: Dict):
        """Save a single object class to the database"""
        return ObjectClassRepository(db).create(session_id=session_id, stage_id=stage_id, **object_data)

# Instantiate DatabaseManager globally
db_manager = DatabaseManager()

# FastAPI dependency for database session
def get_db() -> Generator[Session, None, None]:
    session = db_manager.SessionLocal()
    try:
        yield session
    finally:
        session.close()
