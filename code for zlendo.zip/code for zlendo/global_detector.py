# global_detector.py

import os
import json
import uuid
import time
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import math
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import Rectangle
import cv2

logger = logging.getLogger(__name__)

class GlobalDetector:
    """Stage 1: Global object detection with enhanced spatial analysis and visualization"""

    def __init__(self, ai_engine_controller, database_manager):
        self.ai_engine = ai_engine_controller
        self.db_manager = database_manager
        self.stage_number = 1
        self.stage_name = "global_detection"
        self.stage_type = "global"
        self.REAL_DOOR_WIDTH_METERS = 0.9
        
        # Color mapping for different object types
        self.color_map = {
            'wall': '#4A4A4A',      # Dark gray
            'door': '#FF0000',      # Red
            'window': '#00BFFF',    # Blue
            'sofa': '#32CD32',      # Green
            'bed': '#9932CC',       # Purple
            'table': '#FFA500',     # Orange
            'chair': '#FFD700',     # Gold
            'bathtub': '#00CED1',   # Cyan
            'sink': '#FF1493',      # Pink
            'stove': '#8B4513',     # Brown
            'default': '#808080'    # Gray
        }

    def process(self, session_id: int, image_path: str, ai_model_flags: Dict, 
                enable_visualization: bool = True, output_dir: str = None) -> Dict[str, Any]:
        """
        Process floorplan image through global detection stage with visualization options
        """
        start_time = time.time()

        try:
            logger.info(f"Starting global detection for session {session_id}")
            
            image_dims = self._get_image_dimensions(image_path)
            
            # This is the raw result from the AI model (e.g., MaskRCNN)
            ai_raw_result = self.ai_engine.process_image(session_id, image_path, ai_model_flags)['best_result']
            
            # Calculate scale factor based on detected doors
            avg_door_px = ai_raw_result.get('averageDoor', 0)
            # Use a safe default scale factor if no doors are detected to prevent division by zero
            scale_factor = self.REAL_DOOR_WIDTH_METERS / avg_door_px if avg_door_px > 0 else 0.02

            processed_objects = self._create_enhanced_objects(ai_raw_result, image_dims, scale_factor)
            spatial_relationships = self._analyze_spatial_relationships(processed_objects)
            
            global_json = self._build_global_json(
                session_id, processed_objects, spatial_relationships,
                ai_raw_result, image_dims, scale_factor, avg_door_px
            )
            
            # Generate visualizations if enabled
            if enable_visualization:
                self._generate_visualizations(
                    image_path, processed_objects, ai_raw_result, 
                    session_id, output_dir
                )
            
            processing_time = int((time.time() - start_time) * 1000)
            
            with self.db_manager.get_session() as db:
                stage_data = {
                    'session_id': session_id,
                    'stage_number': self.stage_number,
                    'stage_name': self.stage_name,
                    'stage_type': self.stage_type,
                    'input_json': {"image_path": image_path, "model_flags": ai_model_flags},
                    'output_json': global_json,
                    'processing_time_ms': processing_time,
                    'confidence_scores': self._extract_confidence_scores(global_json),
                    'status': 'completed'
                }
                self.db_manager.save_json_stage(db, stage_data)

            logger.info(f"Global detection completed in {processing_time}ms")

            # Return a dictionary with 'json_output' key to match pipeline expectation
            return {
                "json_output": global_json,
                "processing_time_ms": processing_time,
                "objects_detected": len(processed_objects),
            }

        except Exception as e:
            logger.error(f"Error in global detection for session {session_id}: {e}", exc_info=True)
            raise

    
    def _get_image_dimensions(self, image_path: str) -> Dict[str, Any]:
        with Image.open(image_path) as img:
            return {
                "width": img.width,
                "height": img.height,
                "resolution": img.info.get('dpi', (72, 72))[0]
            }

    # def _correct_class_name(self, class_name: str) -> str:
    #     """
    #     Temporary fix for swapped door/window classifications
    #     Remove this method once the model is retrained with correct labels
    #     """
    #     class_name = class_name.lower()
    #     if class_name == 'door':
    #         return 'window'
    #     elif class_name == 'window':
    #         return 'door'
    #     return class_name
    
    def _determine_door_opening_direction(self, door_bbox: Dict, walls: List[Dict]) -> str:
        """
        Determine door opening direction ('top', 'bottom', 'left', 'right')
        based on proximity and alignment with nearby walls.
        """
        fig, ax = plt.subplots(figsize=(20, 16))
        ax.set_aspect("equal")
        ax.invert_yaxis()
        ax.grid(True, linestyle="--", alpha=0.4)
        x1, y1, x2, y2 = door_bbox['x1'], door_bbox['y1'], door_bbox['x2'], door_bbox['y2']
        door_center_x = (x1 + x2) / 2
        door_center_y = (y1 + y2) / 2
        door_width = abs(x2 - x1)
        door_height = abs(y2 - y1)

        orientation = "horizontal" if door_width > door_height else "vertical"

        closest_wall = None
        min_dist = float('inf')
        direction = 'bottom'  # Default

        for wall in walls:
            wall_bbox = wall.get("bounding_box", {})
            wx1, wy1 = wall_bbox.get("x1"), wall_bbox.get("y1")
            wx2, wy2 = wall_bbox.get("x2"), wall_bbox.get("y2")
            if wx1 is None or wy1 is None or wx2 is None or wy2 is None:
                continue

            wall_center_x = (wx1 + wx2) / 2
            wall_center_y = (wy1 + wy2) / 2

            if orientation == "horizontal":
                dist = abs(wall_center_y - y1)
                if dist < min_dist and min(wx1, wx2) <= x1 <= max(wx1, wx2):
                    min_dist = dist
                    direction = 'top' if wall_center_y < y1 else 'bottom'
                    # ax.text(mid_x, mid_y - 12,
                    #             f"Opens: {direction}",
                    #             fontsize=9, color="purple",
                    #             bbox=dict(boxstyle="round,pad=0.2", facecolor="white", alpha=0.7))
            else:
                dist = abs(wall_center_x - x1)
                if dist < min_dist and min(wy1, wy2) <= y1 <= max(wy1, wy2):
                    min_dist = dist
                    direction = 'left' if wall_center_x < x1 else 'right'

        return direction

    
    def _get_door_line_coordinates(self, door_bbox: Dict, opening_direction: str) -> Dict:
        """
        Get door line coordinates based on opening direction
        """
        x1, y1, x2, y2 = door_bbox['x1'], door_bbox['y1'], door_bbox['x2'], door_bbox['y2']
        
        if opening_direction == 'top':
            return {
                'start_point': {'x': x2, 'y': y1},
                'end_point': {'x': x2, 'y': y2}
            }
        elif opening_direction == 'bottom':
            return {
                'start_point': {'x': x1, 'y': y1},
                'end_point': {'x': x1, 'y': y2}
            }
        elif opening_direction == 'right':
            return {
                'start_point': {'x': x1, 'y': y1},
                'end_point': {'x': x2, 'y': y1}
            }
        elif opening_direction == 'left':
            return {
                'start_point': {'x': x1, 'y': y2},
                'end_point': {'x': x2, 'y': y2}
            }
        else:
            # Default fallback
            return {
                'start_point': {'x': x1, 'y': y1},
                'end_point': {'x': x1, 'y': y2}
            }

    # In global_detector.py

    def _correct_class_name(self, class_name: str) -> str:
        """
        FIX: This function is NECESSARY because the ML model swaps door/window labels.
        This function swaps them back to their correct state.
        """
        class_name_lower = class_name.lower()
        if class_name_lower == 'door':
            return 'Window'  # An AI 'door' is actually a 'Window'
        elif class_name_lower == 'window':
            return 'Door'    # An AI 'window' is actually a 'Door'
        return class_name.capitalize() # Capitalize other names for consistency

    # def _create_enhanced_objects(self, ai_result: Dict, image_dims: Dict, scale_factor: float) -> List[Dict]:
    #     """Convert raw AI detections to enhanced object format using fixed 22-class label mapping."""
    #     enhanced_objects = []

    #     class_names = [
    #         "Wall", "Door", "Window", "Bed", "Table", "Dining", "Sofa", "Sink", "Bathtub",
    #         "Western_T", "Indian_T", "Stove", "Cabinet", "Fridge", "Cupboard", "Flower_Pot",
    #         "W_Machine", "TV", "AC", "Steps", "Chair", "Balcony"
    #     ]

    #     for i, point in enumerate(ai_result['points']):
    #         class_entry = ai_result['classes'][i]
    #         raw_name = class_entry.get("name", "")

    #         if raw_name.startswith("class_"):
    #             index = int(raw_name.split("_")[1])
    #             class_name = class_names[index] if index < len(class_names) else raw_name
    #         else:
    #             class_name = raw_name

    #         # *** FIX: Apply the correction for swapped door/window labels immediately ***
    #         corrected_class_name = self._correct_class_name(class_name)
            
    #         # Bounding box and geometry
    #         x1, y1, x2, y2 = point['x1'], point['y1'], point['x2'], point['y2']
    #         width_px, height_px = abs(x2 - x1), abs(y2 - y1)
    #         center_x, center_y = (x1 + x2) / 2, (y1 + y2) / 2

    #         if width_px > height_px * 1.2:
    #             orientation = "horizontal"
    #         elif height_px > width_px * 1.2:
    #             orientation = "vertical"
    #         else:
    #             orientation = "diagonal"

    #         corners = None
    #         opening_direction = None

    #         # Use the corrected class name for all logic
    #         if corrected_class_name.lower() == "door":
    #             corners = [{"x": x1, "y": y1}, {"x": x2, "y": y1}, {"x": x2, "y": y2}, {"x": x1, "y": y2}]
    #             walls = [obj for obj in enhanced_objects if obj.get('class_name', '').lower() == 'wall']
    #             opening_direction = self._determine_door_opening_direction(
    #                 {"x1": x1, "y1": y1, "x2": x2, "y2": y2}, walls
    #             )
    #             door_coords = self._get_door_line_coordinates(
    #                 {"x1": x1, "y1": y1, "x2": x2, "y2": y2}, opening_direction
    #             )
    #             start_point = door_coords['start_point']
    #             end_point = door_coords['end_point']
    #         else:
    #             start_point = {"x": center_x, "y": y1} if orientation == "vertical" else {"x": x1, "y": center_y}
    #             end_point = {"x": center_x, "y": y2} if orientation == "vertical" else {"x": x2, "y": center_y}

    #         obj = {
    #             "id": str(uuid.uuid4()),
    #             "class_name": corrected_class_name,
    #             "class_type": self._get_class_type(corrected_class_name),
    #             "bounding_box": {"x1": x1, "y1": y1, "x2": x2, "y2": y2},
    #             "center_point": {"x": center_x, "y": center_y},
    #             "orientation": orientation,
    #             "opening_direction": opening_direction,
    #             "start_point": start_point,
    #             "end_point": end_point,
    #             "dimensions": {
    #                 "width_px": width_px, "height_px": height_px,
    #                 "width_m": width_px * scale_factor, "height_m": height_px * scale_factor,
    #                 "depth_m": self._estimate_depth_m(corrected_class_name)
    #             },
    #             "confidence_score": float(class_entry.get('confidence', 0)) / 100.0,
    #             "attributes": {"material": "default", "color": "white", "style": "modern"},
    #             "raw_detection_index": i
    #         }

    #         if corners:
    #             obj["door_corners"] = corners
    #         enhanced_objects.append(obj)
    #     return enhanced_objects


    def _create_enhanced_objects(self, ai_result: Dict, image_dims: Dict, scale_factor: float) -> List[Dict]:
        """
        MODIFIED: Convert raw AI detections to enhanced objects with UNIFIED line generation
        for walls, doors, and windows to ensure correct initial visualization and data.
        """
        enhanced_objects = []

        class_names = [
            "Wall", "Door", "Window", "Bed", "Table", "Dining", "Sofa", "Sink", "Bathtub",
            "Western_T", "Indian_T", "Stove", "Cabinet", "Fridge", "Cupboard", "Flower_Pot",
            "W_Machine", "TV", "AC", "Steps", "Chair", "Balcony"
        ]

        for i, point in enumerate(ai_result['points']):
            class_entry = ai_result['classes'][i]
            raw_name = class_entry.get("name", "")

            # Map class_X to its name
            if raw_name.startswith("class_"):
                try:
                    index = int(raw_name.split("_")[1])
                    class_name = class_names[index] if 0 <= index < len(class_names) else raw_name
                except (ValueError, IndexError):
                    class_name = raw_name
            else:
                class_name = raw_name

            # Apply the NECESSARY correction for the model's swapped labels
            corrected_class_name = self._correct_class_name(class_name)
            
            # Bounding box and geometry
            x1, y1, x2, y2 = point['x1'], point['y1'], point['x2'], point['y2']
            width_px, height_px = abs(x2 - x1), abs(y2 - y1)
            center_x, center_y = (x1 + x2) / 2, (y1 + y2) / 2

            if width_px > height_px:
                orientation = "horizontal"
            else:
                orientation = "vertical"

            start_point = None
            end_point = None
            opening_direction = None

            # --- START OF THE FIX ---
            # UNIFIED LOGIC: Treat walls, doors, and windows as simple lines based on their longest axis.
            # This fixes the incorrect visualization in the global_detection stage.
            if corrected_class_name.lower() in ["wall", "door", "window"]:
                if orientation == "horizontal":
                    start_point = {"x": x1, "y": center_y}
                    end_point = {"x": x2, "y": center_y}
                else: # vertical
                    start_point = {"x": center_x, "y": y1}
                    end_point = {"x": center_x, "y": y2}
            # --- END OF THE FIX ---

            obj = {
                "id": str(uuid.uuid4()),
                "class_name": corrected_class_name,
                "class_type": self._get_class_type(corrected_class_name),
                "bounding_box": {"x1": x1, "y1": y1, "x2": x2, "y2": y2},
                "center_point": {"x": center_x, "y": center_y},
                "orientation": orientation,
                "opening_direction": opening_direction, # This can be refined later if needed
                "start_point": start_point,
                "end_point": end_point,
                "dimensions": {
                    "width_px": width_px, "height_px": height_px,
                    "width_m": width_px * scale_factor, "height_m": height_px * scale_factor,
                    "depth_m": self._estimate_depth_m(corrected_class_name)
                },
                "confidence_score": float(class_entry.get('confidence', 0)) / 100.0,
                "attributes": {"material": "default", "color": "white", "style": "modern"},
                "raw_detection_index": i
            }

            enhanced_objects.append(obj)
        return enhanced_objects




    
    def _align_door_with_walls(self, door: Dict, walls: List[Dict]) -> Dict:
        """Align door positioning with nearby walls based on orientation."""
        door_bbox = door['bounding_box']
        door_center = door['center_point']
        orientation = door['orientation']
        
        # Find the closest wall
        closest_wall = None
        min_distance = float('inf')
        
        for wall in walls:
            wall_center = wall['center_point']
            distance = math.sqrt((door_center['x'] - wall_center['x'])**2 + 
                            (door_center['y'] - wall_center['y'])**2)
            if distance < min_distance:
                min_distance = distance
                closest_wall = wall
        
        if closest_wall is None:
            # Fallback to original positioning if no walls found
            return {
                'start_point': door['start_point'],
                'end_point': door['end_point']
            }
        
        wall_bbox = closest_wall['bounding_box']
        
        if orientation == "horizontal":
            # For horizontal doors, align with wall's vertical edges
            # Position door at the bottom edge of the wall (typical door placement)
            door_y = wall_bbox['y2']  # Bottom edge of wall
            
            # Use door's horizontal span but position at wall edge
            start_x = door_bbox['x1']
            end_x = door_bbox['x2']
            
            return {
                'start_point': {"x": start_x, "y": door_y},
                'end_point': {"x": end_x, "y": door_y}
            }
        
        elif orientation == "vertical":
            # For vertical doors, align with wall's horizontal edges
            # Position door at the right edge of the wall (typical door placement)
            door_x = wall_bbox['x2']  # Right edge of wall
            
            # Use door's vertical span but position at wall edge
            start_y = door_bbox['y1']
            end_y = door_bbox['y2']
            
            return {
                'start_point': {"x": door_x, "y": start_y},
                'end_point': {"x": door_x, "y": end_y}
            }
        
        else:  # diagonal
            # For diagonal doors, use the closest wall edge
            # Determine which edge of the wall is closest to the door
            wall_edges = {
                'top': wall_bbox['y1'],
                'bottom': wall_bbox['y2'],
                'left': wall_bbox['x1'],
                'right': wall_bbox['x2']
            }
            
            # Find closest edge
            door_distances = {
                'top': abs(door_center['y'] - wall_edges['top']),
                'bottom': abs(door_center['y'] - wall_edges['bottom']),
                'left': abs(door_center['x'] - wall_edges['left']),
                'right': abs(door_center['x'] - wall_edges['right'])
            }
            
            closest_edge = min(door_distances, key=door_distances.get)
            
            if closest_edge in ['top', 'bottom']:
                # Align horizontally with wall edge
                door_y = wall_edges[closest_edge]
                return {
                    'start_point': {"x": door_bbox['x1'], "y": door_y},
                    'end_point': {"x": door_bbox['x2'], "y": door_y}
                }
            else:
                # Align vertically with wall edge
                door_x = wall_edges[closest_edge]
                return {
                    'start_point': {"x": door_x, "y": door_bbox['y1']},
                    'end_point': {"x": door_x, "y": door_bbox['y2']}
                }

    def _create_door_analysis_visualization(self, image_path: str, processed_objects: List[Dict], output_dir: str):
        """Create detailed door analysis visualization showing wall-aligned doors"""

        # Filter only doors
        doors = [obj for obj in processed_objects if obj['class_name'].lower() == 'door']

        if not doors:
            logger.warning("No doors detected for door analysis visualization")
            return

        # Load original image
        img = cv2.imread(image_path)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 10))

        # Left plot: Original image with door bounding boxes
        ax1.imshow(img_rgb)
        ax1.set_title('Door Bounding Boxes', fontsize=14, fontweight='bold')

        # Right plot: Wall-aligned door lines
        ax2.imshow(img_rgb)
        ax2.set_title('Wall-Aligned Door Lines', fontsize=14, fontweight='bold')

        for i, door in enumerate(doors):
            bbox = door['bounding_box']
            start_point = door['start_point']
            end_point = door['end_point']
            orientation = door['orientation']
            confidence = door['confidence_score']

            x1, y1, x2, y2 = bbox['x1'], bbox['y1'], bbox['x2'], bbox['y2']

            # ----- Left Plot (Just BBox Rectangle) -----
            rect = Rectangle((x1, y1), x2 - x1, y2 - y1, linewidth=3, edgecolor='red', facecolor='none')
            ax1.add_patch(rect)

            ax1.text(x1, y1 - 10,
                    f"Door {i + 1}\n{orientation}\nConf: {confidence:.2f}",
                    color='red', fontsize=10, fontweight='bold',
                    bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.9))

            # ----- Right Plot (Draw wall-aligned door line) -----
            # Draw the door line in thick red
            ax2.plot([start_point['x'], end_point['x']], 
                    [start_point['y'], end_point['y']], 
                    color='red', linewidth=4, label=f'Door {i+1}' if i < 5 else "")

            # Mark start and end points
            ax2.plot(start_point['x'], start_point['y'], 'go', markersize=8)
            ax2.plot(end_point['x'], end_point['y'], 'bo', markersize=8)

            # Add coordinate info
            ax2.text(start_point['x'], start_point['y'] - 20,
                    f"Door {i + 1} (Wall-Aligned)\nStart: ({start_point['x']:.0f}, {start_point['y']:.0f})\nEnd: ({end_point['x']:.0f}, {end_point['y']:.0f})",
                    fontsize=8, color='black',
                    bbox=dict(boxstyle="round,pad=0.3", facecolor='yellow', alpha=0.8))

        # Add legends
        ax2.plot([], [], 'go', markersize=8, label='Start Point')
        ax2.plot([], [], 'bo', markersize=8, label='End Point')
        ax2.legend(loc='upper right')

        for ax in [ax1, ax2]:
            ax.axis('off')

        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'door_analysis_wall_aligned.png'), dpi=300, bbox_inches='tight')
        plt.close()

    def _find_wall_intersection_points(self, door: Dict, wall: Dict) -> Dict:
        """Find exact intersection points between door and wall boundaries."""
        door_bbox = door['bounding_box']
        wall_bbox = wall['bounding_box']
        orientation = door['orientation']
        
        # Calculate overlap regions
        overlap_x1 = max(door_bbox['x1'], wall_bbox['x1'])
        overlap_y1 = max(door_bbox['y1'], wall_bbox['y1'])
        overlap_x2 = min(door_bbox['x2'], wall_bbox['x2'])
        overlap_y2 = min(door_bbox['y2'], wall_bbox['y2'])
        
        # Check if there's actual overlap
        if overlap_x1 >= overlap_x2 or overlap_y1 >= overlap_y2:
            return None
        
        if orientation == "horizontal":
            # For horizontal doors, find the wall edge that the door should align with
            # Typically, doors align with the bottom edge of walls
            wall_edge_y = wall_bbox['y2']
            
            # Door line spans the overlap region horizontally
            return {
                'start_point': {"x": overlap_x1, "y": wall_edge_y},
                'end_point': {"x": overlap_x2, "y": wall_edge_y}
            }
        
        elif orientation == "vertical":
            # For vertical doors, find the wall edge that the door should align with
            # Typically, doors align with the right edge of walls
            wall_edge_x = wall_bbox['x2']
            
            # Door line spans the overlap region vertically
            return {
                'start_point': {"x": wall_edge_x, "y": overlap_y1},
                'end_point': {"x": wall_edge_x, "y": overlap_y2}
            }
        
        return None





    def _get_class_type(self, class_name: str) -> str:
        class_name = class_name.lower()
        if class_name in ['wall', 'door', 'window', 'room']:
            return "structural"
        elif class_name in ['sofa', 'table', 'chair', 'bed']:
            return "furniture"
        else:
            return "fixture"
            
    def _estimate_depth_m(self, class_name: str) -> float:
        class_name = class_name.lower()
        if class_name == 'wall': return 0.15
        if class_name == 'door': return 0.05
        if class_name == 'window': return 0.10
        return 0.10

    def _analyze_spatial_relationships(self, objects: List[Dict]) -> List[Dict]:
        relationships = []
        for i in range(len(objects)):
            for j in range(i + 1, len(objects)):
                obj1, obj2 = objects[i], objects[j]
                dist = math.sqrt((obj1['center_point']['x'] - obj2['center_point']['x'])**2 + (obj1['center_point']['y'] - obj2['center_point']['y'])**2)
                if dist < 50:
                    relationships.append({
                        "object_id_1": obj1['id'], "object_id_2": obj2['id'],
                        "relationship": "adjacent", "distance_px": dist,
                        "confidence": (obj1['confidence_score'] + obj2['confidence_score']) / 2
                    })
        return relationships

    def _build_global_json(self, session_id, objects, relationships, ai_result, image_dims, scale_factor, avg_door_px):
        confidences = [obj['confidence_score'] for obj in objects] if objects else [0]
        return {
            "metadata": {
                "version": "2.0", "timestamp": datetime.now().isoformat(), "session_id": str(session_id),
                "stage_type": "global", "stage_name": self.stage_name, "stage_number": self.stage_number,
                "ai_model_used": ai_result.get('model_info', {}).get('name', 'unknown'),
                "image_dimensions": image_dims
            },
            "global_context": {
                "scale_factor": scale_factor,
                "coordinate_system": "pixel",
                "units": "meters",
                "reference_points": [{
                    "type": "door", "average_pixels": avg_door_px, "real_width_meters": self.REAL_DOOR_WIDTH_METERS
                }],
                "overall_confidence": np.mean(confidences) if confidences else 0.0
            },
            "detected_objects": objects,
            "spatial_relationships": relationships
        }
        
    def _extract_confidence_scores(self, json_output: Dict) -> Dict[str, float]:
        objects = json_output.get('detected_objects', [])
        if not objects: return {}
        confidences = [obj.get('confidence_score', 0.0) for obj in objects]
        return {
            'average_confidence': np.mean(confidences) if confidences else 0.0,
            'min_confidence': np.min(confidences) if confidences else 0.0,
            'max_confidence': np.max(confidences) if confidences else 0.0,
        }

    def _generate_visualizations(self, image_path: str, processed_objects: List[Dict], 
                               ai_raw_result: Dict, session_id: int, output_dir: str = None):
        """Generate comprehensive visualizations for analysis"""
        
        if output_dir is None:
            output_dir = f"./visualizations/session_{session_id}"
        
        os.makedirs(output_dir, exist_ok=True)
        
        # Generate multiple visualization types
        self._create_bounding_box_visualization(image_path, processed_objects, output_dir)
        self._create_door_analysis_visualization(image_path, processed_objects, output_dir)
        self._create_detailed_door_visualization(image_path, processed_objects, output_dir)
        self._create_coordinate_analysis_visualization(image_path, processed_objects, output_dir)
        self._create_detection_summary_report(processed_objects, ai_raw_result, output_dir)
        
        logger.info(f"Visualizations saved to {output_dir}")

    def _create_bounding_box_visualization(self, image_path: str, processed_objects: List[Dict], output_dir: str):
        """Create visualization showing bounding boxes for all objects. Draw doors as rectangles."""
        
        # Load original image
        img = cv2.imread(image_path)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        fig, ax = plt.subplots(1, 1, figsize=(15, 10))
        ax.imshow(img_rgb)
        
        for obj in processed_objects:
            bbox = obj['bounding_box']
            class_name = obj['class_name']
            confidence = obj['confidence_score']
            color = self.color_map.get(class_name.lower(), self.color_map['default'])
            
            x1, y1 = bbox['x1'], bbox['y1']
            x2, y2 = bbox['x2'], bbox['y2']
            width = x2 - x1
            height = y2 - y1

            # 🟥 Draw doors as rectangles using all 4 coordinates
            if class_name.lower() == 'door':
                rect = Rectangle((x1, y1), width, height,
                                linewidth=3, edgecolor=color, facecolor='none')
                ax.add_patch(rect)
            else:
                # Keep existing logic for other objects
                rect = Rectangle((x1, y1), width, height,
                                linewidth=2, edgecolor=color, facecolor='none')
                ax.add_patch(rect)
            
            # Add label
            ax.text(x1, y1 - 5, f"{class_name} ({confidence:.2f})",
                    color=color, fontsize=8, fontweight='bold',
                    bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.8))
        
        ax.set_title('All Detected Objects with Bounding Boxes', fontsize=16, fontweight='bold')
        ax.axis('off')
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'bounding_boxes_all.png'), dpi=300, bbox_inches='tight')
        plt.close()


   
    def _create_detailed_door_visualization(self, image_path: str, processed_objects: List[Dict], output_dir: str):
        """Create individual door analysis plots"""
        
        doors = [obj for obj in processed_objects if obj['class_name'].lower() == 'door']
        
        if not doors:
            return
        
        # Load original image
        img = cv2.imread(image_path)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        # Create subplot for each door
        n_doors = len(doors)
        if n_doors == 0:
            return
            
        cols = min(3, n_doors)
        rows = (n_doors + cols - 1) // cols
        
        fig, axes = plt.subplots(rows, cols, figsize=(6*cols, 6*rows))
        if n_doors == 1:
            axes = [axes]
        elif rows == 1:
            axes = axes
        else:
            axes = axes.flatten()
        
        for i, door in enumerate(doors):
            if i >= len(axes):
                break
                
            ax = axes[i]
            
            # Get door region with some padding
            bbox = door['bounding_box']
            padding = 50
            x1 = max(0, int(bbox['x1'] - padding))
            y1 = max(0, int(bbox['y1'] - padding))
            x2 = min(img_rgb.shape[1], int(bbox['x2'] + padding))
            y2 = min(img_rgb.shape[0], int(bbox['y2'] + padding))
            
            # Crop image region
            door_region = img_rgb[y1:y2, x1:x2]
            ax.imshow(door_region)
            
            # Adjust coordinates for cropped region
            adj_bbox = {
                'x1': bbox['x1'] - x1,
                'y1': bbox['y1'] - y1,
                'x2': bbox['x2'] - x1,
                'y2': bbox['y2'] - y1
            }
            
            adj_start = {
                'x': door['start_point']['x'] - x1,
                'y': door['start_point']['y'] - y1
            }
            
            adj_end = {
                'x': door['end_point']['x'] - x1,
                'y': door['end_point']['y'] - y1
            }
            
            # Draw bounding box
            rect = Rectangle((adj_bbox['x1'], adj_bbox['y1']), 
                           adj_bbox['x2'] - adj_bbox['x1'], 
                           adj_bbox['y2'] - adj_bbox['y1'],
                           linewidth=2, edgecolor='red', facecolor='none')
            ax.add_patch(rect)
            
            # Draw door line
            ax.plot([adj_start['x'], adj_end['x']], 
                   [adj_start['y'], adj_end['y']], 
                   'r-', linewidth=3)
            
            # Mark points
            ax.plot(adj_start['x'], adj_start['y'], 'go', markersize=8)
            ax.plot(adj_end['x'], adj_end['y'], 'bo', markersize=8)
            
            # Add title with door info
            ax.set_title(f'Door {i+1} - {door["orientation"]}\n' + 
                        f'Size: {door["dimensions"]["width_px"]:.0f}x{door["dimensions"]["height_px"]:.0f}px\n' +
                        f'Confidence: {door["confidence_score"]:.2f}', 
                        fontsize=10)
            ax.axis('off')
        
        # Hide unused subplots
        for i in range(n_doors, len(axes)):
            axes[i].axis('off')
        
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'door_details.png'), dpi=300, bbox_inches='tight')
        plt.close()

    def _create_coordinate_analysis_visualization(self, image_path: str, processed_objects: List[Dict], output_dir: str):
        """Create coordinate system analysis visualization"""
        
        # Load original image
        img = cv2.imread(image_path)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        fig, ax = plt.subplots(1, 1, figsize=(15, 10))
        ax.imshow(img_rgb)
        
        # Draw coordinate grid
        height, width = img_rgb.shape[:2]
        
        # Draw grid lines every 100 pixels
        for x in range(0, width, 100):
            ax.axvline(x, color='gray', alpha=0.3, linewidth=0.5)
        for y in range(0, height, 100):
            ax.axhline(y, color='gray', alpha=0.3, linewidth=0.5)
        
        # Add coordinate labels
        for x in range(0, width, 200):
            ax.text(x, 20, f'x={x}', fontsize=8, color='blue', 
                   bbox=dict(boxstyle="round,pad=0.2", facecolor='white', alpha=0.8))
        
        for y in range(0, height, 200):
            ax.text(20, y, f'y={y}', fontsize=8, color='blue',
                   bbox=dict(boxstyle="round,pad=0.2", facecolor='white', alpha=0.8))
        
        # Highlight doors with coordinate information
        doors = [obj for obj in processed_objects if obj['class_name'].lower() == 'door']
        
        for i, door in enumerate(doors):
            bbox = door['bounding_box']
            start_point = door['start_point']
            end_point = door['end_point']
            
            # Draw door line
            ax.plot([start_point['x'], end_point['x']], 
                   [start_point['y'], end_point['y']], 
                   'r-', linewidth=3)
            
            # Add detailed coordinate info
            coord_text = f"Door {i+1}\nBBox: ({bbox['x1']:.0f},{bbox['y1']:.0f}) to ({bbox['x2']:.0f},{bbox['y2']:.0f})\nLine: ({start_point['x']:.0f},{start_point['y']:.0f}) to ({end_point['x']:.0f},{end_point['y']:.0f})"
            ax.text(bbox['x1'], bbox['y2'] + 10, coord_text, 
                   fontsize=8, color='red',
                   bbox=dict(boxstyle="round,pad=0.3", facecolor='yellow', alpha=0.9))
        
        ax.set_title('Coordinate System Analysis\n(Grid lines every 100px, labels every 200px)', 
                    fontsize=14, fontweight='bold')
        ax.axis('off')
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'coordinate_analysis.png'), dpi=300, bbox_inches='tight')
        plt.close()

    def _create_detection_summary_report(self, processed_objects: List[Dict], ai_raw_result: Dict, output_dir: str):
        """Create a detailed text report of all detections"""
        
        report_path = os.path.join(output_dir, 'detection_report.txt')
        
        with open(report_path, 'w') as f:
            f.write("GLOBAL DETECTION ANALYSIS REPORT\n")
            f.write("=" * 50 + "\n\n")
            
            # Summary statistics
            f.write("SUMMARY STATISTICS\n")
            f.write("-" * 20 + "\n")
            f.write(f"Total objects detected: {len(processed_objects)}\n")
            
            # Count by class
            class_counts = {}
            for obj in processed_objects:
                class_name = obj['class_name']
                class_counts[class_name] = class_counts.get(class_name, 0) + 1
            
            f.write("Objects by class:\n")
            for class_name, count in sorted(class_counts.items()):
                f.write(f"  {class_name}: {count}\n")
            
            f.write(f"\nAverage door size (pixels): {ai_raw_result.get('averageDoor', 'N/A')}\n")
            f.write(f"Scale factor: {ai_raw_result.get('scale_factor', 'N/A')}\n\n")
            
            # Detailed door analysis
            doors = [obj for obj in processed_objects if obj['class_name'].lower() == 'door']
            
            if doors:
                f.write("DETAILED DOOR ANALYSIS\n")
                f.write("-" * 25 + "\n")
                
                for i, door in enumerate(doors, 1):
                    f.write(f"\nDoor {i}:\n")
                    f.write(f"  ID: {door['id']}\n")
                    f.write(f"  Orientation: {door['orientation']}\n")
                    f.write(f"  Confidence: {door['confidence_score']:.3f}\n")
                    f.write(f"  Bounding Box: ({door['bounding_box']['x1']:.0f}, {door['bounding_box']['y1']:.0f}) to ({door['bounding_box']['x2']:.0f}, {door['bounding_box']['y2']:.0f})\n")
                    f.write(f"  Dimensions (px): {door['dimensions']['width_px']:.0f} x {door['dimensions']['height_px']:.0f}\n")
                    f.write(f"  Dimensions (m): {door['dimensions']['width_m']:.2f} x {door['dimensions']['height_m']:.2f}\n")
                    f.write(f"  Center Point: ({door['center_point']['x']:.0f}, {door['center_point']['y']:.0f})\n")
                    f.write(f"  Line Start: ({door['start_point']['x']:.0f}, {door['start_point']['y']:.0f})\n")
                    f.write(f"  Line End: ({door['end_point']['x']:.0f}, {door['end_point']['y']:.0f})\n")
                    
                    # Calculate line length
                    line_length = math.sqrt((door['end_point']['x'] - door['start_point']['x'])**2 + 
                                          (door['end_point']['y'] - door['start_point']['y'])**2)
                    f.write(f"  Line Length: {line_length:.0f} pixels\n")
            
            # All objects summary
            f.write("\n\nALL DETECTED OBJECTS\n")
            f.write("-" * 20 + "\n")
            
            for i, obj in enumerate(processed_objects, 1):
                f.write(f"\nObject {i}:\n")
                f.write(f"  Class: {obj['class_name']} ({obj['class_type']})\n")
                f.write(f"  Confidence: {obj['confidence_score']:.3f}\n")
                f.write(f"  Bounding Box: ({obj['bounding_box']['x1']:.0f}, {obj['bounding_box']['y1']:.0f}) to ({obj['bounding_box']['x2']:.0f}, {obj['bounding_box']['y2']:.0f})\n")
                f.write(f"  Dimensions: {obj['dimensions']['width_px']:.0f} x {obj['dimensions']['height_px']:.0f} pixels\n")
                if obj['class_name'].lower() in ['door', 'window']:
                    f.write(f"  Orientation: {obj['orientation']}\n")
        
        logger.info(f"Detection report saved to {report_path}")

    def analyze_door_placement_issues(self, processed_objects: List[Dict], output_dir: str = None):
        """Analyze specific door placement issues and provide recommendations"""
        
        doors = [obj for obj in processed_objects if obj['class_name'].lower() == 'door']
        walls = [obj for obj in processed_objects if obj['class_name'].lower() == 'wall']
        
        if not doors:
            logger.warning("No doors found for placement analysis")
            return
        
        analysis_results = {
            'total_doors': len(doors),
            'total_walls': len(walls),
            'door_issues': [],
            'recommendations': []
        }
        
        for i, door in enumerate(doors):
            door_analysis = {
                'door_id': i + 1,
                'orientation': door['orientation'],
                'bbox': door['bounding_box'],
                'line_coords': {
                    'start': door['start_point'],
                    'end': door['end_point']
                },
                'issues': []
            }
            
            # Check if door line extends beyond bounding box (it shouldn't in current implementation)
            bbox = door['bounding_box']
            start = door['start_point']
            end = door['end_point']
            
            # Issue 1: Door line spans entire bounding box
            if door['orientation'] == 'horizontal':
                if abs(start['x'] - bbox['x1']) < 5 and abs(end['x'] - bbox['x2']) < 5:
                    door_analysis['issues'].append("Door line spans entire bounding box width - should be positioned in wall gap")
            elif door['orientation'] == 'vertical':
                if abs(start['y'] - bbox['y1']) < 5 and abs(end['y'] - bbox['y2']) < 5:
                    door_analysis['issues'].append("Door line spans entire bounding box height - should be positioned in wall gap")
            
            # Issue 2: Check for nearby walls
            nearby_walls = []
            door_center = door['center_point']
            
            for wall in walls:
                wall_center = wall['center_point']
                distance = math.sqrt((door_center['x'] - wall_center['x'])**2 + 
                                   (door_center['y'] - wall_center['y'])**2)
                if distance < 100:  # Within 100 pixels
                    nearby_walls.append({'wall': wall, 'distance': distance})
            
            door_analysis['nearby_walls'] = len(nearby_walls)
            if len(nearby_walls) == 0:
                door_analysis['issues'].append("No nearby walls detected - door may be floating")
            
            # Issue 3: Check orientation vs aspect ratio
            width = bbox['x2'] - bbox['x1']
            height = bbox['y2'] - bbox['y1']
            aspect_ratio = width / height if height > 0 else 1
            
            if door['orientation'] == 'horizontal' and aspect_ratio < 1.5:
                door_analysis['issues'].append(f"Marked as horizontal but aspect ratio is {aspect_ratio:.2f} - may be incorrectly oriented")
            elif door['orientation'] == 'vertical' and aspect_ratio > 0.7:
                door_analysis['issues'].append(f"Marked as vertical but aspect ratio is {aspect_ratio:.2f} - may be incorrectly oriented")
            
            analysis_results['door_issues'].append(door_analysis)
        
        # Generate recommendations
        analysis_results['recommendations'] = [
            "1. Implement wall gap detection to position doors only within wall openings",
            "2. Use wall intersection analysis to determine actual door placement",
            "3. Consider door swing direction and placement within the gap",
            "4. Validate door orientation against actual architectural drawings",
            "5. Implement door-wall relationship validation",
            "6. Add door width estimation based on standard architectural dimensions"
        ]
        
        # Save analysis results
        if output_dir:
            analysis_path = os.path.join(output_dir, 'door_placement_analysis.json')
            with open(analysis_path, 'w') as f:
                json.dump(analysis_results, f, indent=2)
            
            # Also create a readable report
            report_path = os.path.join(output_dir, 'door_placement_issues.txt')
            with open(report_path, 'w') as f:
                f.write("DOOR PLACEMENT ISSUES ANALYSIS\n")
                f.write("=" * 40 + "\n\n")
                
                f.write(f"Total doors analyzed: {analysis_results['total_doors']}\n")
                f.write(f"Total walls detected: {analysis_results['total_walls']}\n\n")
                
                for door_issue in analysis_results['door_issues']:
                    f.write(f"Door {door_issue['door_id']} ({door_issue['orientation']}):\n")
                    f.write(f"  Bounding Box: ({door_issue['bbox']['x1']:.0f}, {door_issue['bbox']['y1']:.0f}) to ({door_issue['bbox']['x2']:.0f}, {door_issue['bbox']['y2']:.0f})\n")
                    f.write(f"  Line: ({door_issue['line_coords']['start']['x']:.0f}, {door_issue['line_coords']['start']['y']:.0f}) to ({door_issue['line_coords']['end']['x']:.0f}, {door_issue['line_coords']['end']['y']:.0f})\n")
                    f.write(f"  Nearby walls: {door_issue['nearby_walls']}\n")
                    
                    if door_issue['issues']:
                        f.write("  Issues identified:\n")
                        for issue in door_issue['issues']:
                            f.write(f"    - {issue}\n")
                    else:
                        f.write("  No major issues identified\n")
                    f.write("\n")
                
                f.write("RECOMMENDATIONS:\n")
                f.write("-" * 15 + "\n")
                for rec in analysis_results['recommendations']:
                    f.write(f"{rec}\n")
        
        return analysis_results

# Example usage function
def run_enhanced_detection_with_visualization(session_id: int, image_path: str, 
                                            ai_engine_controller, database_manager,
                                            output_dir: str = None):
    """
    Helper function to run the enhanced detection with all visualizations
    """
    
    # Initialize detector
    detector = GlobalDetector(ai_engine_controller, database_manager)
    
    # Define AI model flags (adjust as needed for your setup)
    ai_model_flags = {
        'use_maskrcnn': True,
        'confidence_threshold': 0.5,
        'nms_threshold': 0.3
    }
    
    # Run detection with visualization
    results = detector.process(
        session_id=session_id,
        image_path=image_path,
        ai_model_flags=ai_model_flags,
        enable_visualization=True,
        output_dir=output_dir
    )
    
    # Run additional door placement analysis
    processed_objects = results['json_output']['detected_objects']
    door_analysis = detector.analyze_door_placement_issues(processed_objects, output_dir)
    
    print(f"Detection completed!")
    print(f"Objects detected: {results['objects_detected']}")
    print(f"Processing time: {results['processing_time_ms']}ms")
    print(f"Visualizations saved to: {output_dir}")
    
    return results, door_analysis

# Additional utility functions for door analysis
def compare_door_detection_methods(original_objects: List[Dict], output_dir: str):
    """Compare current door detection method with potential improvements"""
    
    doors = [obj for obj in original_objects if obj['class_name'].lower() == 'door']
    
    if not doors:
        return
    
    comparison_data = []
    
    for i, door in enumerate(doors):
        bbox = door['bounding_box']
        current_method = {
            'door_id': i + 1,
            'current_start': door['start_point'],
            'current_end': door['end_point'],
            'current_length': math.sqrt((door['end_point']['x'] - door['start_point']['x'])**2 + 
                                      (door['end_point']['y'] - door['start_point']['y'])**2)
        }
        
        # Propose alternative method: center-based with reduced length
        center_x = (bbox['x1'] + bbox['x2']) / 2
        center_y = (bbox['y1'] + bbox['y2']) / 2
        
        if door['orientation'] == 'horizontal':
            # Reduce door line to 60% of bounding box width, centered
            width = bbox['x2'] - bbox['x1']
            reduced_width = width * 0.6
            proposed_start = {'x': center_x - reduced_width/2, 'y': center_y}
            proposed_end = {'x': center_x + reduced_width/2, 'y': center_y}
        else:  # vertical
            # Reduce door line to 60% of bounding box height, centered
            height = bbox['y2'] - bbox['y1']
            reduced_height = height * 0.6
            proposed_start = {'x': center_x, 'y': center_y - reduced_height/2}
            proposed_end = {'x': center_x, 'y': center_y + reduced_height/2}
        
        current_method['proposed_start'] = proposed_start
        current_method['proposed_end'] = proposed_end
        current_method['proposed_length'] = math.sqrt((proposed_end['x'] - proposed_start['x'])**2 + 
                                                    (proposed_end['y'] - proposed_start['y'])**2)
        
        comparison_data.append(current_method)
    
    # Save comparison data
    comparison_path = os.path.join(output_dir, 'door_method_comparison.json')
    with open(comparison_path, 'w') as f:
        json.dump(comparison_data, f, indent=2)
    
    return comparison_data

def generate_door_correction_suggestions(processed_objects: List[Dict], output_dir: str):
    """Generate specific suggestions for correcting door placement"""
    
    doors = [obj for obj in processed_objects if obj['class_name'].lower() == 'door']
    walls = [obj for obj in processed_objects if obj['class_name'].lower() == 'wall']
    
    suggestions = {
        'methodology_changes': [
            "Replace full bounding box lines with gap-based positioning",
            "Implement wall edge detection for door placement",
            "Add door swing analysis for proper orientation",
            "Use architectural standards for door dimensions"
        ],
        'code_modifications': [
            "Modify _create_enhanced_objects to detect wall gaps",
            "Add wall intersection analysis function",
            "Implement door-wall relationship validation",
            "Add confidence scoring based on wall proximity"
        ],
        'detection_improvements': [
            "Train model to detect door openings, not just door objects",
            "Implement post-processing to align doors with walls",
            "Add context-aware door positioning",
            "Use building layout understanding for door placement"
        ]
    }
    
    # Save suggestions
    suggestions_path = os.path.join(output_dir, 'door_correction_suggestions.json')
    with open(suggestions_path, 'w') as f:
        json.dump(suggestions, f, indent=2)
    
    return suggestions