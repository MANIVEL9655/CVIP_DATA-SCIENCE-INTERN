# api_projects.py

import logging
import os
from fastapi import APIRouter, Depends, HTTPException, File, UploadFile, Form
from sqlalchemy.orm import Session
from typing import List, Dict, Any

from database_manager import get_db, db_manager
from repositories import ProjectRepository
from models import Project, ProjectStatus, ImageFormat, SessionStatus
from processing_pipeline import run_complete_pipeline_sync  # New synchronous function
from image_utils import (
    validate_image_file, 
    extract_image_metadata, 
    save_uploaded_file, 
    generate_safe_filename,
    validate_file_for_processing,
    ImageValidationError
)
from pydantic import BaseModel
from fastapi import Body
import json

SCALE_FACTOR = 1.0
WALL_HEIGHT_CM = 300.0
WALL_THICKNESS_CM = 20.0
CANVAS_WIDTH = 4000
CANVAS_HEIGHT = 4000

# Pydantic models for request validation
class CreateProjectFromScratchRequest(BaseModel):
    project_name: str
    description: str = None
    floorplan: dict



# def setup_default_thumbnail():
#     """
#     Setup and return path to default thumbnail image.
#     Creates a default thumbnail if it doesn't exist.
#     """
#     default_thumbnails_dir = os.path.join(UPLOAD_DIRECTORY, "defaults")
#     os.makedirs(default_thumbnails_dir, exist_ok=True)
    
#     default_thumbnail_path = os.path.join(default_thumbnails_dir, "default_floorplan_thumbnail.png")
    
#     # Check if default thumbnail already exists
#     if not os.path.exists(default_thumbnail_path):
#         create_default_thumbnail_image(default_thumbnail_path)
    
#     return default_thumbnail_path


def setup_default_thumbnail():
    """
    Returns path to the existing default thumbnail image stored under project root /thumbnail directory.
    """
    # Path to the existing thumbnail in project root
    default_thumbnail_path = os.path.join(os.getcwd(), "thumbnail", "logo.jpg")

    # Ensure the file exists
    if not os.path.exists(default_thumbnail_path):
        raise FileNotFoundError(f"Default thumbnail not found at {default_thumbnail_path}")

    return default_thumbnail_path


def create_default_thumbnail_image(output_path: str):
    """
    Create a default thumbnail image programmatically.
    This creates a simple placeholder image for projects created from scratch.
    """
    try:
        from PIL import Image, ImageDraw, ImageFont
        
        # Create a default 512x512 image
        width, height = 512, 512
        background_color = (240, 248, 255)  # Alice blue
        border_color = (100, 149, 237)      # Cornflower blue
        text_color = (70, 130, 180)         # Steel blue
        
        # Create image
        image = Image.new('RGB', (width, height), background_color)
        draw = ImageDraw.Draw(image)
        
        # Draw border
        border_width = 8
        draw.rectangle([0, 0, width-1, height-1], outline=border_color, width=border_width)
        
        # Draw inner decorative rectangle
        inner_margin = 50
        draw.rectangle([inner_margin, inner_margin, width-inner_margin, height-inner_margin], 
                      outline=border_color, width=2)
        
        # Add text
        try:
            # Try to use a nice font, fallback to default if not available
            try:
                font = ImageFont.truetype("arial.ttf", 36)
                small_font = ImageFont.truetype("arial.ttf", 20)
            except:
                font = ImageFont.load_default()
                small_font = ImageFont.load_default()
            
            # Main text
            main_text = "FLOORPLAN"
            text_bbox = draw.textbbox((0, 0), main_text, font=font)
            text_width = text_bbox[2] - text_bbox[0]
            text_height = text_bbox[3] - text_bbox[1]
            text_x = (width - text_width) // 2
            text_y = (height - text_height) // 2 - 30
            draw.text((text_x, text_y), main_text, fill=text_color, font=font)
            
            # Subtitle
            subtitle = "Default Thumbnail"
            subtitle_bbox = draw.textbbox((0, 0), subtitle, font=small_font)
            subtitle_width = subtitle_bbox[2] - subtitle_bbox[0]
            subtitle_x = (width - subtitle_width) // 2
            subtitle_y = text_y + text_height + 20
            draw.text((subtitle_x, subtitle_y), subtitle, fill=text_color, font=small_font)
            
        except Exception as font_error:
            logger.warning(f"Font rendering issue: {font_error}")
            # Simple fallback text
            draw.text((width//2-60, height//2), "FLOORPLAN", fill=text_color)
        
        # Add some decorative elements (simple geometric shapes)
        # Top-left corner
        draw.rectangle([80, 80, 120, 120], fill=border_color)
        # Top-right corner  
        draw.rectangle([width-120, 80, width-80, 120], fill=border_color)
        # Bottom-left corner
        draw.rectangle([80, height-120, 120, height-80], fill=border_color)
        # Bottom-right corner
        draw.rectangle([width-120, height-120, width-80, height-80], fill=border_color)
        
        # Save the image
        image.save(output_path, "PNG", optimize=True)
        logger.info(f"Created default thumbnail: {output_path}")
        
    except ImportError:
        logger.warning("PIL not available, creating simple text file as placeholder")
        # Fallback: create a simple text file if PIL is not available
        with open(output_path.replace('.png', '.txt'), 'w') as f:
            f.write("Default Floorplan Thumbnail - Install PIL for image generation")
        return output_path.replace('.png', '.txt')
    except Exception as e:
        logger.error(f"Error creating default thumbnail: {e}")
        # Create an even simpler fallback
        create_simple_default_thumbnail(output_path)

def create_simple_default_thumbnail(output_path: str):
    """
    Create a very simple default thumbnail as fallback.
    """
    try:
        from PIL import Image
        # Create a simple solid color image
        image = Image.new('RGB', (512, 512), (240, 248, 255))
        image.save(output_path, "PNG")
        logger.info(f"Created simple default thumbnail: {output_path}")
    except:
        # Ultimate fallback - copy from a template if exists or create empty file
        with open(output_path, 'wb') as f:
            # Create minimal PNG header for a 1x1 transparent pixel
            f.write(b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\nIDATx\x9cc\x00\x01\x00\x00\x05\x00\x01\r\n-\xdb\x00\x00\x00\x00IEND\xaeB`\x82')

# def get_default_image_info():
#     """
#     Return metadata information for the default thumbnail image.
#     """
#     default_path = setup_default_thumbnail()
    
#     try:
#         if os.path.exists(default_path):
#             file_size = os.path.getsize(default_path)
            
#             # Try to get actual image info if PIL is available
#             try:
#                 from PIL import Image
#                 with Image.open(default_path) as img:
#                     width, height = img.size
#                     format_str = img.format.lower() if img.format else 'png'
#                     mode = img.mode
#                     has_transparency = 'transparency' in img.info or mode in ('RGBA', 'LA')
#             except ImportError:
#                 # Fallback values if PIL not available
#                 width, height = 512, 512
#                 format_str = 'png'
#                 mode = 'RGB'
#                 has_transparency = False
            
#             # Map format string to your ImageFormat enum
#             if format_str in ['jpg', 'jpeg']:
#                 image_format = ImageFormat.JPEG
#             elif format_str == 'png':
#                 image_format = ImageFormat.PNG
#             elif format_str == 'gif':
#                 image_format = ImageFormat.GIF
#             elif format_str == 'bmp':
#                 image_format = ImageFormat.BMP
#             else:
#                 image_format = ImageFormat.PNG  # Default fallback
            
#             return {
#                 'width': width,
#                 'height': height,
#                 'dpi': 72,
#                 'size_bytes': file_size,
#                 'size_mb': round(file_size / (1024 * 1024), 4),
#                 'format': image_format,
#                 'color_mode': mode,
#                 'has_transparency': has_transparency,
#                 'aspect_ratio': round(width / height, 2) if height > 0 else 1.0
#             }
#         else:
#             # Return default values if file doesn't exist
#             return {
#                 'width': 512,
#                 'height': 512,
#                 'dpi': 72,
#                 'size_bytes': 1024,
#                 'size_mb': 0.001,
#                 'format': ImageFormat.PNG,
#                 'color_mode': 'RGB',
#                 'has_transparency': False,
#                 'aspect_ratio': 1.0
#             }
#     except Exception as e:
#         logger.error(f"Error getting default image info: {e}")
#         return {
#             'width': 512,
#             'height': 512,
#             'dpi': 72,
#             'size_bytes': 1024,
#             'size_mb': 0.001,
#             'format': ImageFormat.PNG,
#             'color_mode': 'RGB',
#             'has_transparency': False,
#             'aspect_ratio': 1.0
#         }


def get_default_image_info():
    """
    Return metadata information for the existing default thumbnail image.
    """
    default_path = setup_default_thumbnail()

    try:
        from PIL import Image
        with Image.open(default_path) as img:
            width, height = img.size
            format_str = img.format.lower() if img.format else 'png'
            mode = img.mode
            has_transparency = 'transparency' in img.info or mode in ('RGBA', 'LA')

        file_size = os.path.getsize(default_path)

        # Map format string to your ImageFormat enum
        if format_str in ['jpg', 'jpeg']:
            image_format = ImageFormat.JPEG
        elif format_str == 'png':
            image_format = ImageFormat.PNG
        elif format_str == 'gif':
            image_format = ImageFormat.GIF
        elif format_str == 'bmp':
            image_format = ImageFormat.BMP
        else:
            image_format = ImageFormat.PNG  # fallback

        return {
            'width': width,
            'height': height,
            'dpi': 72,
            'size_bytes': file_size,
            'size_mb': round(file_size / (1024 * 1024), 4),
            'format': image_format,
            'color_mode': mode,
            'has_transparency': has_transparency,
            'aspect_ratio': round(width / height, 2) if height > 0 else 1.0
        }

    except Exception as e:
        logger.error(f"Error getting default image info: {e}")
        return {
            'width': 512,
            'height': 512,
            'dpi': 72,
            'size_bytes': 1024,
            'size_mb': 0.001,
            'format': ImageFormat.PNG,
            'color_mode': 'RGB',
            'has_transparency': False,
            'aspect_ratio': 1.0
        }


logger = logging.getLogger(__name__)
router = APIRouter()

UPLOAD_DIRECTORY = os.getenv("UPLOAD_PATH", "./uploads")
os.makedirs(UPLOAD_DIRECTORY, exist_ok=True)

# api_projects.py - Fixed create_project function

# @router.post("/projects", response_model=Dict[str, Any])
# def create_project(
#     name: str = Form(...),
#     description: str = Form(None),
#     image_file: UploadFile = File(...),
#     model: str = Form("yolo"),  # Model selection flag
#     db: Session = Depends(get_db)
# ):
#     """
#     Create a new project with a floorplan image and run the complete processing pipeline.
#     Returns response only after the entire pipeline is completed with download path.
#     """
#     project_repo = ProjectRepository(db)

#     try:
#         # Step 1: Validate the uploaded image file
#         logger.info(f"Validating uploaded image: {image_file.filename}")
#         validation_result = validate_image_file(image_file)
        
#         if not validation_result['is_valid']:
#             raise HTTPException(
#                 status_code=400, 
#                 detail=f"Image validation failed: {validation_result['error_message']}"
#             )
        
#         file_info = validation_result['file_info']
#         logger.info(f"Image validation successful: {file_info['image_width']}x{file_info['image_height']}")

#         # Step 2: Generate safe filename and save file
#         safe_filename = generate_safe_filename(image_file.filename, name)
#         file_location = os.path.join(UPLOAD_DIRECTORY, safe_filename)
        
#         # Save the uploaded file
#         saved_path = save_uploaded_file(image_file, file_location)
#         logger.info(f"Image saved to: {saved_path}")

#         # Step 3: Extract additional metadata from saved file
#         additional_metadata = extract_image_metadata(saved_path)
        
#         # Step 4: Validate file for AI processing
#         if not validate_file_for_processing(saved_path):
#             logger.warning(f"Image may not be optimal for AI processing, but proceeding...")

#         # Step 5: Map model string to ai_model_flags
#         model = model.lower()
#         if model == "yolo":
#             ai_model_flags = {"maskrcnn": False, "yolo": True, "both": False}
#         elif model == "maskrcnn":
#             ai_model_flags = {"maskrcnn": True, "yolo": False, "both": False}
#         elif model == "both":
#             ai_model_flags = {"maskrcnn": False, "yolo": False, "both": True}
#         else:
#             raise HTTPException(
#                 status_code=400, 
#                 detail="Invalid model. Choose from 'maskrcnn', 'yolo', or 'both'."
#             )

#         # Step 6: Create project with enhanced image metadata
#         project = project_repo.create(
#             name=name,
#             description=description,
#             original_image_path=saved_path,
#             image_width=file_info['image_width'],
#             image_height=file_info['image_height'],
#             image_resolution_dpi=additional_metadata.get('image_resolution_dpi', 72),
#             image_size_bytes=file_info['file_size_bytes'],
#             image_format=ImageFormat(file_info['image_format']),
#             image_color_mode=file_info['image_mode'],
#             image_has_transparency=file_info['has_transparency'],
#             image_aspect_ratio=file_info['aspect_ratio'],
#             image_dimensions={
#                 "width": file_info['image_width'],
#                 "height": file_info['image_height'],
#                 "resolution": additional_metadata.get('image_resolution_dpi', 72),
#                 "file_size_mb": round(file_info['file_size_bytes'] / (1024 * 1024), 2),
#                 "format": file_info['image_format'],
#                 "color_mode": file_info['image_mode'],
#                 "has_transparency": file_info['has_transparency'],
#                 "aspect_ratio": file_info['aspect_ratio']
#             }
#         )
        
#         logger.info(f"Project '{name}' (ID: {project.id}) created with enhanced metadata.")

#         # Step 7: Prepare processing configuration
#         processing_config = {
#             "ai_model_flags": ai_model_flags,
#             "processing_config": {
#                 "confidence_threshold": 0.7,
#                 "refinement_levels": 4,
#                 "optimization_enabled": True,
#                 "image_preprocessing": {
#                     "resize_if_needed": True,
#                     "max_dimension": 2048,
#                     "enhance_contrast": True
#                 }
#             }
#         }

#         # Step 8: Run the complete pipeline synchronously and wait for completion
#         logger.info(f"Starting synchronous pipeline processing for project {project.id}")
        
#         pipeline_result = run_complete_pipeline_sync(
#             project_id=project.id,
#             image_path=saved_path,
#             config=processing_config
#         )
        
#         logger.info(f"Pipeline completed for project {project.id}")

#         # Step 9: Get the updated project and session information WITHIN THE SESSION CONTEXT
#         with db_manager.get_session() as db_session:
#             from repositories import ProcessingSessionRepository
#             session_repo = ProcessingSessionRepository(db_session)
#             project_repo_new = ProjectRepository(db_session)
            
#             updated_project = project_repo_new.get_by_id(project.id)
#             latest_session = session_repo.get_latest_for_project(project.id)

#             # Extract all needed data WHILE INSIDE THE SESSION CONTEXT
#             session_data = None
#             if latest_session:
#                 session_data = {
#                     "id": latest_session.id,
#                     "export_file_path": latest_session.export_file_path,
#                     "export_format_version": latest_session.export_format_version,
#                     "status": latest_session.status.value if latest_session.status else None
#                 }
            
#             project_status = updated_project.status.value if updated_project and updated_project.status else "unknown"

#         # Step 10: Prepare download information USING EXTRACTED DATA
#         download_info = None
#         if session_data and session_data["export_file_path"] and os.path.exists(session_data["export_file_path"]):
#             file_size_bytes = os.path.getsize(session_data["export_file_path"])
#             download_info = {
#                 "available": True,
#                 "file_path": session_data["export_file_path"],
#                 "file_size_bytes": file_size_bytes,
#                 "file_size_mb": round(file_size_bytes / (1024 * 1024), 2),
#                 "format_version": session_data["export_format_version"],
#                 "filename": f"session_{session_data['id']}_final.json"
#             }
#         else:
#             download_info = {
#                 "available": False,
#                 "message": "Export file not available"
#             }

#         # Return complete response with all information
#         return {
#             "message": "Project created and processing completed successfully.",
#             "project_id": project.id,
#             "project_name": project.name,
#             "status": project_status,
#             "session_id": session_data["id"] if session_data else None,
#             "processing_result": {
#                 "success": pipeline_result["success"],
#                 "stages_completed": pipeline_result.get("stages_completed", 0),
#                 "processing_time_seconds": pipeline_result.get("processing_time_seconds", 0),
#                 "error_message": pipeline_result.get("error_message") if not pipeline_result["success"] else None
#             },
#             "download": download_info,
#             "image_info": {
#                 "width": file_info['image_width'],
#                 "height": file_info['image_height'],
#                 "format": file_info['image_format'],
#                 "size_mb": round(file_info['file_size_bytes'] / (1024 * 1024), 2),
#                 "resolution_dpi": additional_metadata.get('image_resolution_dpi', 72),
#                 "aspect_ratio": file_info['aspect_ratio']
#             }
#         }

#     except ImageValidationError as e:
#         logger.error(f"Image validation error: {e}")
#         raise HTTPException(status_code=400, detail=str(e))
#     except HTTPException:
#         raise
#     except Exception as e:
#         logger.error(f"Failed to create project or process pipeline: {e}", exc_info=True)
#         if 'saved_path' in locals() and os.path.exists(saved_path):
#             try:
#                 os.remove(saved_path)
#                 logger.info(f"Cleaned up uploaded file: {saved_path}")
#             except:
#                 pass
#         raise HTTPException(status_code=500, detail=f"Project creation or processing failed: {str(e)}")





from api_exports import create_2layer_json_structure
from repositories import JSONStageRepository

@router.post("/projects", response_model=Dict[str, Any])
def create_project(
    name: str = Form(...),
    description: str = Form(None),
    image_file: UploadFile = File(...),
    model: str = Form("yolo"),  # Model selection flag
    db: Session = Depends(get_db)
):
    """
    Create a new project with a floorplan image and run the complete processing pipeline.
    Returns response only after the entire pipeline is completed with download path
    and the final 2-layer JSON.
    """
    project_repo = ProjectRepository(db)

    try:
        # Step 1: Validate uploaded image
        logger.info(f"Validating uploaded image: {image_file.filename}")
        validation_result = validate_image_file(image_file)
        if not validation_result['is_valid']:
            raise HTTPException(status_code=400, detail=f"Image validation failed: {validation_result['error_message']}")

        file_info = validation_result['file_info']
        logger.info(f"Image validation successful: {file_info['image_width']}x{file_info['image_height']}")

        # Step 2: Save uploaded file
        safe_filename = generate_safe_filename(image_file.filename, name)
        file_location = os.path.join(UPLOAD_DIRECTORY, safe_filename)
        saved_path = save_uploaded_file(image_file, file_location)
        logger.info(f"Image saved to: {saved_path}")

        # Step 3: Extract metadata
        additional_metadata = extract_image_metadata(saved_path)

        # Step 4: Validate for AI processing
        if not validate_file_for_processing(saved_path):
            logger.warning("Image may not be optimal for AI processing, but proceeding...")

        # Step 5: Map model string to flags
        model = model.lower()
        if model == "yolo":
            ai_model_flags = {"maskrcnn": False, "yolo": True, "both": False}
        elif model == "maskrcnn":
            ai_model_flags = {"maskrcnn": True, "yolo": False, "both": False}
        elif model == "both":
            ai_model_flags = {"maskrcnn": False, "yolo": False, "both": True}
        else:
            raise HTTPException(status_code=400, detail="Invalid model. Choose from 'maskrcnn', 'yolo', or 'both'.")

        # Step 6: Create project
        project = project_repo.create(
            name=name,
            description=description,
            original_image_path=saved_path,
            image_width=file_info['image_width'],
            image_height=file_info['image_height'],
            image_resolution_dpi=additional_metadata.get('image_resolution_dpi', 72),
            image_size_bytes=file_info['file_size_bytes'],
            image_format=ImageFormat(file_info['image_format']),
            image_color_mode=file_info['image_mode'],
            image_has_transparency=file_info['has_transparency'],
            image_aspect_ratio=file_info['aspect_ratio'],
            image_dimensions={
                "width": file_info['image_width'],
                "height": file_info['image_height'],
                "resolution": additional_metadata.get('image_resolution_dpi', 72),
                "file_size_mb": round(file_info['file_size_bytes'] / (1024 * 1024), 2),
                "format": file_info['image_format'],
                "color_mode": file_info['image_mode'],
                "has_transparency": file_info['has_transparency'],
                "aspect_ratio": file_info['aspect_ratio']
            }
        )
        logger.info(f"Project '{name}' (ID: {project.id}) created.")

        # Step 7: Processing config
        processing_config = {
            "ai_model_flags": ai_model_flags,
            "processing_config": {
                "confidence_threshold": 0.7,
                "refinement_levels": 4,
                "optimization_enabled": True,
                "image_preprocessing": {
                    "resize_if_needed": True,
                    "max_dimension": 2048,
                    "enhance_contrast": True
                }
            }
        }

        # Step 8: Run pipeline synchronously
        logger.info(f"Starting synchronous pipeline processing for project {project.id}")
        pipeline_result = run_complete_pipeline_sync(
            project_id=project.id,
            image_path=saved_path,
            config=processing_config
        )
        logger.info(f"Pipeline completed for project {project.id}")

        # Step 9: Fetch updated project + session
        with db_manager.get_session() as db_session:
            from repositories import ProcessingSessionRepository
            session_repo = ProcessingSessionRepository(db_session)
            project_repo_new = ProjectRepository(db_session)
            json_stage_repo = JSONStageRepository(db_session)

            updated_project = project_repo_new.get_by_id(project.id)
            latest_session = session_repo.get_latest_for_project(project.id)

            session_data = None
            final_json = None
            if latest_session:
                session_data = {
                    "id": latest_session.id,
                    "export_file_path": latest_session.export_file_path,
                    "export_format_version": latest_session.export_format_version,
                    "status": latest_session.status.value if latest_session.status else None
                }

                # Fetch Stage 4 JSON and convert to 2-layer
                stage4_data = json_stage_repo.get_by_session_and_stage(latest_session.id, 4)
                if stage4_data and stage4_data.output_json:
                    try:
                        final_json = create_2layer_json_structure(stage4_data.output_json, latest_session.id)
                    except Exception as e:
                        logger.warning(f"Could not generate final JSON for session {latest_session.id}: {e}")

            project_status = updated_project.status.value if updated_project and updated_project.status else "unknown"

        # Step 10: Prepare download info
        download_info = None
        if session_data and session_data["export_file_path"] and os.path.exists(session_data["export_file_path"]):
            file_size_bytes = os.path.getsize(session_data["export_file_path"])
            download_info = {
                "available": True,
                "file_path": session_data["export_file_path"],
                "file_size_bytes": file_size_bytes,
                "file_size_mb": round(file_size_bytes / (1024 * 1024), 2),
                "format_version": session_data["export_format_version"],
                "filename": f"session_{session_data['id']}_final.json"
            }
        else:
            download_info = {
                "available": False,
                "message": "Export file not available"
            }

        # Final response
        return {
            "message": "Project created and processing completed successfully.",
            "project_id": project.id,
            "project_name": project.name,
            "status": project_status,
            "session_id": session_data["id"] if session_data else None,
            "final_json": final_json,  # ✅ Added here
            "processing_result": {
                "success": pipeline_result["success"],
                "stages_completed": pipeline_result.get("stages_completed", 0),
                "processing_time_seconds": pipeline_result.get("processing_time_seconds", 0),
                "error_message": pipeline_result.get("error_message") if not pipeline_result["success"] else None
            },
            "download": download_info,
            "image_info": {
                "width": file_info['image_width'],
                "height": file_info['image_height'],
                "format": file_info['image_format'],
                "size_mb": round(file_info['file_size_bytes'] / (1024 * 1024), 2),
                "resolution_dpi": additional_metadata.get('image_resolution_dpi', 72),
                "aspect_ratio": file_info['aspect_ratio']
            }
        }

    except ImageValidationError as e:
        logger.error(f"Image validation error: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to create project or process pipeline: {e}", exc_info=True)
        if 'saved_path' in locals() and os.path.exists(saved_path):
            try:
                os.remove(saved_path)
                logger.info(f"Cleaned up uploaded file: {saved_path}")
            except:
                pass
        raise HTTPException(status_code=500, detail=f"Project creation or processing failed: {str(e)}")


# @router.post("/projects", response_model=Dict[str, Any])
# def create_project(
#     name: str = Form(...),
#     description: str = Form(None),
#     image_file: UploadFile = File(...),
#     model: str = Form("yolo"),
#     db: Session = Depends(get_db)
# ):
#     """
#     Create a new project with a floorplan image and run the complete processing pipeline.
#     Returns response only after the entire pipeline is completed with download path.
#     """
#     project_repo = ProjectRepository(db)

#     try:
#         # 1. Validate image
#         logger.info(f"Validating uploaded image: {image_file.filename}")
#         validation_result = validate_image_file(image_file)
#         if not validation_result['is_valid']:
#             raise HTTPException(status_code=400, detail=f"Image validation failed: {validation_result['error_message']}")

#         file_info = validation_result['file_info']
#         logger.info(f"Image validation successful: {file_info['image_width']}x{file_info['image_height']}")

#         # 2. Save uploaded file
#         safe_filename = generate_safe_filename(image_file.filename, name)
#         file_location = os.path.join(UPLOAD_DIRECTORY, safe_filename)
#         saved_path = save_uploaded_file(image_file, file_location)
#         logger.info(f"Image saved to: {saved_path}")

#         # 3. Extract metadata
#         additional_metadata = extract_image_metadata(saved_path)

#         # 4. Validate for AI processing
#         if not validate_file_for_processing(saved_path):
#             logger.warning("Image may not be optimal for AI processing, but proceeding...")

#         # 5. AI model flags
#         model = model.lower()
#         if model == "yolo":
#             ai_model_flags = {"maskrcnn": False, "yolo": True, "both": False}
#         elif model == "maskrcnn":
#             ai_model_flags = {"maskrcnn": True, "yolo": False, "both": False}
#         elif model == "both":
#             ai_model_flags = {"maskrcnn": False, "yolo": False, "both": True}
#         else:
#             raise HTTPException(status_code=400, detail="Invalid model. Choose from 'maskrcnn', 'yolo', or 'both'.")

#         # 6. Create project
#         project = project_repo.create(
#             name=name,
#             description=description,
#             original_image_path=saved_path,
#             image_width=file_info['image_width'],
#             image_height=file_info['image_height'],
#             image_resolution_dpi=additional_metadata.get('image_resolution_dpi', 72),
#             image_size_bytes=file_info['file_size_bytes'],
#             image_format=ImageFormat(file_info['image_format']),
#             image_color_mode=file_info['image_mode'],
#             image_has_transparency=file_info['has_transparency'],
#             image_aspect_ratio=file_info['aspect_ratio'],
#             image_dimensions={
#                 "width": file_info['image_width'],
#                 "height": file_info['image_height'],
#                 "resolution": additional_metadata.get('image_resolution_dpi', 72),
#                 "file_size_mb": round(file_info['file_size_bytes'] / (1024 * 1024), 2),
#                 "format": file_info['image_format'],
#                 "color_mode": file_info['image_mode'],
#                 "has_transparency": file_info['has_transparency'],
#                 "aspect_ratio": file_info['aspect_ratio']
#             }
#         )

#         logger.info(f"Project '{name}' (ID: {project.id}) created.")

#         # 7. Create session BEFORE pipeline so we know session_id
#         from repositories import ProcessingSessionRepository
#         from models import SessionStatus
#         session_repo = ProcessingSessionRepository(db)

#         session = session_repo.create(
#             project_id=project.id,
#             ai_model_flags=ai_model_flags
#         )
#         db.commit()  # Commit so session ID is generated

#         # Define export file path using session_id format
#         export_dir = os.getenv("EXPORT_PATH", "./exports")
#         os.makedirs(export_dir, exist_ok=True)
#         export_file_path = os.path.join(export_dir, f"session_{session.id}_final.json")

#         # 8. Run pipeline with the export_file_path
#         processing_config = {
#             "ai_model_flags": ai_model_flags,
#             "processing_config": {
#                 "confidence_threshold": 0.7,
#                 "refinement_levels": 4,
#                 "optimization_enabled": True,
#                 "image_preprocessing": {
#                     "resize_if_needed": True,
#                     "max_dimension": 2048,
#                     "enhance_contrast": True
#                 },
#                 "export_file_path": export_file_path  # Pass to pipeline
#             }
#         }

#         logger.info(f"Starting pipeline for project {project.id}, session {session.id}")
#         pipeline_result = run_complete_pipeline_sync(
#             project_id=project.id,
#             image_path=saved_path,
#             config=processing_config
#         )
#         logger.info(f"Pipeline completed for session {session.id}")

#         # 9. Update session with export path
#         session.status = SessionStatus.COMPLETED
#         session.export_file_path = export_file_path
#         session.export_format_version = "1.0"
#         db.commit()

#         # 10. Download info
#         download_info = None
#         if os.path.exists(export_file_path):
#             file_size_bytes = os.path.getsize(export_file_path)
#             download_info = {
#                 "available": True,
#                 "file_path": export_file_path,
#                 "file_size_bytes": file_size_bytes,
#                 "file_size_mb": round(file_size_bytes / (1024 * 1024), 2),
#                 "format_version": "1.0",
#                 "filename": f"session_{session.id}_final.json"
#             }
#         else:
#             download_info = {"available": False, "message": "Export file not available"}

#         return {
#             "message": "Project created and processing completed successfully.",
#             "project_id": project.id,
#             "project_name": project.name,
#             "status": project.status.value if project.status else "unknown",
#             "session_id": session.id,
#             "processing_result": {
#                 "success": pipeline_result["success"],
#                 "stages_completed": pipeline_result.get("stages_completed", 0),
#                 "processing_time_seconds": pipeline_result.get("processing_time_seconds", 0),
#                 "error_message": pipeline_result.get("error_message") if not pipeline_result["success"] else None
#             },
#             "download": download_info,
#             "image_info": {
#                 "width": file_info['image_width'],
#                 "height": file_info['image_height'],
#                 "format": file_info['image_format'],
#                 "size_mb": round(file_info['file_size_bytes'] / (1024 * 1024), 2),
#                 "resolution_dpi": additional_metadata.get('image_resolution_dpi', 72),
#                 "aspect_ratio": file_info['aspect_ratio']
#             }
#         }

#     except ImageValidationError as e:
#         logger.error(f"Image validation error: {e}")
#         raise HTTPException(status_code=400, detail=str(e))
#     except HTTPException:
#         raise
#     except Exception as e:
#         db.rollback()
#         logger.error(f"Failed to create project or process pipeline: {e}", exc_info=True)
#         if 'saved_path' in locals() and os.path.exists(saved_path):
#             try:
#                 os.remove(saved_path)
#                 logger.info(f"Cleaned up uploaded file: {saved_path}")
#             except:
#                 pass
#         raise HTTPException(status_code=500, detail=f"Project creation or processing failed: {str(e)}")


@router.get("/projects/{project_id}/download")
def download_project_result(project_id: int, db: Session = Depends(get_db)):
    """
    Download the final processed result file for a project.
    """
    from fastapi.responses import FileResponse
    
    try:
        project_repo = ProjectRepository(db)
        project = project_repo.get_by_id(project_id)
        
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")
        
        # Get the latest completed session
        from repositories import ProcessingSessionRepository
        session_repo = ProcessingSessionRepository(db)
        latest_session = session_repo.get_latest_for_project(project_id)
        
        if not latest_session:
            raise HTTPException(status_code=404, detail="No processing session found for this project")
        
        if latest_session.status != SessionStatus.COMPLETED:
            raise HTTPException(status_code=400, detail=f"Processing not completed. Current status: {latest_session.status.value}")
        
        if not latest_session.export_file_path or not os.path.exists(latest_session.export_file_path):
            raise HTTPException(status_code=404, detail="Export file not found")
        
        filename = f"{project.name}_session_{latest_session.id}_final.json"
        
        return FileResponse(
            path=latest_session.export_file_path,
            filename=filename,
            media_type='application/json'
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading file for project {project_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Download failed: {str(e)}")


@router.get("/projects/{project_id}", response_model=Dict[str, Any])
def get_project_details(project_id: int, db: Session = Depends(get_db)):
    """
    Get details for a specific project, including all its processing sessions
    and enhanced image metadata.
    """
    project = ProjectRepository(db).get_by_id(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    sessions = [
        {
            "session_id": s.id,
            "session_uuid": s.session_uuid,
            "status": s.status.value,
            "created_at": s.created_at,
            "export_available": bool(s.export_file_path and os.path.exists(s.export_file_path))
        } for s in project.processing_sessions
    ]

    return {
        "id": project.id,
        "name": project.name,
        "description": project.description,
        "status": project.status.value,
        "created_at": project.created_at,
        "original_image_path": project.original_image_path,
        "export_file_path": (
                    project.processing_sessions[0].export_file_path 
                    if project.processing_sessions and project.processing_sessions[0].export_file_path 
                    else None),
        
        # Enhanced image metadata
        "image_metadata": {
            "width": project.image_width,
            "height": project.image_height,
            "resolution_dpi": project.image_resolution_dpi,
            "size_bytes": project.image_size_bytes,
            "size_mb": round(project.image_size_bytes / (1024 * 1024), 2) if project.image_size_bytes else None,
            "format": project.image_format.value if project.image_format else None,
            "color_mode": project.image_color_mode,
            "has_transparency": project.image_has_transparency,
            "aspect_ratio": project.image_aspect_ratio
        },
        
        # Legacy dimensions for backward compatibility
        "image_dimensions": project.image_dimensions,
        
        "processing_sessions": sessions
    }

@router.delete("/projects/{project_id}", response_model=Dict[str, str])
def delete_project(project_id: int, db: Session = Depends(get_db)):
    """
    Delete a project and all its associated data (sessions, models, etc.).
    """
    project_repo = ProjectRepository(db)
    project = project_repo.get_by_id(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    # Clean up the image file
    if project.original_image_path and os.path.exists(project.original_image_path):
        try:
            os.remove(project.original_image_path)
            logger.info(f"Deleted image file: {project.original_image_path}")
        except Exception as e:
            logger.warning(f"Failed to delete image file: {e}")

    # Clean up export files from sessions
    for session in project.processing_sessions:
        if session.export_file_path and os.path.exists(session.export_file_path):
            try:
                os.remove(session.export_file_path)
                logger.info(f"Deleted export file: {session.export_file_path}")
            except Exception as e:
                logger.warning(f"Failed to delete export file: {e}")

    if project_repo.delete(project_id):
        return {"message": f"Project {project_id} and all associated data deleted successfully."}
    else:
        raise HTTPException(status_code=500, detail="Failed to delete project.")

@router.get("/projects", response_model=List[Dict[str, Any]])
def get_all_projects(
    status: str = None,
    limit: int = 50,
    offset: int = 0,
    db: Session = Depends(get_db)
):
    """
    Get all projects with optional filtering and pagination.
    """
    try:
        project_repo = ProjectRepository(db)
        
        # Convert status string to enum if provided
        status_filter = None
        if status:
            try:
                status_filter = ProjectStatus(status.lower())
            except ValueError:
                raise HTTPException(
                    status_code=400, 
                    detail=f"Invalid status. Valid options: {[s.value for s in ProjectStatus]}"
                )
        
        projects = project_repo.get_all(status=status_filter, limit=limit, offset=offset)

        return [
            {
                "id": project.id,
                "name": project.name,
                "description": project.description,
                "status": project.status.value,
                "created_at": project.created_at,
                "original_image_path": project.original_image_path,
                "export_file_path": (
                    project.processing_sessions[0].export_file_path 
                    if project.processing_sessions and project.processing_sessions[0].export_file_path 
                    else None
                ),
                "image_metadata": {
                    "width": project.image_width,
                    "height": project.image_height,
                    "format": project.image_format.value if project.image_format else None,
                    "size_mb": round(project.image_size_bytes / (1024 * 1024), 2) if project.image_size_bytes else None,
                },
                "session_count": len(project.processing_sessions),
                "latest_session_status": project.processing_sessions[0].status.value if project.processing_sessions else None
            } for project in projects
        ]
        
    except Exception as e:
        logger.error(f"Failed to get projects: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to retrieve projects")
    
@router.post("/projects/validate-image")
def validate_image_endpoint(image_file: UploadFile = File(...)):
    """
    Endpoint to validate an image file without creating a project.
    Useful for frontend validation before project creation.
    """
    try:
        validation_result = validate_image_file(image_file)
        
        if validation_result['is_valid']:
            return {
                "valid": True,
                "message": "Image is valid for processing",
                "image_info": validation_result['file_info']
            }
        else:
            return {
                "valid": False,
                "message": validation_result['error_message'],
                "image_info": validation_result.get('file_info', {})
            }
            
    except Exception as e:
        logger.error(f"Image validation endpoint error: {e}")
        return {
            "valid": False,
            "message": f"Validation error: {str(e)}",
            "image_info": {}
        }
    

@router.post("/update/project-json/{project_id}", response_model=Dict[str, Any])
def update_project_json(
    project_id: int,
    floorplan: dict = Body(...),
    db: Session = Depends(get_db)
):
    """
    Update project floorplan JSON using project ID without validating structure.
    Updates both database record and the export file.
    """
    try:
        project_repo = ProjectRepository(db)
        project = project_repo.get_by_id(project_id)
        
        if not project:
            raise HTTPException(status_code=404, detail="Project with given ID not found")
        
        # Get the latest processing session
        from repositories import ProcessingSessionRepository
        session_repo = ProcessingSessionRepository(db)
        latest_session = session_repo.get_latest_for_project(project_id)
        
        if not latest_session:
            raise HTTPException(status_code=404, detail="No processing session found for this project")
        
        # Check if export file exists
        export_path = latest_session.export_file_path
        if not export_path or not os.path.exists(export_path):
            raise HTTPException(status_code=404, detail="Export file path invalid or file missing")
        
        # Update the session with new floorplan data
        # Note: You'll need to add a floorplan_json field to your ProcessingSession model if it doesn't exist
        latest_session.floorplan_json = json.dumps(floorplan, ensure_ascii=False)
        
        # Save to file
        with open(export_path, 'w', encoding='utf-8') as f:
            json.dump(floorplan, f, ensure_ascii=False, indent=2)
        
        db.commit()
        
        logger.info(f"Floorplan JSON updated for project {project_id}")
        
        return {
            "success": True,
            "message": f"✅ Floorplan updated for project {project_id}",
            "project_id": project_id,
            "project_name": project.name,
            "updated_file": export_path,
            "file_size_bytes": os.path.getsize(export_path) if os.path.exists(export_path) else 0
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to update project JSON for project {project_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"❌ Failed to update: {str(e)}")


@router.post("/create-project-from-scratch", response_model=Dict[str, Any])
def create_project_from_scratch(
    request: CreateProjectFromScratchRequest,
    db: Session = Depends(get_db)
):
    """
    Creates a new project record from scratch with initial floorplan JSON.
    This creates a minimal project without image processing but with a default thumbnail.
    """
    try:
        project_repo = ProjectRepository(db)
        
        # Setup default thumbnail
        default_thumbnail_path = setup_default_thumbnail()
        default_image_info = get_default_image_info()
        
        # Create project with default image as thumbnail
        project = project_repo.create(
            name=request.project_name,
            description=request.description,
            # Use default thumbnail image
            original_image_path=default_thumbnail_path,
            image_width=default_image_info['width'],
            image_height=default_image_info['height'],
            image_resolution_dpi=default_image_info['dpi'],
            image_size_bytes=default_image_info['size_bytes'],
            image_format=default_image_info['format'],
            image_color_mode=default_image_info['color_mode'],
            image_has_transparency=default_image_info['has_transparency'],
            image_aspect_ratio=default_image_info['aspect_ratio'],
            image_dimensions={
                "width": default_image_info['width'],
                "height": default_image_info['height'],
                "resolution": default_image_info['dpi'],
                "file_size_mb": default_image_info['size_mb'],
                "format": default_image_info['format'].value,
                "color_mode": default_image_info['color_mode'],
                "has_transparency": default_image_info['has_transparency'],
                "aspect_ratio": default_image_info['aspect_ratio'],
                "source": "default_thumbnail"
            }
        )
        
        logger.info(f"Project '{request.project_name}' (ID: {project.id}) created from scratch")
        
        # Create a processing session for this project
        from repositories import ProcessingSessionRepository
        from models import SessionStatus
        import uuid
        
        session_repo = ProcessingSessionRepository(db)
        
        # Define output directory and filename
        output_dir = os.getenv("EXPORT_PATH", "./exports")
        os.makedirs(output_dir, exist_ok=True)
        
        filename = f"session_{project.id}_final.json"
        json_path = os.path.join(output_dir, filename)
        
        # Save the initial floorplan JSON to file
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(request.floorplan, f, ensure_ascii=False, indent=2)
        
        # Create processing session record
        # Your repository requires ai_model_flags parameter
        ai_model_flags = {
            "maskrcnn": False,
            "yolo": False,
            "both": False,
            "from_scratch": True  # Custom flag to indicate this was created from scratch
        }
        
        session = session_repo.create(
            project_id=project.id,
            ai_model_flags=ai_model_flags
        )
        
        # Set additional fields after creation
        if hasattr(session, 'status'):
            session.status = SessionStatus.COMPLETED
        if hasattr(session, 'export_file_path'):
            session.export_file_path = json_path
        if hasattr(session, 'export_format_version'):
            session.export_format_version = "1.0"
        
        # Update session with floorplan data if your model supports it
        if hasattr(session, 'floorplan_json'):
            session.floorplan_json = json.dumps(request.floorplan, ensure_ascii=False)
        
        # Update project status to completed
        project.status = ProjectStatus.COMPLETED
        
        db.commit()
        
        # Prepare file info
        file_size_bytes = os.path.getsize(json_path)
        
        return {
            "success": True,
            "message": f"✅ Project created from scratch successfully",
            "project_id": project.id,
            "project_name": project.name,
            "session_id": session.id,
            "status": project.status.value,
            "export_file": {
                "path": json_path,
                "filename": filename,
                "size_bytes": file_size_bytes,
                "size_mb": round(file_size_bytes / (1024 * 1024), 4)
            },
            "download": {
                "available": True,
                "file_path": json_path,
                "file_size_bytes": file_size_bytes,
                "file_size_mb": round(file_size_bytes / (1024 * 1024), 4),
                "format_version": "1.0",
                "filename": filename
            }
        }
        
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to create project from scratch: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"❌ Failed to create project: {str(e)}")

    
# Alternative update endpoint that works with session ID directly
@router.post("/update/session-json/{session_id}", response_model=Dict[str, Any])
def update_session_json(
    session_id: int,
    floorplan: dict = Body(...),
    db: Session = Depends(get_db)
):
    """
    Update floorplan JSON using session ID directly.
    This provides more direct access to the specific processing session.
    """
    try:
        from repositories import ProcessingSessionRepository
        session_repo = ProcessingSessionRepository(db)
        
        session = session_repo.get_by_id(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Processing session not found")
        
        # Check if export file exists
        export_path = session.export_file_path
        if not export_path or not os.path.exists(export_path):
            raise HTTPException(status_code=404, detail="Export file path invalid or file missing")
        
        # Update session with new floorplan data
        if hasattr(session, 'floorplan_json'):
            session.floorplan_json = json.dumps(floorplan, ensure_ascii=False)
        
        # Save to file
        with open(export_path, 'w', encoding='utf-8') as f:
            json.dump(floorplan, f, ensure_ascii=False, indent=2)
        
        db.commit()
        
        logger.info(f"Floorplan JSON updated for session {session_id}")
        
        return {
            "success": True,
            "message": f"✅ Floorplan updated for session {session_id}",
            "session_id": session_id,
            "project_id": session.project_id,
            "updated_file": export_path,
            "file_size_bytes": os.path.getsize(export_path) if os.path.exists(export_path) else 0
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to update session JSON for session {session_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"❌ Failed to update: {str(e)}")

