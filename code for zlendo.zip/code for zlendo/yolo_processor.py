# import os
# import time
# import logging
# from typing import Dict, List, Any
# import torch
# import numpy as np
# from PIL import Image
# import cv2
# from ultralytics import YOLO

# logger = logging.getLogger(__name__)


# class YOLOProcessor:
#     """Custom YOLOv8 Processor using PyTorch only"""

#     def __init__(self):
#         self.model = None
#         self.model_loaded = False
#         self.weights_folder = "./weights"
#         self.weights_file_name = "best.pt"
#         self.confidence_threshold = 0.25
#         self.iou_threshold = 0.45

#         self.class_mapping = {
#             0: 'Wall',
#             1: 'Window',
#             2: 'Door',
#         }

#     def is_available(self) -> bool:
#         weights_path = os.path.join(self.weights_folder, self.weights_file_name)
#         return os.path.exists(weights_path)

    

#     def load_model(self) -> bool:
#         try:
#             weights_path = os.path.join(self.weights_folder, self.weights_file_name)
#             if not os.path.exists(weights_path):
#                 logger.error(f"YOLO weights not found at {weights_path}")
#                 return False

#             self.model = YOLO(weights_path)  # uses ultralytics
#             self.model_loaded = True
#             logger.info("Ultralytics YOLOv8 model loaded successfully.")
#             return True

#         except Exception as e:
#             logger.error(f"Failed to load YOLOv8 model: {e}")
#             self.model_loaded = False
#             return False

#     def process_image(self, image_path: str) -> Dict[str, Any]:
#         if not self.model_loaded:
#             raise RuntimeError("YOLOv8 model not loaded")

#         try:
#             results = self.model(image_path)[0]  # Use first result in batch

#             boxes = results.boxes.xyxy.cpu().numpy()  # [x1, y1, x2, y2]
#             confs = results.boxes.conf.cpu().numpy()
#             classes = results.boxes.cls.cpu().numpy().astype(int)

#             return {
#                 'points': self._boxes_to_points(boxes),
#                 'classes': self._classes_with_confidence(classes, confs),
#                 'Width': results.orig_shape[1],
#                 'Height': results.orig_shape[0],
#                 'averageDoor': self._calculate_avg_door_size(boxes, classes),
#                 'detection_count': len(boxes),
#                 'confidence_scores': [float(score) for score in confs],
#                 'model_info': {
#                     "name": "YOLOv8",
#                     "version": "custom",
#                     "classes": list(self.class_mapping.values())
#                 }
#             }

#         except Exception as e:
#             logger.error(f"Error processing image with YOLO: {e}")
#             raise


#     def _load_image(self, image_path: str) -> np.ndarray:
#         image = cv2.imread(image_path)
#         if image is None:
#             pil_image = Image.open(image_path)
#             image = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
#         return image

#     def _postprocess(self, outputs, scale_x, scale_y):
#         boxes, scores, classes = [], [], []

#         for output in outputs:
#             if output[4] < self.confidence_threshold:
#                 continue

#             x1, y1, x2, y2 = output[0:4]
#             x1 *= scale_x
#             x2 *= scale_x
#             y1 *= scale_y
#             y2 *= scale_y

#             boxes.append([x1.item(), y1.item(), x2.item(), y2.item()])
#             scores.append(output[4].item())
#             classes.append(int(output[5].item()))

#         return boxes, scores, classes

#     def _boxes_to_points(self, boxes: List[List[float]]) -> List[Dict[str, float]]:
#         return [{'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2} for x1, y1, x2, y2 in boxes]

#     def _classes_with_confidence(self, class_ids: List[int], scores: List[float]) -> List[Dict[str, Any]]:
#         result = []
#         for cid, score in zip(class_ids, scores):
#             result.append({
#                 'name': self.class_mapping.get(cid, f'class_{cid}'),
#                 'confidence': round(score * 100, 2)
#             })
#         return result

#     def _calculate_avg_door_size(self, boxes: List[List[float]], class_ids: List[int]) -> float:
#         door_sizes = [
#             max(abs(x2 - x1), abs(y2 - y1))
#             for (x1, y1, x2, y2), cid in zip(boxes, class_ids) if cid == 2
#         ]
#         return sum(door_sizes) / len(door_sizes) if door_sizes else 0




import os
import time
import logging
from typing import Dict, List, Any
import torch
import numpy as np
from PIL import Image
import cv2
from ultralytics import YOLO

logger = logging.getLogger(__name__)


class YOLOProcessor:
    """Custom YOLOv8 Processor using PyTorch only"""

    def __init__(self):
        self.model = None
        self.model_loaded = False
        self.weights_folder = "./weights"
        self.weights_file_name = "best.pt"
        self.confidence_threshold = 0.25
        self.iou_threshold = 0.45

        # Updated class mapping with new 22-class system
        self.class_mapping = {
            0: 'AC',
            1: 'Balcony',
            2: 'Bathtub',
            3: 'Bed',
            4: 'Cabinet',
            5: 'Chair',
            6: 'Cupboard',
            7: 'Dining',
            8: 'Window',
            9: 'Flower_Pot',
            10: 'Fridge',
            11: 'Indian_T',
            12: 'Sink',
            13: 'Sofa',
            14: 'Steps',
            15: 'Stove',
            16: 'TV',
            17: 'Table',
            18: 'W_Machine',
            19: 'Wall',
            20: 'Western_T',
            21: 'Door'
        }
        
        # Define door class IDs for average door size calculation
        # Assuming 'Door' is still the primary door class
        self.door_class_ids = [21]  # Door class ID
        
        # Define wall class IDs for wall-specific processing
        self.wall_class_ids = [19]  # Wall class ID
        
        # Define window class IDs for window-specific processing
        self.window_class_ids = [8]  # Window class ID

    def is_available(self) -> bool:
        weights_path = os.path.join(self.weights_folder, self.weights_file_name)
        return os.path.exists(weights_path)

    def load_model(self) -> bool:
        try:
            weights_path = os.path.join(self.weights_folder, self.weights_file_name)
            if not os.path.exists(weights_path):
                logger.error(f"YOLO weights not found at {weights_path}")
                return False

            self.model = YOLO(weights_path)  # uses ultralytics
            self.model_loaded = True
            logger.info("Ultralytics YOLOv8 model loaded successfully.")
            return True

        except Exception as e:
            logger.error(f"Failed to load YOLOv8 model: {e}")
            self.model_loaded = False
            return False

    def process_image(self, image_path: str) -> Dict[str, Any]:
        if not self.model_loaded:
            raise RuntimeError("YOLOv8 model not loaded")

        try:
            results = self.model(image_path)[0]  # Use first result in batch

            boxes = results.boxes.xyxy.cpu().numpy()  # [x1, y1, x2, y2]
            confs = results.boxes.conf.cpu().numpy()
            classes = results.boxes.cls.cpu().numpy().astype(int)

            return {
                'points': self._boxes_to_points(boxes),
                'classes': self._classes_with_confidence(classes, confs),
                'Width': results.orig_shape[1],
                'Height': results.orig_shape[0],
                'averageDoor': self._calculate_avg_door_size(boxes, classes),
                'detection_count': len(boxes),
                'confidence_scores': [float(score) for score in confs],
                'detection_summary': self._get_detection_summary(classes),
                'architectural_elements': self._get_architectural_elements(boxes, classes),
                'furniture_items': self._get_furniture_items(boxes, classes),
                'model_info': {
                    "name": "YOLOv8",
                    "version": "custom",
                    "classes": list(self.class_mapping.values()),
                    "total_classes": len(self.class_mapping)
                }
            }

        except Exception as e:
            logger.error(f"Error processing image with YOLO: {e}")
            raise

    def _load_image(self, image_path: str) -> np.ndarray:
        image = cv2.imread(image_path)
        if image is None:
            pil_image = Image.open(image_path)
            image = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
        return image

    def _postprocess(self, outputs, scale_x, scale_y):
        boxes, scores, classes = [], [], []

        for output in outputs:
            if output[4] < self.confidence_threshold:
                continue

            x1, y1, x2, y2 = output[0:4]
            x1 *= scale_x
            x2 *= scale_x
            y1 *= scale_y
            y2 *= scale_y

            boxes.append([x1.item(), y1.item(), x2.item(), y2.item()])
            scores.append(output[4].item())
            classes.append(int(output[5].item()))

        return boxes, scores, classes

    def _boxes_to_points(self, boxes: List[List[float]]) -> List[Dict[str, float]]:
        return [{'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2} for x1, y1, x2, y2 in boxes]

    def _classes_with_confidence(self, class_ids: List[int], scores: List[float]) -> List[Dict[str, Any]]:
        result = []
        for cid, score in zip(class_ids, scores):
            result.append({
                'name': self.class_mapping.get(cid, f'class_{cid}'),
                'class_id': cid,
                'confidence': round(score * 100, 2)
            })
        return result

    def _calculate_avg_door_size(self, boxes: List[List[float]], class_ids: List[int]) -> float:
        door_sizes = [
            max(abs(x2 - x1), abs(y2 - y1))
            for (x1, y1, x2, y2), cid in zip(boxes, class_ids) 
            if cid in self.door_class_ids
        ]
        return sum(door_sizes) / len(door_sizes) if door_sizes else 0

    def _get_detection_summary(self, class_ids: List[int]) -> Dict[str, int]:
        """Get count summary of detected classes"""
        summary = {}
        for class_id in class_ids:
            class_name = self.class_mapping.get(class_id, f'class_{class_id}')
            summary[class_name] = summary.get(class_name, 0) + 1
        return summary

    def _get_architectural_elements(self, boxes: List[List[float]], class_ids: List[int]) -> List[Dict[str, Any]]:
        """Extract architectural elements (walls, doors, windows, etc.)"""
        architectural_classes = [1, 8, 14, 19, 21]  # Balcony, Door, Steps, Wall, Window
        elements = []
        
        for i, class_id in enumerate(class_ids):
            if class_id in architectural_classes:
                x1, y1, x2, y2 = boxes[i]
                elements.append({
                    'type': self.class_mapping[class_id],
                    'class_id': class_id,
                    'bbox': {'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2},
                    'area': (x2 - x1) * (y2 - y1),
                    'center': {'x': (x1 + x2) / 2, 'y': (y1 + y2) / 2}
                })
        
        return elements

    def _get_furniture_items(self, boxes: List[List[float]], class_ids: List[int]) -> List[Dict[str, Any]]:
        """Extract furniture items"""
        furniture_classes = [0, 2, 3, 4, 5, 6, 7, 9, 10, 11, 12, 13, 15, 16, 17, 18, 20]  # All non-architectural classes
        items = []
        
        for i, class_id in enumerate(class_ids):
            if class_id in furniture_classes:
                x1, y1, x2, y2 = boxes[i]
                items.append({
                    'type': self.class_mapping[class_id],
                    'class_id': class_id,
                    'bbox': {'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2},
                    'area': (x2 - x1) * (y2 - y1),
                    'center': {'x': (x1 + x2) / 2, 'y': (y1 + y2) / 2}
                })
        
        return items

    def get_model_version(self) -> str:
        """Get model version info"""
        return "YOLOv8-custom-22classes"

    def get_supported_classes(self) -> List[str]:
        """Get list of supported class names"""
        return list(self.class_mapping.values())

    def get_class_id(self, class_name: str) -> int:
        """Get class ID by class name"""
        for class_id, name in self.class_mapping.items():
            if name.lower() == class_name.lower():
                return class_id
        return -1

    def filter_detections_by_confidence(self, detections: Dict[str, Any], min_confidence: float = 0.5) -> Dict[str, Any]:
        """Filter detections by minimum confidence threshold"""
        filtered_points = []
        filtered_classes = []
        filtered_scores = []
        
        for i, class_info in enumerate(detections['classes']):
            if class_info['confidence'] >= min_confidence * 100:  # confidence is stored as percentage
                filtered_points.append(detections['points'][i])
                filtered_classes.append(class_info)
                filtered_scores.append(detections['confidence_scores'][i])
        
        # Update the detection result
        filtered_detections = detections.copy()
        filtered_detections['points'] = filtered_points
        filtered_detections['classes'] = filtered_classes
        filtered_detections['confidence_scores'] = filtered_scores
        filtered_detections['detection_count'] = len(filtered_points)
        
        # Recalculate summaries with filtered data
        filtered_class_ids = [cls['class_id'] for cls in filtered_classes]
        filtered_detections['detection_summary'] = self._get_detection_summary(filtered_class_ids)
        
        return filtered_detections

    def get_detections_by_class(self, detections: Dict[str, Any], target_classes: List[str]) -> Dict[str, Any]:
        """Get detections filtered by specific class names"""
        target_class_ids = [self.get_class_id(cls) for cls in target_classes if self.get_class_id(cls) != -1]
        
        filtered_points = []
        filtered_classes = []
        filtered_scores = []
        
        for i, class_info in enumerate(detections['classes']):
            if class_info['class_id'] in target_class_ids:
                filtered_points.append(detections['points'][i])
                filtered_classes.append(class_info)
                filtered_scores.append(detections['confidence_scores'][i])
        
        return {
            'points': filtered_points,
            'classes': filtered_classes,
            'confidence_scores': filtered_scores,
            'detection_count': len(filtered_points)
        }