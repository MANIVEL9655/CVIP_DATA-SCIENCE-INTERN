# api_sessions.py

import logging
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Dict, Any

from database_manager import get_db
from repositories import ProcessingSessionRepository, JSONStageRepository

logger = logging.getLogger(__name__)
router = APIRouter()

@router.get("/sessions/{session_id}/status", response_model=Dict[str, Any])
def get_session_status(session_id: int, db: Session = Depends(get_db)):
    """
    Get the real-time processing status of a session.
    """
    session = ProcessingSessionRepository(db).get_by_id(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    return {
        "session_id": session.id,
        "status": session.status.value,
        "current_stage": session.current_stage,
        "total_stages": session.total_stages,
        "started_at": session.started_at,
        "completed_at": session.completed_at
    }


@router.get("/sessions/{session_id}/stages", response_model=List[Dict[str, Any]])
def get_session_stages(session_id: int, db: Session = Depends(get_db)):
    """
    Get all processing stages for a given session.
    """
    stages = JSONStageRepository(db).get_by_session(session_id)
    if not stages:
        # Check if session exists at all
        if not ProcessingSessionRepository(db).get_by_id(session_id):
            raise HTTPException(status_code=404, detail="Session not found")
        return []

    return [
        {
            "stage_number": stage.stage_number,
            "stage_name": stage.stage_name,
            "status": stage.status.value,
            "processing_time_ms": stage.processing_time_ms,
            "created_at": stage.created_at
        } for stage in stages
    ]

@router.get("/sessions/{session_id}/stages/{stage_number}", response_model=Dict[str, Any])
def get_stage_details(session_id: int, stage_number: int, db: Session = Depends(get_db)):
    """
    Get details for a specific stage, including its output JSON.
    """
    stage = JSONStageRepository(db).get_by_session_and_stage(session_id, stage_number)
    if not stage:
        raise HTTPException(status_code=404, detail=f"Stage {stage_number} for session {session_id} not found")

    return {
        "stage_number": stage.stage_number,
        "stage_name": stage.stage_name,
        "status": stage.status.value,
        "processing_time_ms": stage.processing_time_ms,
        "confidence_scores": stage.confidence_scores,
        "error_log": stage.error_log,
        "output_json_preview": {k: v for k, v in (stage.output_json or {}).items() if k != 'detected_objects'} # Preview without large lists
    }

@router.get("/sessions/{session_id}/stages/{stage_number}/json")
def get_stage_json(session_id: int, stage_number: int, db: Session = Depends(get_db)):
    """
    Get the full JSON output for a specific stage.
    """
    stage = JSONStageRepository(db).get_by_session_and_stage(session_id, stage_number)
    if not stage or not stage.output_json:
        raise HTTPException(status_code=404, detail=f"JSON output for stage {stage_number} of session {session_id} not found or is empty")

    return stage.output_json