# image_utils.py

import os
import mimetypes
from PIL import Image, ExifTags
from typing import Dict, Optional, Tuple, List
from fastapi import HTTPException, UploadFile
import logging

logger = logging.getLogger(__name__)

# Allowed image formats and their MIME types
ALLOWED_IMAGE_FORMATS = {
    'image/jpeg': ['jpg', 'jpeg'],
    'image/png': ['png'],
    'image/bmp': ['bmp'],
    'image/tiff': ['tiff', 'tif'],
    'image/webp': ['webp'],
    'image/gif': ['gif']  # Optional: GIF support
}

# Flatten allowed extensions
ALLOWED_EXTENSIONS = []
for extensions in ALLOWED_IMAGE_FORMATS.values():
    ALLOWED_EXTENSIONS.extend(extensions)

# Maximum file size (50MB)
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB in bytes

# Minimum and maximum image dimensions
MIN_IMAGE_SIZE = (100, 100)  # Minimum 100x100 pixels
MAX_IMAGE_SIZE = (10000, 10000)  # Maximum 10000x10000 pixels

class ImageValidationError(Exception):
    """Custom exception for image validation errors"""
    pass

def validate_image_file(file: UploadFile) -> Dict:
    """
    Validate uploaded image file and return validation results
    
    Args:
        file: FastAPI UploadFile object
        
    Returns:
        Dict with validation results and file info
        
    Raises:
        ImageValidationError: If validation fails
    """
    validation_result = {
        'is_valid': False,
        'error_message': None,
        'file_info': {}
    }
    
    try:
        # Check if file exists
        if not file or not file.filename:
            raise ImageValidationError("No file provided")
        
        # Check file extension
        file_extension = file.filename.lower().split('.')[-1]
        if file_extension not in ALLOWED_EXTENSIONS:
            raise ImageValidationError(
                f"Invalid file format. Allowed formats: {', '.join(ALLOWED_EXTENSIONS)}"
            )
        
        # Check MIME type
        content_type = file.content_type
        if content_type not in ALLOWED_IMAGE_FORMATS:
            raise ImageValidationError(
                f"Invalid MIME type: {content_type}. Expected image formats only."
            )
        
        # Read file content for size validation
        file_content = file.file.read()
        file.file.seek(0)  # Reset file pointer
        
        # Check file size
        file_size = len(file_content)
        if file_size > MAX_FILE_SIZE:
            raise ImageValidationError(
                f"File too large: {file_size / (1024*1024):.2f}MB. Maximum allowed: {MAX_FILE_SIZE / (1024*1024)}MB"
            )
        
        if file_size == 0:
            raise ImageValidationError("File is empty")
        
        # Validate image using PIL
        try:
            image = Image.open(file.file)
            file.file.seek(0)  # Reset file pointer again
            
            # Check image dimensions
            width, height = image.size
            if width < MIN_IMAGE_SIZE[0] or height < MIN_IMAGE_SIZE[1]:
                raise ImageValidationError(
                    f"Image too small: {width}x{height}. Minimum size: {MIN_IMAGE_SIZE[0]}x{MIN_IMAGE_SIZE[1]}"
                )
            
            if width > MAX_IMAGE_SIZE[0] or height > MAX_IMAGE_SIZE[1]:
                raise ImageValidationError(
                    f"Image too large: {width}x{height}. Maximum size: {MAX_IMAGE_SIZE[0]}x{MAX_IMAGE_SIZE[1]}"
                )
            
            validation_result['file_info'] = {
                'filename': file.filename,
                'content_type': content_type,
                'file_size_bytes': file_size,
                'file_extension': file_extension,
                'image_width': width,
                'image_height': height,
                'image_format': image.format.lower() if image.format else file_extension,
                'image_mode': image.mode,
                'has_transparency': image.mode in ('RGBA', 'LA', 'P'),
                'aspect_ratio': round(width / height, 4)
            }
            
        except Exception as e:
            raise ImageValidationError(f"Invalid image file: {str(e)}")
        
        validation_result['is_valid'] = True
        return validation_result
        
    except ImageValidationError as e:
        validation_result['error_message'] = str(e)
        return validation_result
    except Exception as e:
        validation_result['error_message'] = f"Unexpected validation error: {str(e)}"
        return validation_result

def extract_image_metadata(file_path: str) -> Dict:
    """
    Extract comprehensive metadata from an image file
    
    Args:
        file_path: Path to the image file
        
    Returns:
        Dict containing image metadata
    """
    metadata = {}
    
    try:
        with Image.open(file_path) as image:
            # Basic image information
            metadata.update({
                'image_width': image.size[0],
                'image_height': image.size[1],
                'image_format': image.format.lower() if image.format else 'unknown',
                'image_color_mode': image.mode,
                'image_has_transparency': image.mode in ('RGBA', 'LA', 'P'),
                'image_aspect_ratio': round(image.size[0] / image.size[1], 4)
            })
            
            # File size
            file_stats = os.stat(file_path)
            metadata['image_size_bytes'] = file_stats.st_size
            
            # DPI/Resolution information
            dpi = image.info.get('dpi')
            if dpi:
                metadata['image_resolution_dpi'] = int(dpi[0]) if isinstance(dpi, tuple) else int(dpi)
            else:
                metadata['image_resolution_dpi'] = 72  # Default DPI
            
            # EXIF data extraction (for JPEG images mainly)
            if hasattr(image, '_getexif') and image._getexif() is not None:
                exif_data = {}
                exif = image._getexif()
                
                for tag_id, value in exif.items():
                    tag = ExifTags.TAGS.get(tag_id, tag_id)
                    if tag in ['Make', 'Model', 'DateTime', 'Software', 'Orientation']:
                        exif_data[tag] = str(value)
                
                if exif_data:
                    metadata['exif_data'] = exif_data
            
    except Exception as e:
        logger.warning(f"Failed to extract metadata from {file_path}: {e}")
        # Return basic file info even if image processing fails
        try:
            file_stats = os.stat(file_path)
            metadata['image_size_bytes'] = file_stats.st_size
        except:
            pass
    
    return metadata

def save_uploaded_file(file: UploadFile, save_path: str) -> str:
    """
    Save uploaded file to specified path with validation
    
    Args:
        file: FastAPI UploadFile object
        save_path: Path where to save the file
        
    Returns:
        str: Full path to saved file
        
    Raises:
        HTTPException: If file save fails
    """
    try:
        # Ensure directory exists
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        
        # Save file
        with open(save_path, "wb") as buffer:
            content = file.file.read()
            buffer.write(content)
        
        # Reset file pointer
        file.file.seek(0)
        
        return save_path
        
    except Exception as e:
        logger.error(f"Failed to save file to {save_path}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to save uploaded file: {str(e)}")

def generate_safe_filename(original_filename: str, project_name: str) -> str:
    """
    Generate a safe filename for storing uploaded images
    
    Args:
        original_filename: Original filename from upload
        project_name: Project name for prefix
        
    Returns:
        str: Safe filename
    """
    import re
    from datetime import datetime
    
    # Clean project name
    safe_project_name = re.sub(r'[^\w\-_\.]', '_', project_name)
    
    # Get file extension
    file_extension = original_filename.lower().split('.')[-1] if '.' in original_filename else 'jpg'
    
    # Generate timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    return f"{safe_project_name}_{timestamp}.{file_extension}"

def validate_file_for_processing(file_path: str) -> bool:
    """
    Validate if a file is suitable for AI processing
    
    Args:
        file_path: Path to the image file
        
    Returns:
        bool: True if suitable for processing
    """
    try:
        metadata = extract_image_metadata(file_path)
        
        # Check minimum requirements for AI processing
        width = metadata.get('image_width', 0)
        height = metadata.get('image_height', 0)
        
        # Floorplans should typically be at least 500x500 for good AI processing
        if width < 500 or height < 500:
            logger.warning(f"Image {file_path} may be too small for optimal AI processing: {width}x{height}")
            return False
        
        # Check aspect ratio - extremely narrow or wide images might not be floorplans
        aspect_ratio = metadata.get('image_aspect_ratio', 1.0)
        if aspect_ratio < 0.1 or aspect_ratio > 10.0:
            logger.warning(f"Image {file_path} has unusual aspect ratio: {aspect_ratio}")
            return False
        
        return True
        
    except Exception as e:
        logger.error(f"Failed to validate file for processing: {e}")
        return False