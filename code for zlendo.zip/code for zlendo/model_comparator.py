import logging
import numpy as np
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime

logger = logging.getLogger(__name__)

class ModelComparator:
    """Compare and analyze results from multiple AI models"""
    
    def __init__(self):
        self.model_version = "1.0.0"
        
        # Weights for different comparison metrics
        self.comparison_weights = {
            'confidence': 0.3,
            'detection_count': 0.2,
            'consistency': 0.3,
            'coverage': 0.2
        }
    
    def compare_results(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Compare results from multiple models
        
        Args:
            results: Dictionary containing results from different models
            
        Returns:
            Dictionary containing comparison analysis
        """
        try:
            logger.info("Starting model comparison analysis")
            
            # Filter out non-model results
            model_results = {k: v for k, v in results.items() 
                           if k in ['maskrcnn', 'yolo', 'ensemble']}
            
            if len(model_results) < 2:
                logger.warning("Need at least 2 models for comparison")
                return {
                    "comparison_available": False,
                    "reason": "Insufficient models for comparison"
                }
            
            # Perform detailed comparison
            comparison_data = {
                "comparison_available": True,
                "models_compared": list(model_results.keys()),
                "timestamp": datetime.now().isoformat(),
                "metrics": self._calculate_comparison_metrics(model_results),
                "object_analysis": self._analyze_object_consistency(model_results),
                "confidence_analysis": self._analyze_confidence_scores(model_results),
                "spatial_analysis": self._analyze_spatial_consistency(model_results),
                "recommendations": self._generate_recommendations(model_results)
            }
            
            logger.info("Model comparison completed successfully")
            return comparison_data
            
        except Exception as e:
            logger.error(f"Error in model comparison: {str(e)}")
            return {
                "comparison_available": False,
                "error": str(e)
            }
    
    def _calculate_comparison_metrics(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate overall comparison metrics"""
        metrics = {}
        
        for model_name, result in results.items():
            try:
                detection_count = result.get('detection_count', 0)
                confidence_scores = result.get('confidence_scores', [])
                
                avg_confidence = np.mean(confidence_scores) if confidence_scores else 0
                max_confidence = np.max(confidence_scores) if confidence_scores else 0
                min_confidence = np.min(confidence_scores) if confidence_scores else 0
                
                metrics[model_name] = {
                    'detection_count': detection_count,
                    'average_confidence': round(avg_confidence, 3),
                    'max_confidence': round(max_confidence, 3),
                    'min_confidence': round(min_confidence, 3),
                    'confidence_std': round(np.std(confidence_scores), 3) if confidence_scores else 0,
                    'processing_time_ms': result.get('processing_time_ms', 0)
                }
                
            except Exception as e:
                logger.error(f"Error calculating metrics for {model_name}: {str(e)}")
                metrics[model_name] = {
                    'error': str(e)
                }
        
        return metrics
    
    def _analyze_object_consistency(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze consistency of object detection across models"""
        try:
            all_classes = set()
            model_classes = {}
            
            # Collect all detected classes
            for model_name, result in results.items():
                classes = result.get('classes', [])
                model_class_names = [cls.get('name', '') for cls in classes]
                model_classes[model_name] = model_class_names
                all_classes.update(model_class_names)
            
            # Calculate consistency metrics
            consistency_data = {
                'total_unique_classes': len(all_classes),
                'classes_detected': list(all_classes),
                'model_class_counts': {
                    model: len(classes) for model, classes in model_classes.items()
                },
                'class_agreement': self._calculate_class_agreement(model_classes),
                'common_classes': self._find_common_classes(model_classes),
                'model_specific_classes': self._find_model_specific_classes(model_classes)
            }
            
            return consistency_data
            
        except Exception as e:
            logger.error(f"Error analyzing object consistency: {str(e)}")
            return {'error': str(e)}
    
    def _analyze_confidence_scores(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze confidence score distributions"""
        try:
            confidence_analysis = {}
            
            for model_name, result in results.items():
                confidence_scores = result.get('confidence_scores', [])
                
                if not confidence_scores:
                    confidence_analysis[model_name] = {
                        'error': 'No confidence scores available'
                    }
                    continue
                
                # Calculate distribution metrics
                confidence_analysis[model_name] = {
                    'mean': round(np.mean(confidence_scores), 3),
                    'median': round(np.median(confidence_scores), 3),
                    'std': round(np.std(confidence_scores), 3),
                    'min': round(np.min(confidence_scores), 3),
                    'max': round(np.max(confidence_scores), 3),
                    'high_confidence_count': sum(1 for score in confidence_scores if score > 0.8),
                    'low_confidence_count': sum(1 for score in confidence_scores if score < 0.5),
                    'distribution': self._calculate_confidence_distribution(confidence_scores)
                }
            
            return confidence_analysis
            
        except Exception as e:
            logger.error(f"Error analyzing confidence scores: {str(e)}")
            return {'error': str(e)}
    
    def _analyze_spatial_consistency(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze spatial consistency of detections"""
        try:
            spatial_analysis = {}
            
            for model_name, result in results.items():
                points = result.get('points', [])
                
                if not points:
                    spatial_analysis[model_name] = {
                        'error': 'No spatial data available'
                    }
                    continue
                
                # Calculate spatial metrics
                bounding_box_areas = []
                center_points = []
                
                for point in points:
                    # Calculate bounding box area
                    width = abs(point.get('x2', 0) - point.get('x1', 0))
                    height = abs(point.get('y2', 0) - point.get('y1', 0))
                    area = width * height
                    bounding_box_areas.append(area)
                    
                    # Calculate center point
                    center_x = (point.get('x1', 0) + point.get('x2', 0)) / 2
                    center_y = (point.get('y1', 0) + point.get('y2', 0)) / 2
                    center_points.append((center_x, center_y))
                
                spatial_analysis[model_name] = {
                    'avg_bounding_box_area': round(np.mean(bounding_box_areas), 2) if bounding_box_areas else 0,
                    'total_coverage_area': round(sum(bounding_box_areas), 2),
                    'detection_density': len(points) / (result.get('Width', 1) * result.get('Height', 1)) if result.get('Width') and result.get('Height') else 0,
                    'spatial_distribution': self._calculate_spatial_distribution(center_points, 
                                                                              result.get('Width', 1), 
                                                                              result.get('Height', 1))
                }
            
            return spatial_analysis
            
        except Exception as e:
            logger.error(f"Error analyzing spatial consistency: {str(e)}")
            return {'error': str(e)}
    
    def _generate_recommendations(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Generate recommendations based on comparison"""
        try:
            recommendations = {
                'best_model': None,
                'confidence_leader': None,
                'speed_leader': None,
                'coverage_leader': None,
                'overall_recommendation': '',
                'specific_recommendations': []
            }
            
            # Find best performing models in different categories
            best_confidence = 0
            best_speed = float('inf')
            best_coverage = 0
            
            model_scores = {}
            
            for model_name, result in results.items():
                confidence_scores = result.get('confidence_scores', [])
                processing_time = result.get('processing_time_ms', 0)
                detection_count = result.get('detection_count', 0)
                
                avg_confidence = np.mean(confidence_scores) if confidence_scores else 0
                
                # Track leaders
                if avg_confidence > best_confidence:
                    best_confidence = avg_confidence
                    recommendations['confidence_leader'] = model_name
                
                if processing_time < best_speed:
                    best_speed = processing_time
                    recommendations['speed_leader'] = model_name
                
                if detection_count > best_coverage:
                    best_coverage = detection_count
                    recommendations['coverage_leader'] = model_name
                
                # Calculate overall score
                score = self._calculate_model_score(result)
                model_scores[model_name] = score
            
            # Determine best overall model
            if model_scores:
                best_model = max(model_scores, key=model_scores.get)
                recommendations['best_model'] = best_model
                
                # Generate overall recommendation
                recommendations['overall_recommendation'] = self._generate_overall_recommendation(
                    best_model, model_scores, recommendations
                )
                
                # Generate specific recommendations
                recommendations['specific_recommendations'] = self._generate_specific_recommendations(
                    results, model_scores, recommendations
                )
            
            return recommendations
            
        except Exception as e:
            logger.error(f"Error generating recommendations: {str(e)}")
            return {'error': str(e)}
    
    def _calculate_class_agreement(self, model_classes: Dict[str, List[str]]) -> float:
        """Calculate agreement between models on detected classes"""
        if len(model_classes) < 2:
            return 1.0
        
        all_classes = set()
        for classes in model_classes.values():
            all_classes.update(classes)
        
        if not all_classes:
            return 1.0
        
        agreement_count = 0
        total_classes = len(all_classes)
        
        for class_name in all_classes:
            models_detecting_class = sum(1 for classes in model_classes.values() 
                                       if class_name in classes)
            if models_detecting_class > 1:
                agreement_count += 1
        
        return agreement_count / total_classes if total_classes > 0 else 1.0
    
    def _find_common_classes(self, model_classes: Dict[str, List[str]]) -> List[str]:
        """Find classes detected by all models"""
        if not model_classes:
            return []
        
        common_classes = set(next(iter(model_classes.values())))
        for classes in model_classes.values():
            common_classes = common_classes.intersection(set(classes))
        
        return list(common_classes)
    
    def _find_model_specific_classes(self, model_classes: Dict[str, List[str]]) -> Dict[str, List[str]]:
        """Find classes detected by only one model"""
        specific_classes = {}
        
        for model_name, classes in model_classes.items():
            model_specific = []
            for class_name in classes:
                other_models_count = sum(1 for other_model, other_classes in model_classes.items()
                                       if other_model != model_name and class_name in other_classes)
                if other_models_count == 0:
                    model_specific.append(class_name)
            
            if model_specific:
                specific_classes[model_name] = model_specific
        
        return specific_classes
    
    def _calculate_confidence_distribution(self, confidence_scores: List[float]) -> Dict[str, int]:
        """Calculate confidence score distribution"""
        distribution = {
            'very_low': 0,    # 0-0.3
            'low': 0,         # 0.3-0.5
            'medium': 0,      # 0.5-0.7
            'high': 0,        # 0.7-0.9
            'very_high': 0    # 0.9-1.0
        }
        
        for score in confidence_scores:
            if score < 0.3:
                distribution['very_low'] += 1
            elif score < 0.5:
                distribution['low'] += 1
            elif score < 0.7:
                distribution['medium'] += 1
            elif score < 0.9:
                distribution['high'] += 1
            else:
                distribution['very_high'] += 1
        
        return distribution
    
    def _calculate_spatial_distribution(self, center_points: List[Tuple[float, float]], 
                                      width: int, height: int) -> Dict[str, int]:
        """Calculate spatial distribution of detections"""
        distribution = {
            'top_left': 0,
            'top_right': 0,
            'bottom_left': 0,
            'bottom_right': 0,
            'center': 0
        }
        
        mid_x = width / 2
        mid_y = height / 2
        
        for x, y in center_points:
            # Simple quadrant-based distribution
            if x < mid_x and y < mid_y:
                distribution['top_left'] += 1
            elif x >= mid_x and y < mid_y:
                distribution['top_right'] += 1
            elif x < mid_x and y >= mid_y:
                distribution['bottom_left'] += 1
            elif x >= mid_x and y >= mid_y:
                distribution['bottom_right'] += 1
            
            # Check if near center
            if abs(x - mid_x) < width * 0.2 and abs(y - mid_y) < height * 0.2:
                distribution['center'] += 1
        
        return distribution
    
    def _calculate_model_score(self, result: Dict[str, Any]) -> float:
        """Calculate overall score for a model"""
        try:
            confidence_scores = result.get('confidence_scores', [])
            detection_count = result.get('detection_count', 0)
            processing_time = result.get('processing_time_ms', 1000)
            
            # Normalize metrics
            avg_confidence = np.mean(confidence_scores) if confidence_scores else 0
            speed_score = max(0, 1 - (processing_time / 10000))  # Normalize to 0-1
            coverage_score = min(1, detection_count / 20)  # Normalize to 0-1
            
            # Calculate weighted score
            score = (
                self.comparison_weights['confidence'] * avg_confidence +
                self.comparison_weights['detection_count'] * coverage_score +
                self.comparison_weights['consistency'] * speed_score +
                self.comparison_weights['coverage'] * coverage_score
            )
            
            return round(score, 3)
            
        except Exception as e:
            logger.error(f"Error calculating model score: {str(e)}")
            return 0.0
    
    def _generate_overall_recommendation(self, best_model: str, model_scores: Dict[str, float], 
                                       recommendations: Dict[str, Any]) -> str:
        """Generate overall recommendation text"""
        try:
            confidence_leader = recommendations.get('confidence_leader', 'unknown')
            speed_leader = recommendations.get('speed_leader', 'unknown')
            
            if best_model == confidence_leader and best_model == speed_leader:
                return f"{best_model} is the clear winner, excelling in both accuracy and speed."
            elif best_model == confidence_leader:
                return f"{best_model} is recommended for its superior confidence scores, though {speed_leader} is faster."
            elif best_model == speed_leader:
                return f"{best_model} is recommended for its speed, though {confidence_leader} has better confidence scores."
            else:
                return f"{best_model} provides the best overall balance of performance metrics."
                
        except Exception as e:
            logger.error(f"Error generating overall recommendation: {str(e)}")
            return "Unable to generate recommendation due to insufficient data."
    
    def _generate_specific_recommendations(self, results: Dict[str, Any], 
                                         model_scores: Dict[str, float],
                                         recommendations: Dict[str, Any]) -> List[str]:
        """Generate specific recommendations"""
        specific_recs = []
        
        try:
            # Speed recommendations
            if recommendations.get('speed_leader'):
                specific_recs.append(f"For real-time applications, use {recommendations['speed_leader']} for fastest processing.")
            
            # Accuracy recommendations
            if recommendations.get('confidence_leader'):
                specific_recs.append(f"For highest accuracy, use {recommendations['confidence_leader']} for best confidence scores.")
            
            # Coverage recommendations
            if recommendations.get('coverage_leader'):
                specific_recs.append(f"For comprehensive detection, use {recommendations['coverage_leader']} for maximum object coverage.")
            
            # Ensemble recommendations
            if 'ensemble' in results and len(results) > 2:
                specific_recs.append("Consider ensemble method for best overall performance combining multiple models.")
            
        except Exception as e:
            logger.error(f"Error generating specific recommendations: {str(e)}")
        
        return specific_recs
    
    def get_model_version(self) -> str:
        """Get model comparator version"""
        return self.model_version