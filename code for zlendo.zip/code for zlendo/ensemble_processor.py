import os
import time
import logging
import numpy as np
from typing import Dict, List, Optional, Any, Tuple
from collections import defaultdict
import json

logger = logging.getLogger(__name__)

class EnsembleProcessor:
    """Ensemble processor for combining multiple AI model results"""
    
    def __init__(self):
        self.model_version = "1.0.0"
        self.ensemble_methods = [
            'weighted_average',
            'confidence_voting',
            'nms_fusion',
            'consensus_based'
        ]
        self.default_method = 'weighted_average'
        
        # Model weights for ensemble (can be adjusted based on model performance)
        self.model_weights = {
            'maskrcnn': 0.6,
            'yolo': 0.4,
            'yolov8': 0.4  # alias for yolo
        }
        
        # IoU threshold for matching detections
        self.iou_threshold = 0.5
        
        # Confidence threshold for final ensemble results
        self.confidence_threshold = 0.3
        
        # Class mapping consistency
        self.class_mapping = {
            'wall': 'wall',
            'window': 'window', 
            'door': 'door'
        }
    
    def process_results(self, model_results: Dict[str, Any], 
                       method: str = None) -> Dict[str, Any]:
        """
        Process and combine results from multiple AI models
        
        Args:
            model_results: Dictionary containing results from different models
            method: Ensemble method to use
            
        Returns:
            Dictionary containing ensemble results
        """
        start_time = time.time()
        
        try:
            if not model_results:
                raise ValueError("No model results provided for ensemble")
            
            # Filter out invalid results
            valid_results = self._filter_valid_results(model_results)
            
            if not valid_results:
                raise ValueError("No valid model results found")
            
            logger.info(f"Processing ensemble with {len(valid_results)} models")
            
            # Select ensemble method
            ensemble_method = method or self.default_method
            
            # Process based on selected method
            if ensemble_method == 'weighted_average':
                ensemble_result = self._weighted_average_ensemble(valid_results)
            elif ensemble_method == 'confidence_voting':
                ensemble_result = self._confidence_voting_ensemble(valid_results)
            elif ensemble_method == 'nms_fusion':
                ensemble_result = self._nms_fusion_ensemble(valid_results)
            elif ensemble_method == 'consensus_based':
                ensemble_result = self._consensus_based_ensemble(valid_results)
            else:
                logger.warning(f"Unknown ensemble method: {ensemble_method}, using default")
                ensemble_result = self._weighted_average_ensemble(valid_results)
            
            # Post-process ensemble result
            final_result = self._post_process_ensemble(ensemble_result, valid_results)
            
            processing_time = int((time.time() - start_time) * 1000)
            logger.info(f"Ensemble processing completed in {processing_time}ms")
            
            return {
                **final_result,
                "processing_time_ms": processing_time,
                "model_info": {
                    "name": "Ensemble",
                    "version": self.model_version,
                    "method": ensemble_method,
                    "models_used": list(valid_results.keys()),
                    "classes": list(self.class_mapping.values())
                },
                "ensemble_metadata": {
                    "method": ensemble_method,
                    "models_combined": len(valid_results),
                    "confidence_threshold": self.confidence_threshold,
                    "iou_threshold": self.iou_threshold
                }
            }
            
        except Exception as e:
            logger.error(f"Error in ensemble processing: {str(e)}")
            raise
    
    def _filter_valid_results(self, model_results: Dict[str, Any]) -> Dict[str, Any]:
        """Filter out invalid or empty model results"""
        valid_results = {}
        
        for model_name, result in model_results.items():
            if self._is_valid_result(result):
                valid_results[model_name] = result
            else:
                logger.warning(f"Invalid result from model {model_name}, skipping")
        
        return valid_results
    
    def _is_valid_result(self, result: Any) -> bool:
        """Check if model result is valid"""
        if not isinstance(result, dict):
            return False
        
        required_keys = ['points', 'classes', 'Width', 'Height']
        if not all(key in result for key in required_keys):
            return False
        
        if not isinstance(result['points'], list):
            return False
        
        if not isinstance(result['classes'], list):
            return False
        
        if len(result['points']) != len(result['classes']):
            return False
        
        return True
    
    def _weighted_average_ensemble(self, model_results: Dict[str, Any]) -> Dict[str, Any]:
        """Weighted average ensemble method"""
        try:
            # Collect all detections with model weights
            weighted_detections = []
            
            for model_name, result in model_results.items():
                model_weight = self.model_weights.get(model_name, 0.5)
                
                for i, point in enumerate(result['points']):
                    class_info = result['classes'][i]
                    
                    # Calculate weighted confidence
                    original_confidence = class_info.get('confidence', 50.0) / 100.0
                    weighted_confidence = original_confidence * model_weight
                    
                    detection = {
                        'bbox': [point['x1'], point['y1'], point['x2'], point['y2']],
                        'class_name': class_info['name'],
                        'confidence': weighted_confidence,
                        'model_source': model_name,
                        'model_weight': model_weight
                    }
                    weighted_detections.append(detection)
            
            # Group detections by class and spatial proximity
            grouped_detections = self._group_detections_by_proximity(weighted_detections)
            
            # Merge overlapping detections
            merged_detections = self._merge_overlapping_detections(grouped_detections)
            
            # Get image dimensions from first valid result
            width = list(model_results.values())[0]['Width']
            height = list(model_results.values())[0]['Height']
            
            return self._format_ensemble_result(merged_detections, width, height)
            
        except Exception as e:
            logger.error(f"Error in weighted average ensemble: {str(e)}")
            raise
    
    def _confidence_voting_ensemble(self, model_results: Dict[str, Any]) -> Dict[str, Any]:
        """Confidence-based voting ensemble method"""
        try:
            # Collect all detections
            all_detections = []
            
            for model_name, result in model_results.items():
                for i, point in enumerate(result['points']):
                    class_info = result['classes'][i]
                    
                    detection = {
                        'bbox': [point['x1'], point['y1'], point['x2'], point['y2']],
                        'class_name': class_info['name'],
                        'confidence': class_info.get('confidence', 50.0) / 100.0,
                        'model_source': model_name
                    }
                    all_detections.append(detection)
            
            # Group detections by spatial proximity
            grouped_detections = self._group_detections_by_proximity(all_detections)
            
            # Vote based on confidence scores
            voted_detections = []
            for group in grouped_detections:
                if len(group) == 1:
                    # Single detection, use as-is if confidence is high enough
                    if group[0]['confidence'] >= self.confidence_threshold:
                        voted_detections.append(group[0])
                else:
                    # Multiple detections, vote based on confidence
                    voted_detection = self._vote_on_detection_group(group)
                    if voted_detection:
                        voted_detections.append(voted_detection)
            
            # Get image dimensions
            width = list(model_results.values())[0]['Width']
            height = list(model_results.values())[0]['Height']
            
            return self._format_ensemble_result(voted_detections, width, height)
            
        except Exception as e:
            logger.error(f"Error in confidence voting ensemble: {str(e)}")
            raise
    
    def _nms_fusion_ensemble(self, model_results: Dict[str, Any]) -> Dict[str, Any]:
        """Non-Maximum Suppression fusion ensemble method"""
        try:
            # Collect all detections
            all_detections = []
            
            for model_name, result in model_results.items():
                for i, point in enumerate(result['points']):
                    class_info = result['classes'][i]
                    
                    detection = {
                        'bbox': [point['x1'], point['y1'], point['x2'], point['y2']],
                        'class_name': class_info['name'],
                        'confidence': class_info.get('confidence', 50.0) / 100.0,
                        'model_source': model_name
                    }
                    all_detections.append(detection)
            
            # Apply NMS per class
            nms_detections = []
            classes_present = set(det['class_name'] for det in all_detections)
            
            for class_name in classes_present:
                class_detections = [det for det in all_detections if det['class_name'] == class_name]
                nms_class_detections = self._apply_nms(class_detections)
                nms_detections.extend(nms_class_detections)
            
            # Get image dimensions
            width = list(model_results.values())[0]['Width']
            height = list(model_results.values())[0]['Height']
            
            return self._format_ensemble_result(nms_detections, width, height)
            
        except Exception as e:
            logger.error(f"Error in NMS fusion ensemble: {str(e)}")
            raise
    
    def _consensus_based_ensemble(self, model_results: Dict[str, Any]) -> Dict[str, Any]:
        """Consensus-based ensemble method"""
        try:
            # Collect all detections
            all_detections = []
            
            for model_name, result in model_results.items():
                for i, point in enumerate(result['points']):
                    class_info = result['classes'][i]
                    
                    detection = {
                        'bbox': [point['x1'], point['y1'], point['x2'], point['y2']],
                        'class_name': class_info['name'],
                        'confidence': class_info.get('confidence', 50.0) / 100.0,
                        'model_source': model_name
                    }
                    all_detections.append(detection)
            
            # Group detections by spatial proximity
            grouped_detections = self._group_detections_by_proximity(all_detections)
            
            # Require consensus from multiple models
            consensus_detections = []
            min_consensus = max(1, len(model_results) // 2)  # At least half the models
            
            for group in grouped_detections:
                if len(group) >= min_consensus:
                    # Calculate consensus detection
                    consensus_detection = self._calculate_consensus_detection(group)
                    consensus_detections.append(consensus_detection)
            
            # Get image dimensions
            width = list(model_results.values())[0]['Width']
            height = list(model_results.values())[0]['Height']
            
            return self._format_ensemble_result(consensus_detections, width, height)
            
        except Exception as e:
            logger.error(f"Error in consensus-based ensemble: {str(e)}")
            raise
    
    def _group_detections_by_proximity(self, detections: List[Dict]) -> List[List[Dict]]:
        """Group detections by spatial proximity using IoU"""
        groups = []
        used_indices = set()
        
        for i, detection in enumerate(detections):
            if i in used_indices:
                continue
            
            group = [detection]
            used_indices.add(i)
            
            for j, other_detection in enumerate(detections):
                if j <= i or j in used_indices:
                    continue
                
                iou = self._calculate_iou(detection['bbox'], other_detection['bbox'])
                if iou >= self.iou_threshold:
                    group.append(other_detection)
                    used_indices.add(j)
            
            groups.append(group)
        
        return groups
    
    def _merge_overlapping_detections(self, grouped_detections: List[List[Dict]]) -> List[Dict]:
        """Merge overlapping detections within groups"""
        merged_detections = []
        
        for group in grouped_detections:
            if len(group) == 1:
                merged_detections.append(group[0])
            else:
                # Average the bounding boxes and combine confidences
                merged_detection = self._average_detection_group(group)
                merged_detections.append(merged_detection)
        
        return merged_detections
    
    def _average_detection_group(self, group: List[Dict]) -> Dict:
        """Average multiple detections in a group"""
        # Calculate average bounding box
        avg_bbox = [0, 0, 0, 0]
        total_confidence = 0
        class_votes = defaultdict(int)
        
        for detection in group:
            bbox = detection['bbox']
            confidence = detection['confidence']
            class_name = detection['class_name']
            
            # Weight by confidence
            for i in range(4):
                avg_bbox[i] += bbox[i] * confidence
            
            total_confidence += confidence
            class_votes[class_name] += confidence
        
        # Normalize by total confidence
        if total_confidence > 0:
            for i in range(4):
                avg_bbox[i] /= total_confidence
        
        # Select class with highest weighted vote
        best_class = max(class_votes.items(), key=lambda x: x[1])[0]
        
        return {
            'bbox': avg_bbox,
            'class_name': best_class,
            'confidence': total_confidence / len(group),
            'model_source': 'ensemble'
        }
    
    def _vote_on_detection_group(self, group: List[Dict]) -> Optional[Dict]:
        """Vote on a group of detections"""
        if not group:
            return None
        
        # Vote based on confidence-weighted class prediction
        class_votes = defaultdict(float)
        bbox_sum = [0, 0, 0, 0]
        total_weight = 0
        
        for detection in group:
            confidence = detection['confidence']
            class_name = detection['class_name']
            bbox = detection['bbox']
            
            class_votes[class_name] += confidence
            
            for i in range(4):
                bbox_sum[i] += bbox[i] * confidence
            
            total_weight += confidence
        
        # Select class with highest vote
        best_class = max(class_votes.items(), key=lambda x: x[1])[0]
        best_confidence = class_votes[best_class] / len(group)
        
        # Check if confidence meets threshold
        if best_confidence < self.confidence_threshold:
            return None
        
        # Calculate weighted average bbox
        avg_bbox = [coord / total_weight for coord in bbox_sum]
        
        return {
            'bbox': avg_bbox,
            'class_name': best_class,
            'confidence': best_confidence,
            'model_source': 'ensemble'
        }
    
    def _apply_nms(self, detections: List[Dict]) -> List[Dict]:
        """Apply Non-Maximum Suppression to detections"""
        if not detections:
            return []
        
        # Sort by confidence (descending)
        sorted_detections = sorted(detections, key=lambda x: x['confidence'], reverse=True)
        
        keep = []
        while sorted_detections:
            # Keep the highest confidence detection
            current = sorted_detections.pop(0)
            keep.append(current)
            
            # Remove overlapping detections
            filtered_detections = []
            for detection in sorted_detections:
                iou = self._calculate_iou(current['bbox'], detection['bbox'])
                if iou < self.iou_threshold:
                    filtered_detections.append(detection)
            
            sorted_detections = filtered_detections
        
        return keep
    
    def _calculate_consensus_detection(self, group: List[Dict]) -> Dict:
        """Calculate consensus detection from a group"""
        # Use median for robustness
        bboxes = [det['bbox'] for det in group]
        confidences = [det['confidence'] for det in group]
        
        # Calculate median bbox
        median_bbox = []
        for i in range(4):
            coords = sorted([bbox[i] for bbox in bboxes])
            median_bbox.append(coords[len(coords) // 2])
        
        # Calculate average confidence
        avg_confidence = sum(confidences) / len(confidences)
        
        # Vote on class
        class_votes = defaultdict(int)
        for detection in group:
            class_votes[detection['class_name']] += 1
        
        best_class = max(class_votes.items(), key=lambda x: x[1])[0]
        
        return {
            'bbox': median_bbox,
            'class_name': best_class,
            'confidence': avg_confidence,
            'model_source': 'ensemble'
        }
    
    def _calculate_iou(self, bbox1: List[float], bbox2: List[float]) -> float:
        """Calculate Intersection over Union (IoU) between two bounding boxes"""
        x1_1, y1_1, x2_1, y2_1 = bbox1
        x1_2, y1_2, x2_2, y2_2 = bbox2
        
        # Calculate intersection
        x1_i = max(x1_1, x1_2)
        y1_i = max(y1_1, y1_2)
        x2_i = min(x2_1, x2_2)
        y2_i = min(y2_1, y2_2)
        
        if x2_i <= x1_i or y2_i <= y1_i:
            return 0.0
        
        intersection = (x2_i - x1_i) * (y2_i - y1_i)
        
        # Calculate union
        area1 = (x2_1 - x1_1) * (y2_1 - y1_1)
        area2 = (x2_2 - x1_2) * (y2_2 - y1_2)
        union = area1 + area2 - intersection
        
        return intersection / union if union > 0 else 0.0
    
    def _format_ensemble_result(self, detections: List[Dict], width: int, height: int) -> Dict[str, Any]:
        """Format ensemble result to match expected output format"""
        points = []
        classes = []
        confidence_scores = []
        
        door_count = 0
        door_difference = 0
        
        for detection in detections:
            bbox = detection['bbox']
            class_name = detection['class_name']
            confidence = detection['confidence']
            
            # Format point
            point = {
                'x1': bbox[0],
                'y1': bbox[1],
                'x2': bbox[2],
                'y2': bbox[3]
            }
            points.append(point)
            
            # Format class
            class_info = {
                'name': class_name,
                'confidence': round(confidence * 100, 2)
            }
            classes.append(class_info)
            
            confidence_scores.append(confidence)
            
            # Calculate door metrics
            if class_name == 'door':
                door_count += 1
                width_diff = abs(bbox[2] - bbox[0])
                height_diff = abs(bbox[3] - bbox[1])
                door_difference += max(width_diff, height_diff)
        
        average_door = (door_difference / door_count) if door_count > 0 else 0
        
        return {
            'points': points,
            'classes': classes,
            'Width': width,
            'Height': height,
            'averageDoor': average_door,
            'detection_count': len(detections),
            'confidence_scores': confidence_scores
        }
    
    def _post_process_ensemble(self, ensemble_result: Dict[str, Any], 
                             model_results: Dict[str, Any]) -> Dict[str, Any]:
        """Post-process ensemble result"""
        # Add ensemble-specific metadata
        ensemble_result['ensemble_info'] = {
            'models_used': list(model_results.keys()),
            'total_detections_before_ensemble': sum(
                len(result.get('points', [])) for result in model_results.values()
            ),
            'final_detections': ensemble_result['detection_count'],
            'confidence_threshold': self.confidence_threshold,
            'iou_threshold': self.iou_threshold
        }
        
        return ensemble_result
    
    def get_model_version(self) -> str:
        """Get model version"""
        return self.model_version
    
    def get_supported_methods(self) -> List[str]:
        """Get list of supported ensemble methods"""
        return self.ensemble_methods
    
    def set_model_weights(self, weights: Dict[str, float]):
        """Set model weights for ensemble"""
        self.model_weights.update(weights)
        logger.info(f"Model weights updated: {self.model_weights}")
    
    def set_confidence_threshold(self, threshold: float):
        """Set confidence threshold for ensemble"""
        if 0.0 <= threshold <= 1.0:
            self.confidence_threshold = threshold
            logger.info(f"Confidence threshold set to {threshold}")
        else:
            logger.warning("Confidence threshold must be between 0.0 and 1.0")
    
    def set_iou_threshold(self, threshold: float):
        """Set IoU threshold for ensemble"""
        if 0.0 <= threshold <= 1.0:
            self.iou_threshold = threshold
            logger.info(f"IoU threshold set to {threshold}")
        else:
            logger.warning("IoU threshold must be between 0.0 and 1.0")