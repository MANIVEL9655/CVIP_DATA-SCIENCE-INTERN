# from sqlalchemy.orm import Session
# from sqlalchemy import and_, or_, desc, asc
# from typing import List, Optional, Dict, Any
# from datetime import datetime
# import uuid
# import numpy as np

# from models import (
#     Project, ProcessingSession, JSONStage, AIModelResult, 
#     ObjectClass, DebugLog, ModelOutput, ProjectStatus, 
#     SessionStatus, StageStatus, AIModel, LogLevel
# )
# def to_serializable(obj):
#     """Recursively convert numpy and torch types to native Python types."""
#     if isinstance(obj, dict):
#         return {k: to_serializable(v) for k, v in obj.items()}
#     elif isinstance(obj, list):
#         return [to_serializable(v) for v in obj]
#     elif hasattr(obj, "tolist"):
#         return obj.tolist()
#     elif isinstance(obj, (float, int, str, bool)) or obj is None:
#         return obj
#     elif isinstance(obj, (np.integer, np.int32, np.int64)):
#         return int(obj)
#     elif isinstance(obj, (np.floating, np.float32, np.float64)):
#         return float(obj)
#     else:
#         return str(obj)  # fallback

# class ProjectRepository:
#     def __init__(self, db: Session):
#         self.db = db
    
#     def create(self, name: str, description: str = None, 
#                original_image_path: str = None, 
#                image_dimensions: Dict = None, 
#                user_id: int = None) -> Project:
#         """Create a new project"""
#         project = Project(
#             name=name,
#             description=description,
#             original_image_path=original_image_path,
#             image_dimensions=image_dimensions,
#             user_id=user_id
#         )
#         self.db.add(project)
#         self.db.commit()
#         self.db.refresh(project)
#         return project
    
#     def get_by_id(self, project_id: int) -> Optional[Project]:
#         """Get project by ID"""
#         return self.db.query(Project).filter(Project.id == project_id).first()
    
#     def get_all(self, user_id: int = None, status: ProjectStatus = None) -> List[Project]:
#         """Get all projects with optional filtering"""
#         query = self.db.query(Project)
        
#         if user_id:
#             query = query.filter(Project.user_id == user_id)
        
#         if status:
#             query = query.filter(Project.status == status)
        
#         return query.order_by(desc(Project.created_at)).all()
    
#     def update_status(self, project_id: int, status: ProjectStatus) -> bool:
#         """Update project status"""
#         result = self.db.query(Project).filter(Project.id == project_id).update(
#             {"status": status, "updated_at": datetime.now()}
#         )
#         self.db.commit()
#         return result > 0
    
#     def delete(self, project_id: int) -> bool:
#         """Delete project"""
#         result = self.db.query(Project).filter(Project.id == project_id).delete()
#         self.db.commit()
#         return result > 0

# class ProcessingSessionRepository:
#     def __init__(self, db: Session):
#         self.db = db
    
#     def create(self, project_id: int, ai_model_flags: Dict, 
#                processing_config: Dict = None, 
#                total_stages: int = 4) -> ProcessingSession:
#         """Create a new processing session"""
#         session = ProcessingSession(
#             project_id=project_id,
#             session_uuid=str(uuid.uuid4()),
#             ai_model_flags=ai_model_flags,
#             processing_config=processing_config,
#             total_stages=total_stages
#         )
#         self.db.add(session)
#         self.db.commit()
#         self.db.refresh(session)
#         return session
    
#     def get_by_id(self, session_id: int) -> Optional[ProcessingSession]:
#         """Get session by ID"""
#         return self.db.query(ProcessingSession).filter(
#             ProcessingSession.id == session_id
#         ).first()
    
#     def get_by_uuid(self, session_uuid: str) -> Optional[ProcessingSession]:
#         """Get session by UUID"""
#         return self.db.query(ProcessingSession).filter(
#             ProcessingSession.session_uuid == session_uuid
#         ).first()
    
#     def get_by_project(self, project_id: int) -> List[ProcessingSession]:
#         """Get all sessions for a project"""
#         return self.db.query(ProcessingSession).filter(
#             ProcessingSession.project_id == project_id
#         ).order_by(desc(ProcessingSession.created_at)).all()
    
#     def update_status(self, session_id: int, status: SessionStatus, 
#                      current_stage: int = None) -> bool:
#         """Update session status and current stage"""
#         update_data = {"status": status}
        
#         if current_stage is not None:
#             update_data["current_stage"] = current_stage
        
#         if status == SessionStatus.PROCESSING and not self.get_by_id(session_id).started_at:
#             update_data["started_at"] = datetime.now()
        
#         if status in [SessionStatus.COMPLETED, SessionStatus.FAILED]:
#             update_data["completed_at"] = datetime.now()
        
#         result = self.db.query(ProcessingSession).filter(
#             ProcessingSession.id == session_id
#         ).update(update_data)
#         self.db.commit()
#         return result > 0

# class JSONStageRepository:
#     def __init__(self, db: Session):
#         self.db = db
    
#     def create(self, session_id: int, stage_number: int, 
#            stage_name: str, stage_type: str = "local", 
#            input_json: Dict = None, status: StageStatus = StageStatus.PROCESSING) -> JSONStage:
#         """Create a new JSON stage"""
#         # stage = JSONStage(
#         #     session_id=session_id,
#         #     stage_number=stage_number,
#         #     stage_name=stage_name,
#         #     stage_type=stage_type,
#         #     input_json=input_json,
#         #     status=status
#         # )
#         stage = JSONStage(
#             session_id=session_id,
#             stage_number=stage_number,
#             stage_name=stage_name,
#             stage_type=stage_type,
#             input_json=to_serializable(input_json),
#             status=status
#         )

#         self.db.add(stage)
#         self.db.commit()
#         self.db.refresh(stage)
#         return stage

#     # def create(self, session_id: int, stage_number: int, 
#     #            stage_name: str, stage_type: str = "local", 
#     #            input_json: Dict = None) -> JSONStage:
#     #     """Create a new JSON stage"""
#     #     stage = JSONStage(
#     #         session_id=session_id,
#     #         stage_number=stage_number,
#     #         stage_name=stage_name,
#     #         stage_type=stage_type,
#     #         input_json=input_json
#     #     )
#     #     self.db.add(stage)
#     #     self.db.commit()
#     #     self.db.refresh(stage)
#     #     return stage
    
#     def get_by_id(self, stage_id: int) -> Optional[JSONStage]:
#         """Get stage by ID"""
#         return self.db.query(JSONStage).filter(JSONStage.id == stage_id).first()
    
#     def get_by_session(self, session_id: int) -> List[JSONStage]:
#         """Get all stages for a session"""
#         return self.db.query(JSONStage).filter(
#             JSONStage.session_id == session_id
#         ).order_by(asc(JSONStage.stage_number)).all()
    
#     def get_by_session_and_stage(self, session_id: int, stage_number: int) -> Optional[JSONStage]:
#         """Get specific stage for a session"""
#         return self.db.query(JSONStage).filter(
#             and_(
#                 JSONStage.session_id == session_id,
#                 JSONStage.stage_number == stage_number
#             )
#         ).first()
    
#     def update_output(self, stage_id: int, output_json: Dict,
#                   processing_time_ms: int = None,
#                   confidence_scores: Dict = None,
#                   status: StageStatus = StageStatus.COMPLETED,
#                   error_log: str = None) -> bool:
#         update_data = {
#             "output_json": to_serializable(output_json),
#             "status": status
#         }

#         # update_data = {
#         #     "output_json": output_json,
#         #     "status": status
#         # }
#         if processing_time_ms is not None:
#             update_data["processing_time_ms"] = processing_time_ms
#         if confidence_scores is not None:
#             update_data["confidence_scores"] = confidence_scores
#         if error_log is not None:
#             update_data["error_log"] = error_log

#         result = self.db.query(JSONStage).filter(
#             JSONStage.id == stage_id
#         ).update(update_data)
#         self.db.commit()
#         return result > 0
    
#     # def update_output(self, stage_id: int, output_json: Dict,
#     #               processing_time_ms: int = None,
#     #               confidence_scores: Dict = None,
#     #               status: StageStatus = StageStatus.COMPLETED,
#     #               error_log: str = None) -> bool:
#     #     update_data = {
#     #         "output_json": output_json,
#     #         "status": status
#     #     }
#     #     if processing_time_ms is not None:
#     #         update_data["processing_time_ms"] = processing_time_ms
#     #     if confidence_scores is not None:
#     #         update_data["confidence_scores"] = confidence_scores
#     #     if error_log is not None:
#     #         update_data["error_log"] = error_log

#     #     result = self.db.query(JSONStage).filter(
#     #         JSONStage.id == stage_id
#     #     ).update(update_data)
#     #     self.db.commit()
#     #     return result > 0


#     # def update_output(self, stage_id: int, output_json: Dict, 
#     #                  processing_time_ms: int = None, 
#     #                  confidence_scores: Dict = None) -> bool:
#     #     """Update stage output"""
#     #     update_data = {
#     #         "output_json": output_json,
#     #         "status": StageStatus.COMPLETED
#     #     }
        
#         # if processing_time_ms is not None:
#         #     update_data["processing_time_ms"] = processing_time_ms
        
#         # if confidence_scores is not None:
#         #     update_data["confidence_scores"] = confidence_scores
        
#         # result = self.db.query(JSONStage).filter(
#         #     JSONStage.id == stage_id
#         # ).update(update_data)
#         # self.db.commit()
#         # return result > 0
    
#     def update_status(self, stage_id: int, status: StageStatus, 
#                      error_log: str = None) -> bool:
#         """Update stage status"""
#         update_data = {"status": status}
        
#         if error_log:
#             update_data["error_log"] = error_log
        
#         result = self.db.query(JSONStage).filter(
#             JSONStage.id == stage_id
#         ).update(update_data)
#         self.db.commit()
#         return result > 0

# class AIModelResultRepository:
#     def __init__(self, db: Session):
#         self.db = db
    
#     def create(self, session_id: int, model_name: AIModel, 
#                raw_output: Dict, processed_output: Dict = None,
#                confidence_threshold: float = None,
#                processing_time_ms: int = None,
#                model_version: str = None) -> AIModelResult:
#         """Create AI model result"""
#         result = AIModelResult(
#             session_id=session_id,
#             model_name=model_name,
#             raw_output=raw_output,
#             processed_output=processed_output,
#             confidence_threshold=confidence_threshold,
#             processing_time_ms=processing_time_ms,
#             model_version=model_version
#         )
#         self.db.add(result)
#         self.db.commit()
#         self.db.refresh(result)
#         return result
    
#     def get_by_session(self, session_id: int) -> List[AIModelResult]:
#         """Get all AI results for a session"""
#         return self.db.query(AIModelResult).filter(
#             AIModelResult.session_id == session_id
#         ).all()
    
#     def get_by_session_and_model(self, session_id: int, model_name: AIModel) -> Optional[AIModelResult]:
#         """Get specific model result for a session"""
#         return self.db.query(AIModelResult).filter(
#             and_(
#                 AIModelResult.session_id == session_id,
#                 AIModelResult.model_name == model_name
#             )
#         ).first()
    
# class ObjectClassRepository:
#     def __init__(self, db: Session):
#         self.db = db
    
#     def create(self, session_id: int, stage_id: int, class_name: str, 
#                class_type: str, bounding_box: Dict = None, 
#                center_point: Dict = None, orientation: str = None,
#                start_point: Dict = None, end_point: Dict = None,
#                dimensions: Dict = None, confidence_score: float = None,
#                is_global: bool = False, parent_class_id: int = None,
#                **kwargs) -> ObjectClass:
#         """Create a single object class"""
#         obj = ObjectClass(
#             session_id=session_id,
#             stage_id=stage_id,
#             class_name=class_name,
#             class_type=class_type,
#             bounding_box=bounding_box,
#             center_point=center_point,
#             orientation=orientation,
#             start_point=start_point,
#             end_point=end_point,
#             dimensions=dimensions,
#             confidence_score=confidence_score,
#             is_global=is_global,
#             parent_class_id=parent_class_id,
#             **kwargs  # Handle any additional fields
#         )
#         self.db.add(obj)
#         self.db.commit()
#         self.db.refresh(obj)
#         return obj
    
#     def create_batch(self, objects: List[Dict], session_id: int, 
#                     stage_id: int) -> List[ObjectClass]:
#         """Create multiple object classes"""
#         object_instances = []
#         for obj_data in objects:
#             obj = ObjectClass(
#                 session_id=session_id,
#                 stage_id=stage_id,
#                 **obj_data
#             )
#             object_instances.append(obj)
        
#         self.db.add_all(object_instances)
#         self.db.commit()
#         return object_instances
    
#     def get_by_session(self, session_id: int) -> List[ObjectClass]:
#         """Get all objects for a session"""
#         return self.db.query(ObjectClass).filter(
#             ObjectClass.session_id == session_id
#         ).all()
    
#     def get_by_stage(self, stage_id: int) -> List[ObjectClass]:
#         """Get all objects for a stage"""
#         return self.db.query(ObjectClass).filter(
#             ObjectClass.stage_id == stage_id
#         ).all()
    
#     def get_global_objects(self, session_id: int) -> List[ObjectClass]:
#         """Get global objects for a session"""
#         return self.db.query(ObjectClass).filter(
#             and_(
#                 ObjectClass.session_id == session_id,
#                 ObjectClass.is_global == True
#             )
#         ).all()

# # class ObjectClassRepository:
# #     def __init__(self, db: Session):
# #         self.db = db
    
# #     def create_batch(self, objects: List[Dict], session_id: int, 
# #                     stage_id: int) -> List[ObjectClass]:
# #         """Create multiple object classes"""
# #         object_instances = []
# #         for obj_data in objects:
# #             obj = ObjectClass(
# #                 session_id=session_id,
# #                 stage_id=stage_id,
# #                 **obj_data
# #             )
# #             object_instances.append(obj)
        
# #         self.db.add_all(object_instances)
# #         self.db.commit()
# #         return object_instances
    
# #     def get_by_session(self, session_id: int) -> List[ObjectClass]:
# #         """Get all objects for a session"""
# #         return self.db.query(ObjectClass).filter(
# #             ObjectClass.session_id == session_id
# #         ).all()
    
# #     def get_by_stage(self, stage_id: int) -> List[ObjectClass]:
# #         """Get all objects for a stage"""
# #         return self.db.query(ObjectClass).filter(
# #             ObjectClass.stage_id == stage_id
# #         ).all()
    
# #     def get_global_objects(self, session_id: int) -> List[ObjectClass]:
# #         """Get global objects for a session"""
# #         return self.db.query(ObjectClass).filter(
# #             and_(
# #                 ObjectClass.session_id == session_id,
# #                 ObjectClass.is_global == True
# #             )
# #         ).all()

# # class DebugLogRepository:
# #     def __init__(self, db: Session):
# #         self.db = db
    
# #     def create(self, session_id: int, log_level: LogLevel, 
# #                component: str, message: str, 
# #                stage_id: int = None, stack_trace: str = None,
# #                metadata: Dict = None) -> DebugLog:
# #         """Create debug log entry"""
# #         log = DebugLog(
# #             session_id=session_id,
# #             stage_id=stage_id,
# #             log_level=log_level,
# #             component=component,
# #             message=message,
# #             stack_trace=stack_trace,
# #             metadata=metadata
# #         )
# #         self.db.add(log)
# #         self.db.commit()
# #         self.db.refresh(log)
# #         return log
# # class DebugLogRepository:
# #     def __init__(self, db: Session):
# #         self.db = db
    
# #     def create(self, session_id: int, log_level: LogLevel, 
# #                component: str, message: str, 
# #                stage_id: int = None, stack_trace: str = None,
# #                log_data: Dict = None) -> DebugLog:  # RENAMED parameter from 'metadata'
# #         """Create debug log entry"""
# #         log = DebugLog(
# #             session_id=session_id,
# #             stage_id=stage_id,
# #             log_level=log_level,
# #             component=component,
# #             message=message,
# #             stack_trace=stack_trace,
# #             log_data=log_data  # RENAMED attribute from 'metadata'
# #         )
# #         self.db.add(log)
# #         self.db.commit()
# #         self.db.refresh(log)
# #         return log
    
# #     def get_by_session(self, session_id: int, log_level: LogLevel = None) -> List[DebugLog]:
# #         """Get logs for a session"""
# #         query = self.db.query(DebugLog).filter(DebugLog.session_id == session_id)
        
# #         if log_level:
# #             query = query.filter(DebugLog.log_level == log_level)
        
# #         return query.order_by(desc(DebugLog.created_at)).all()
    
# #     def get_by_stage(self, stage_id: int) -> List[DebugLog]:
# #         """Get logs for a stage"""
# #         return self.db.query(DebugLog).filter(
# #             DebugLog.stage_id == stage_id
# #         ).order_by(desc(DebugLog.created_at)).all()

# class DebugLogRepository:
#     def __init__(self, db: Session):
#         self.db = db


#     def create(self, session_id: int, log_level: LogLevel,
#            component: str, message: str,
#            stage_id: int = None, stack_trace: str = None,
#            log_data: Dict = None) -> DebugLog:
#         log = DebugLog(
#             session_id=session_id,
#             stage_id=stage_id,
#             log_level=log_level,
#             component=component,
#             message=message,
#             stack_trace=stack_trace,
#             log_data=log_data
#         )
#         self.db.add(log)
#         self.db.commit()
#         self.db.refresh(log)
#         return log

#     # def create(
#     #     self,
#     #     session_id: int,
#     #     log_level: LogLevel,
#     #     component: str,
#     #     message: str,
#     #     stage_id: int = None,
#     #     stack_trace: str = None,
#     #     metadata: Dict = None  # 👈 allow metadata as argument name
#     # ) -> DebugLog:
#     #     """Create debug log entry"""
#     #     log = DebugLog(
#     #         session_id=session_id,
#     #         stage_id=stage_id,
#     #         log_level=log_level,
#     #         component=component,
#     #         message=message,
#     #         stack_trace=stack_trace,
#     #         log_data=metadata  # 👈 store it in the DB field 'log_data'
#     #     )
#     #     self.db.add(log)
#     #     self.db.commit()
#     #     self.db.refresh(log)
#     #     return log

#     def get_by_session(self, session_id: int, log_level: LogLevel = None) -> List[DebugLog]:
#         """Get logs for a session"""
#         query = self.db.query(DebugLog).filter(DebugLog.session_id == session_id)

#         if log_level:
#             query = query.filter(DebugLog.log_level == log_level)

#         return query.order_by(desc(DebugLog.created_at)).all()

#     def get_by_stage(self, stage_id: int) -> List[DebugLog]:
#         """Get logs for a stage"""
#         return self.db.query(DebugLog).filter(
#             DebugLog.stage_id == stage_id
#         ).order_by(desc(DebugLog.created_at)).all()


# class ModelOutputRepository:
#     def __init__(self, db: Session):
#         self.db = db
    
#     def create(self, session_id: int, output_type: str, 
#                file_path: str, file_size_mb: float = None,
#                generation_time_ms: int = None,
#                blender_version: str = None,
#                export_settings: Dict = None,
#                quality_metrics: Dict = None) -> ModelOutput:
#         """Create model output record"""
#         output = ModelOutput(
#             session_id=session_id,
#             output_type=output_type,
#             file_path=file_path,
#             file_size_mb=file_size_mb,
#             generation_time_ms=generation_time_ms,
#             blender_version=blender_version,
#             export_settings=export_settings,
#             quality_metrics=quality_metrics
#         )
#         self.db.add(output)
#         self.db.commit()
#         self.db.refresh(output)
#         return output
    
#     def get_by_session(self, session_id: int) -> List[ModelOutput]:
#         """Get all outputs for a session"""
#         return self.db.query(ModelOutput).filter(
#             ModelOutput.session_id == session_id
#         ).all()
    
#     def get_by_id(self, output_id: int) -> Optional[ModelOutput]:
#         """Get output by ID"""
#         return self.db.query(ModelOutput).filter(
#             ModelOutput.id == output_id
#         ).first()










# repositories.py - Enhanced version with export management

from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, desc, asc
from typing import List, Optional, Dict, Any
from datetime import datetime
import uuid
import numpy as np

from models import (
    Project, ProcessingSession, JSONStage, AIModelResult, 
    ObjectClass, DebugLog, ModelOutput, ProjectStatus, 
    SessionStatus, StageStatus, AIModel, LogLevel, ImageFormat
)

def to_serializable(obj):
    """Recursively convert numpy and torch types to native Python types."""
    if isinstance(obj, dict):
        return {k: to_serializable(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [to_serializable(v) for v in obj]
    elif hasattr(obj, "tolist"):
        return obj.tolist()
    elif isinstance(obj, (float, int, str, bool)) or obj is None:
        return obj
    elif isinstance(obj, (np.integer, np.int32, np.int64)):
        return int(obj)
    elif isinstance(obj, (np.floating, np.float32, np.float64)):
        return float(obj)
    else:
        return str(obj)  # fallback

class ProjectRepository:
    def __init__(self, db: Session):
        self.db = db
    
    def create(self, name: str, description: str = None, 
               original_image_path: str = None, 
               image_width: int = None,
               image_height: int = None,
               image_resolution_dpi: int = None,
               image_size_bytes: int = None,
               image_format: ImageFormat = None,
               image_color_mode: str = None,
               image_has_transparency: bool = False,
               image_aspect_ratio: float = None,
               image_dimensions: Dict = None,  # Legacy field
               user_id: int = None) -> Project:
        """Create a new project with enhanced image metadata"""
        project = Project(
            name=name,
            description=description,
            original_image_path=original_image_path,
            image_width=image_width,
            image_height=image_height,
            image_resolution_dpi=image_resolution_dpi,
            image_size_bytes=image_size_bytes,
            image_format=image_format,
            image_color_mode=image_color_mode,
            image_has_transparency=image_has_transparency,
            image_aspect_ratio=image_aspect_ratio,
            image_dimensions=image_dimensions,
            user_id=user_id
        )
        self.db.add(project)
        self.db.commit()
        self.db.refresh(project)
        return project
    
    def get_by_id(self, project_id: int) -> Optional[Project]:
        """Get project by ID"""
        return self.db.query(Project).filter(Project.id == project_id).first()
    
    def get_all(self, user_id: int = None, status: ProjectStatus = None, 
                limit: int = 50, offset: int = 0) -> List[Project]:
        """Get all projects with optional filtering and pagination"""
        query = self.db.query(Project)
        
        if user_id:
            query = query.filter(Project.user_id == user_id)
        
        if status:
            query = query.filter(Project.status == status)
        
        return query.order_by(desc(Project.created_at)).offset(offset).limit(limit).all()
    
    def update_status(self, project_id: int, status: ProjectStatus) -> bool:
        """Update project status"""
        result = self.db.query(Project).filter(Project.id == project_id).update(
            {"status": status, "updated_at": datetime.now()}
        )
        self.db.commit()
        return result > 0
    
    def delete(self, project_id: int) -> bool:
        """Delete project"""
        result = self.db.query(Project).filter(Project.id == project_id).delete()
        self.db.commit()
        return result > 0

class ProcessingSessionRepository:
    def __init__(self, db: Session):
        self.db = db
    
    def create(self, project_id: int, ai_model_flags: Dict, 
               processing_config: Dict = None, 
               total_stages: int = 4) -> ProcessingSession:
        """Create a new processing session"""
        session = ProcessingSession(
            project_id=project_id,
            session_uuid=str(uuid.uuid4()),
            ai_model_flags=ai_model_flags,
            processing_config=processing_config,
            total_stages=total_stages
        )
        self.db.add(session)
        self.db.commit()
        self.db.refresh(session)
        return session
    
    def get_latest_for_project(self, project_id: int):
        return (
            self.db.query(ProcessingSession)
            .filter_by(project_id=project_id)
            .order_by(ProcessingSession.created_at.desc())
            .first()
        )
    
    def get_by_id(self, session_id: int) -> Optional[ProcessingSession]:
        """Get session by ID"""
        return self.db.query(ProcessingSession).filter(
            ProcessingSession.id == session_id
        ).first()
    
    def get_by_uuid(self, session_uuid: str) -> Optional[ProcessingSession]:
        """Get session by UUID"""
        return self.db.query(ProcessingSession).filter(
            ProcessingSession.session_uuid == session_uuid
        ).first()
    
    def get_by_project(self, project_id: int) -> List[ProcessingSession]:
        """Get all sessions for a project"""
        return self.db.query(ProcessingSession).filter(
            ProcessingSession.project_id == project_id
        ).order_by(desc(ProcessingSession.created_at)).all()
    
    def update_status(self, session_id: int, status: SessionStatus, 
                     current_stage: int = None) -> bool:
        """Update session status and current stage"""
        update_data = {"status": status}
        
        if current_stage is not None:
            update_data["current_stage"] = current_stage
        
        if status == SessionStatus.PROCESSING and not self.get_by_id(session_id).started_at:
            update_data["started_at"] = datetime.now()
        
        if status in [SessionStatus.COMPLETED, SessionStatus.FAILED]:
            update_data["completed_at"] = datetime.now()
        
        result = self.db.query(ProcessingSession).filter(
            ProcessingSession.id == session_id
        ).update(update_data)
        self.db.commit()
        return result > 0
    
    def update_export_info(self, session_id: int, export_file_path: str, 
                          export_file_size_bytes: int, export_format_version: str = "2.1") -> bool:
        """Update export file information"""
        update_data = {
            "export_file_path": export_file_path,
            "export_file_size_bytes": export_file_size_bytes,
            "export_created_at": datetime.now(),
            "export_format_version": export_format_version
        }
        
        result = self.db.query(ProcessingSession).filter(
            ProcessingSession.id == session_id
        ).update(update_data)
        self.db.commit()
        return result > 0
    
    def update_export_access(self, session_id: int) -> bool:
        """Update export access timestamp (for usage tracking)"""
        # Note: You might want to add a last_accessed field to track this
        return True
    
    def clear_export_info(self, session_id: int) -> bool:
        """Clear export file information"""
        update_data = {
            "export_file_path": None,
            "export_file_size_bytes": None,
            "export_created_at": None,
            "export_format_version": None
        }
        
        result = self.db.query(ProcessingSession).filter(
            ProcessingSession.id == session_id
        ).update(update_data)
        self.db.commit()
        return result > 0

class JSONStageRepository:
    def __init__(self, db: Session):
        self.db = db
    
    def create(self, session_id: int, stage_number: int, 
           stage_name: str, stage_type: str = "local", 
           input_json: Dict = None, status: StageStatus = StageStatus.PROCESSING) -> JSONStage:
        """Create a new JSON stage"""
        stage = JSONStage(
            session_id=session_id,
            stage_number=stage_number,
            stage_name=stage_name,
            stage_type=stage_type,
            input_json=to_serializable(input_json),
            status=status
        )
        self.db.add(stage)
        self.db.commit()
        self.db.refresh(stage)
        return stage
    
    def get_by_id(self, stage_id: int) -> Optional[JSONStage]:
        """Get stage by ID"""
        return self.db.query(JSONStage).filter(JSONStage.id == stage_id).first()
    
    def get_by_session(self, session_id: int) -> List[JSONStage]:
        """Get all stages for a session"""
        return self.db.query(JSONStage).filter(
            JSONStage.session_id == session_id
        ).order_by(asc(JSONStage.stage_number)).all()
    
    def get_by_session_and_stage(self, session_id: int, stage_number: int) -> Optional[JSONStage]:
        """Get specific stage for a session"""
        return self.db.query(JSONStage).filter(
            and_(
                JSONStage.session_id == session_id,
                JSONStage.stage_number == stage_number
            )
        ).first()
    
    def update_output(self, stage_id: int, output_json: Dict,
                  processing_time_ms: int = None,
                  confidence_scores: Dict = None,
                  status: StageStatus = StageStatus.COMPLETED,
                  error_log: str = None) -> bool:
        """Update stage output with serialization"""
        update_data = {
            "output_json": to_serializable(output_json),
            "status": status
        }
        
        if processing_time_ms is not None:
            update_data["processing_time_ms"] = processing_time_ms
        if confidence_scores is not None:
            update_data["confidence_scores"] = to_serializable(confidence_scores)
        if error_log is not None:
            update_data["error_log"] = error_log

        result = self.db.query(JSONStage).filter(
            JSONStage.id == stage_id
        ).update(update_data)
        self.db.commit()
        return result > 0
    
    def update_status(self, stage_id: int, status: StageStatus, 
                     error_log: str = None) -> bool:
        """Update stage status"""
        update_data = {"status": status}
        
        if error_log:
            update_data["error_log"] = error_log
        
        result = self.db.query(JSONStage).filter(
            JSONStage.id == stage_id
        ).update(update_data)
        self.db.commit()
        return result > 0

class AIModelResultRepository:
    def __init__(self, db: Session):
        self.db = db
    
    def create(self, session_id: int, model_name: AIModel, 
               raw_output: Dict, processed_output: Dict = None,
               confidence_threshold: float = None,
               processing_time_ms: int = None,
               model_version: str = None) -> AIModelResult:
        """Create AI model result"""
        result = AIModelResult(
            session_id=session_id,
            model_name=model_name,
            raw_output=to_serializable(raw_output),
            processed_output=to_serializable(processed_output),
            confidence_threshold=confidence_threshold,
            processing_time_ms=processing_time_ms,
            model_version=model_version
        )
        self.db.add(result)
        self.db.commit()
        self.db.refresh(result)
        return result
    
    def get_by_session(self, session_id: int) -> List[AIModelResult]:
        """Get all AI results for a session"""
        return self.db.query(AIModelResult).filter(
            AIModelResult.session_id == session_id
        ).all()
    
    def get_by_session_and_model(self, session_id: int, model_name: AIModel) -> Optional[AIModelResult]:
        """Get specific model result for a session"""
        return self.db.query(AIModelResult).filter(
            and_(
                AIModelResult.session_id == session_id,
                AIModelResult.model_name == model_name
            )
        ).first()
    
class ObjectClassRepository:
    def __init__(self, db: Session):
        self.db = db
    
    def create(self, session_id: int, stage_id: int, class_name: str, 
               class_type: str, bounding_box: Dict = None, 
               center_point: Dict = None, orientation: str = None,
               start_point: Dict = None, end_point: Dict = None,
               dimensions: Dict = None, confidence_score: float = None,
               is_global: bool = False, parent_class_id: int = None,
               **kwargs) -> ObjectClass:
        """Create a single object class"""
        obj = ObjectClass(
            session_id=session_id,
            stage_id=stage_id,
            class_name=class_name,
            class_type=class_type,
            bounding_box=to_serializable(bounding_box),
            center_point=to_serializable(center_point),
            orientation=orientation,
            start_point=to_serializable(start_point),
            end_point=to_serializable(end_point),
            dimensions=to_serializable(dimensions),
            confidence_score=confidence_score,
            is_global=is_global,
            parent_class_id=parent_class_id,
            **kwargs
        )
        self.db.add(obj)
        self.db.commit()
        self.db.refresh(obj)
        return obj
    
    def create_batch(self, objects: List[Dict], session_id: int, 
                    stage_id: int) -> List[ObjectClass]:
        """Create multiple object classes"""
        object_instances = []
        for obj_data in objects:
            # Serialize nested dictionaries
            serialized_data = to_serializable(obj_data)
            obj = ObjectClass(
                session_id=session_id,
                stage_id=stage_id,
                **serialized_data
            )
            object_instances.append(obj)
        
        self.db.add_all(object_instances)
        self.db.commit()
        return object_instances
    
    def get_by_session(self, session_id: int) -> List[ObjectClass]:
        """Get all objects for a session"""
        return self.db.query(ObjectClass).filter(
            ObjectClass.session_id == session_id
        ).all()
    
    def get_by_stage(self, stage_id: int) -> List[ObjectClass]:
        """Get all objects for a stage"""
        return self.db.query(ObjectClass).filter(
            ObjectClass.stage_id == stage_id
        ).all()
    
    def get_global_objects(self, session_id: int) -> List[ObjectClass]:
        """Get global objects for a session"""
        return self.db.query(ObjectClass).filter(
            and_(
                ObjectClass.session_id == session_id,
                ObjectClass.is_global == True
            )
        ).all()

class DebugLogRepository:
    def __init__(self, db: Session):
        self.db = db

    def create(self, session_id: int, log_level: LogLevel,
           component: str, message: str,
           stage_id: int = None, stack_trace: str = None,
           log_data: Dict = None) -> DebugLog:
        """Create debug log entry"""
        log = DebugLog(
            session_id=session_id,
            stage_id=stage_id,
            log_level=log_level,
            component=component,
            message=message,
            stack_trace=stack_trace,
            log_data=to_serializable(log_data)
        )
        self.db.add(log)
        self.db.commit()
        self.db.refresh(log)
        return log

    def get_by_session(self, session_id: int, log_level: LogLevel = None) -> List[DebugLog]:
        """Get logs for a session"""
        query = self.db.query(DebugLog).filter(DebugLog.session_id == session_id)

        if log_level:
            query = query.filter(DebugLog.log_level == log_level)

        return query.order_by(desc(DebugLog.created_at)).all()

    def get_by_stage(self, stage_id: int) -> List[DebugLog]:
        """Get logs for a stage"""
        return self.db.query(DebugLog).filter(
            DebugLog.stage_id == stage_id
        ).order_by(desc(DebugLog.created_at)).all()

class ModelOutputRepository:
    def __init__(self, db: Session):
        self.db = db
    
    def create(self, session_id: int, output_type: str, 
               file_path: str, file_size_mb: float = None,
               generation_time_ms: int = None,
               blender_version: str = None,
               export_settings: Dict = None,
               quality_metrics: Dict = None) -> ModelOutput:
        """Create model output record"""
        output = ModelOutput(
            session_id=session_id,
            output_type=output_type,
            file_path=file_path,
            file_size_mb=file_size_mb,
            generation_time_ms=generation_time_ms,
            blender_version=blender_version,
            export_settings=to_serializable(export_settings),
            quality_metrics=to_serializable(quality_metrics)
        )
        self.db.add(output)
        self.db.commit()
        self.db.refresh(output)
        return output
    
    def get_by_session(self, session_id: int) -> List[ModelOutput]:
        """Get all outputs for a session"""
        return self.db.query(ModelOutput).filter(
            ModelOutput.session_id == session_id
        ).all()
    
    def get_by_id(self, output_id: int) -> Optional[ModelOutput]:
        """Get output by ID"""
        return self.db.query(ModelOutput).filter(
            ModelOutput.id == output_id
        ).first()