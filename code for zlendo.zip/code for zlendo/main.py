# main.py

import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database_manager import db_manager
import api_projects, api_sessions, api_visualization, api_models
from api_exports import router as exports_router

from api_flutter_exports import router as flutter_router
from services import asset_service

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app instance
app = FastAPI(
    title="2D Floorplan to 3D Model API",
    description="Backend service to convert 2D floorplan images into 3D models with integrated legacy support.",
    version="2.1.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins for simplicity, restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Event Handlers ---
@app.on_event("startup")
def startup_event():
    """Actions to perform on application startup."""
    logger.info("Starting up the application...")
    try:
        # Create database tables if they don't exist
        db_manager.create_tables()
        logger.info("Database tables verified/created successfully.")
        
        # Log available endpoints
        logger.info("Available API endpoints:")
        logger.info("- Project Management: /api/v2_yolo/projects/")
        logger.info("- AI & Processing Sessions: /api/v2_yolo/sessions/")
        logger.info("- Visualization: /api/v2_yolo/visualization/")
        logger.info("- 3D Model Generation: /api/v2_yolo/models/")
        logger.info("- Floorplan Processing: /api/v2_yolo/floorplans/")
        logger.info("- Exports: /api/v2_yolo/exports/")
        
    except Exception as e:
        logger.error(f"Error during startup creating database tables: {e}")
        # Depending on the severity, you might want to exit the application
        # raise e

@app.on_event("shutdown")
def shutdown_event():
    """Actions to perform on application shutdown."""
    logger.info("Shutting down the application...")
    # Add any cleanup tasks here if needed

# --- API Routers ---
# Include routers from the API files
app.include_router(api_projects.router, prefix="/api/v2_yolo", tags=["1. Project Management"])
app.include_router(api_sessions.router, prefix="/api/v2_yolo", tags=["2. AI & Processing Sessions"])
app.include_router(api_visualization.router, prefix="/api/v2_yolo", tags=["3. Visualization"])
app.include_router(api_models.router, prefix="/api/v2_yolo", tags=["4. 3D Model Generation"])
app.include_router(exports_router, prefix="/api/v2_yolo")
app.include_router(flutter_router, prefix="/api/v2", tags=["Flutter Exports"])

# --- Root Endpoint ---
@app.get("/", tags=["Root"])
def read_root():
    """Root endpoint providing basic API information."""
    return {
        "message": "Welcome to the 2D Floorplan to 3D Model API",
        "version": "2.1.0",
        "documentation": "/docs",
        "features": [
            "Project Management with legacy floorplan support",
            "AI-powered processing sessions",
            "JSON stage tracking and synchronization",
            "3D model generation and export",
            "Comprehensive visualization tools",
            "Legacy data migration support"
        ],
        "endpoints": {
            "projects": "/api/v2_yolo/projects/",
            "sessions": "/api/v2_yolo/sessions/",
            "visualization": "/api/v2_yolo/visualization/",
            "models": "/api/v2_yolo/models/",
            "floorplans": "/api/v2_yolo/floorplans/",
            "exports": "/api/v2_yolo/exports/"
        }
    }

# Health check endpoint
@app.get("/health", tags=["Health"])
def health_check():
    """Health check endpoint for monitoring."""
    return {"status": "healthy", "timestamp": "2025-01-31T12:00:00Z"}

# Migration endpoint
@app.post("/migrate-legacy", tags=["Migration"])
def migrate_legacy_floorplan_data():
    """Migrate legacy floorplan_processings data to new integrated schema."""
    try:
        with db_manager.get_session() as db:
            results = db_manager.migrate_legacy_floorplan_data(db)
            return {
                "message": "Legacy migration completed successfully",
                "results": results,
                "status": "success"
            }
    except Exception as e:
        logger.error(f"Migration error: {str(e)}")
        return {
            "message": "Legacy migration failed",
            "error": str(e),
            "status": "error"
        }

# To run this application:
# uvicorn main:app --reload