# api_exports.py - Updated with direct file access route

import os
import json
import logging
from collections import OrderedDict
from datetime import datetime
from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import JSONResponse, FileResponse
from sqlalchemy.orm import Session
from repositories import ProjectRepository

from database_manager import get_db
from repositories import ProcessingSessionRepository, JSONStageRepository

router = APIRouter()
logger = logging.getLogger("api")

EXPORTS_DIRECTORY = os.getenv("EXPORTS_PATH", "exports")
os.makedirs(EXPORTS_DIRECTORY, exist_ok=True)

def create_2layer_json_structure(raw_data: dict, session_id: int) -> dict:
    """
    Create the standardized 2layer JSON structure from raw data.
    """
    if "layers" not in raw_data or "layer-1" not in raw_data["layers"]:
        raise ValueError("Missing layers or layer-1 in final JSON")

    layer = raw_data["layers"]["layer-1"]

    # Construct final JSON with exact field order for 2layer compatibility
    final_json = OrderedDict()
    final_json["unit"] = "cm"
    final_json["layers"] = {
        "layer-1": OrderedDict({
            "id": "layer-1",
            "altitude": 0,
            "order": 0,
            "opacity": 1,
            "name": "default",
            "visible": True,
            "vertices": layer.get("vertices", {}),
            "lines": layer.get("lines", {}),
            "holes": layer.get("holes", {}),
            "items": layer.get("items", {}),
            "areas": layer.get("areas", {})
        })
    }
    final_json["grids"] = {
        "h1": {
            "id": "h1",
            "type": "horizontal-streak",
            "properties": {
                "step": 20,
                "colors": ["#808080", "#ddd", "#ddd", "#ddd", "#ddd"]
            }
        },
        "v1": {
            "id": "v1",
            "type": "vertical-streak",
            "properties": {
                "step": 20,
                "colors": ["#808080", "#ddd", "#ddd", "#ddd", "#ddd"]
            }
        }
    }
    final_json["selectedLayer"] = "layer-1"
    final_json["groups"] = {}
    final_json["width"] = 4000
    final_json["height"] = 4000
    final_json["meta"] = {
        "generated_by": "AI_Processing_Pipeline_v2.1",
        "session_id": session_id,
        "export_timestamp": datetime.now().isoformat(),
        "format_version": "2.1"
    }
    final_json["guides"] = {
        "horizontal": {},
        "vertical": {},
        "circular": {}
    }

    return final_json

def ensure_export_file_exists(session_id: int, db: Session) -> str:
    """
    Ensure the export file exists, create it if it doesn't.
    Returns the file path.
    """
    session_repo = ProcessingSessionRepository(db)
    stage_repo = JSONStageRepository(db)
    
    # Check if export file already exists
    session = session_repo.get_by_id(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    if session.export_file_path and os.path.exists(session.export_file_path):
        return session.export_file_path
    
    # Create export file if it doesn't exist
    if session.status.value != "completed":
        raise HTTPException(
            status_code=400, 
            detail=f"Session status is '{session.status.value}', must be 'completed' to export"
        )
    
    # Get the final stage JSON (stage 4)
    final_stage = stage_repo.get_by_session_and_stage(session_id, 4)
    if not final_stage or not final_stage.output_json:
        raise HTTPException(
            status_code=404, 
            detail="Final validated JSON (Stage 4) not found for this session"
        )

    # Create the 2layer structure
    final_json = create_2layer_json_structure(final_stage.output_json, session_id)

    # Create the export file
    file_path = os.path.join(EXPORTS_DIRECTORY, f"session_{session_id}_final.json")
    
    with open(file_path, "w") as f:
        json.dump(final_json, f, indent=2)
    
    # Get file size
    file_size = os.path.getsize(file_path)
    
    # Update session with export information
    session_repo.update_export_info(
        session_id=session_id,
        export_file_path=file_path,
        export_file_size_bytes=file_size,
        export_format_version="2.1"
    )
    
    logger.info(f"Export file created: {file_path} ({file_size} bytes)")
    return file_path


@router.get("/session_{session_id}_final.json", summary="Direct download of session export file")
def download_session_file_direct(session_id: int, db: Session = Depends(get_db)):
    """
    Direct download route matching the URL pattern: /exports/session_{id}_final.json
    Uses session_id directly to locate and return the export file.
    """
    try:
        # Locate the export path using session_id
        file_path = ensure_export_file_exists(session_id=session_id, db=db)

        logger.info(f"Direct download requested for session {session_id}: {file_path}")

        return FileResponse(
            path=file_path,
            filename=f"session_{session_id}_final.json",
            media_type="application/json"
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in direct download for session {session_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Download failed: {str(e)}")


from fastapi.responses import FileResponse
from fastapi import Header

@router.get("/sessions/{session_id}/download", summary="Download final 2layer JSON")
def download_final_output(session_id: int, db: Session = Depends(get_db)):
    """
    Download final 2layer JSON using session_id directly.
    Forces file download instead of displaying raw JSON.
    """
    try:
        # Locate the export path using session_id
        file_path = ensure_export_file_exists(session_id=session_id, db=db)

        # Update last accessed timestamp (optional)
        session_repo = ProcessingSessionRepository(db)
        session_repo.update_export_access(session_id)

        return FileResponse(
            path=file_path,
            filename=f"session_{session_id}_final.json",
            media_type="application/json",
            headers={
                "Content-Disposition": f"attachment; filename=session_{session_id}_final.json"
            }
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading file for session {session_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Download failed: {str(e)}")




from fastapi.responses import FileResponse

@router.get("/projects/{project_id}/download-original")
def download_original_image(project_id: int, db: Session = Depends(get_db)):
    """
    Download the original uploaded image for a project.
    """
    try:
        project_repo = ProjectRepository(db)
        project = project_repo.get_by_id(project_id)

        if not project:
            raise HTTPException(status_code=404, detail="Project not found")

        if not project.original_image_path or not os.path.exists(project.original_image_path):
            raise HTTPException(status_code=404, detail="Original image not found")

        filename = os.path.basename(project.original_image_path)

        return FileResponse(
            path=project.original_image_path,
            filename=filename,
            media_type='image/*'
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading original image for project {project_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Download failed: {str(e)}")

from fastapi.responses import FileResponse
from repositories import ProcessingSessionRepository

@router.get("/sessions/{session_id}/download-original")
def download_original_image_by_session(session_id: int, db: Session = Depends(get_db)):
    """
    Download the original uploaded image for a given session.
    """
    try:
        # Step 1: Get the session
        session_repo = ProcessingSessionRepository(db)
        processing_session = session_repo.get_by_id(session_id)

        if not processing_session:
            raise HTTPException(status_code=404, detail="Processing session not found")

        # Step 2: Get the related project
        project = processing_session.project
        if not project:
            raise HTTPException(status_code=404, detail="Project not found for this session")

        # Step 3: Check the original image path
        if not project.original_image_path or not os.path.exists(project.original_image_path):
            raise HTTPException(status_code=404, detail="Original image not found")

        filename = os.path.basename(project.original_image_path)

        return FileResponse(
            path=project.original_image_path,
            filename=filename,
            media_type='image/*'
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading original image for session {session_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Download failed: {str(e)}")


@router.get("/projects/{session_id}/export-info", summary="Get export file information")
def get_export_info(session_id: int, db: Session = Depends(get_db)):
    """
    Get information about the export file for a session without downloading it.
    """
    session_repo = ProcessingSessionRepository(db)
    session = session_repo.get_by_id(session_id)
    
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    # Check if file actually exists on disk
    file_exists = bool(session.export_file_path and os.path.exists(session.export_file_path))
    
    export_info = {
        "session_id": session_id,
        "export_available": file_exists,
        "export_file_path": session.export_file_path,
        "export_created_at": session.export_created_at,
        "export_file_size_bytes": session.export_file_size_bytes,
        "export_file_size_mb": round(session.export_file_size_bytes / (1024 * 1024), 2) if session.export_file_size_bytes else None,
        "export_format_version": session.export_format_version,
        "session_status": session.status.value,
        "can_export": session.status.value == "completed",
        "file_exists_on_disk": file_exists
    }
    
    return export_info

@router.post("/projects/{session_id}/regenerate-export", summary="Regenerate export file")
def regenerate_export(session_id: int, db: Session = Depends(get_db)):
    """
    Force regeneration of the export file, even if it already exists.
    """
    session_repo = ProcessingSessionRepository(db)
    stage_repo = JSONStageRepository(db)
    
    session = session_repo.get_by_id(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    if session.status.value != "completed":
        raise HTTPException(
            status_code=400, 
            detail=f"Session must be completed to regenerate export"
        )
    
    # Remove existing export file if it exists
    if session.export_file_path and os.path.exists(session.export_file_path):
        try:
            os.remove(session.export_file_path)
            logger.info(f"Removed existing export file: {session.export_file_path}")
        except Exception as e:
            logger.warning(f"Failed to remove existing export file: {e}")
    
    # Clear export info from database
    session_repo.clear_export_info(session_id)
    
    # Get the final stage JSON and regenerate
    try:
        final_stage = stage_repo.get_by_session_and_stage(session_id, 4)
        if not final_stage or not final_stage.output_json:
            raise HTTPException(
                status_code=404, 
                detail="Final validated JSON (Stage 4) not found for this session"
            )

        # Create the 2layer structure
        final_json = create_2layer_json_structure(final_stage.output_json, session_id)

        # Create new export file
        file_path = os.path.join(EXPORTS_DIRECTORY, f"session_{session_id}_final.json")
        
        with open(file_path, "w") as f:
            json.dump(final_json, f, indent=2)
        
        file_size = os.path.getsize(file_path)
        
        # Update database
        session_repo.update_export_info(
            session_id=session_id,
            export_file_path=file_path,
            export_file_size_bytes=file_size,
            export_format_version="2.1"
        )
        
        return {
            "message": "Export file regenerated successfully",
            "file_path": file_path,
            "file_size_bytes": file_size,
            "file_size_mb": round(file_size / (1024 * 1024), 2)
        }
        
    except Exception as e:
        logger.error(f"Failed to regenerate export: {e}")
        raise HTTPException(status_code=500, detail=f"Export regeneration failed: {str(e)}")

@router.delete("/projects/{session_id}/export", summary="Delete export file")
def delete_export(session_id: int, db: Session = Depends(get_db)):
    """
    Delete the export file and clear export information from database.
    """
    session_repo = ProcessingSessionRepository(db)
    session = session_repo.get_by_id(session_id)
    
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    deleted = False
    
    # Remove export file if it exists
    if session.export_file_path and os.path.exists(session.export_file_path):
        try:
            os.remove(session.export_file_path)
            deleted = True
            logger.info(f"Deleted export file: {session.export_file_path}")
        except Exception as e:
            logger.error(f"Failed to delete export file: {e}")
            raise HTTPException(status_code=500, detail="Failed to delete export file")
    
    # Clear export info from database
    session_repo.clear_export_info(session_id)
    
    if deleted:
        return {"message": "Export file deleted successfully"}
    else:
        return {"message": "No export file found to delete"}

@router.get("/exports/cleanup", summary="Clean up orphaned export files")
def cleanup_exports(db: Session = Depends(get_db)):
    """
    Clean up export files that exist on disk but are not referenced in the database.
    Admin endpoint for maintenance.
    """
    session_repo = ProcessingSessionRepository(db)
    
    try:
        cleanup_count = 0
        total_size_cleaned = 0
        
        # Get all export files on disk
        if os.path.exists(EXPORTS_DIRECTORY):
            for filename in os.listdir(EXPORTS_DIRECTORY):
                if filename.startswith("session_") and filename.endswith("_final.json"):
                    file_path = os.path.join(EXPORTS_DIRECTORY, filename)
                    
                    # Extract session ID from filename
                    try:
                        session_id = int(filename.split("_")[1])
                        session = session_repo.get_by_id(session_id)
                        
                        # If session doesn't exist or doesn't reference this file
                        if not session or session.export_file_path != file_path:
                            file_size = os.path.getsize(file_path)
                            os.remove(file_path)
                            cleanup_count += 1
                            total_size_cleaned += file_size
                            logger.info(f"Cleaned up orphaned export file: {file_path}")
                            
                    except (ValueError, IndexError):
                        # Invalid filename format, skip
                        continue
        
        return {
            "message": f"Cleanup completed. Removed {cleanup_count} orphaned files.",
            "files_cleaned": cleanup_count,
            "bytes_cleaned": total_size_cleaned,
            "mb_cleaned": round(total_size_cleaned / (1024 * 1024), 2)
        }
        
    except Exception as e:
        logger.error(f"Export cleanup failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Cleanup failed")

@router.post("/projects/{session_id}/check-and-fix-export", summary="Check and fix export file issues")
def check_and_fix_export(session_id: int, db: Session = Depends(get_db)):
    """
    Debug endpoint to check export file status and fix common issues.
    """
    session_repo = ProcessingSessionRepository(db)
    stage_repo = JSONStageRepository(db)
    
    session = session_repo.get_by_id(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    issues_found = []
    fixes_applied = []
    
    # Check if session is completed
    if session.status.value != "completed":
        issues_found.append(f"Session status is '{session.status.value}', not 'completed'")
    
    # Check if Stage 4 exists
    final_stage = stage_repo.get_by_session_and_stage(session_id, 4)
    if not final_stage:
        issues_found.append("Stage 4 (final validation) not found in database")
    elif not final_stage.output_json:
        issues_found.append("Stage 4 exists but has no output JSON")
    
    # Check export file path in database
    if not session.export_file_path:
        issues_found.append("No export file path recorded in database")
    elif not os.path.exists(session.export_file_path):
        issues_found.append(f"Export file path recorded ({session.export_file_path}) but file doesn't exist")
    
    # Check if export file exists on disk but not recorded
    expected_path = os.path.join(EXPORTS_DIRECTORY, f"session_{session_id}_final.json")
    if not session.export_file_path and os.path.exists(expected_path):
        issues_found.append("Export file exists on disk but not recorded in database")
        
        # Fix: Update database with existing file
        try:
            file_size = os.path.getsize(expected_path)
            session_repo.update_export_info(
                session_id=session_id,
                export_file_path=expected_path,
                export_file_size_bytes=file_size,
                export_format_version="2.1"
            )
            fixes_applied.append("Updated database with existing export file information")
        except Exception as e:
            issues_found.append(f"Failed to update database: {e}")
    
    # If we can create the export file, do it
    if (session.status.value == "completed" and 
        final_stage and final_stage.output_json and 
        not os.path.exists(expected_path)):
        
        try:
            final_json = create_2layer_json_structure(final_stage.output_json, session_id)
            
            with open(expected_path, "w") as f:
                json.dump(final_json, f, indent=2)
            
            file_size = os.path.getsize(expected_path)
            
            session_repo.update_export_info(
                session_id=session_id,
                export_file_path=expected_path,
                export_file_size_bytes=file_size,
                export_format_version="2.1"
            )
            
            fixes_applied.append(f"Created missing export file: {expected_path}")
            
        except Exception as e:
            issues_found.append(f"Failed to create export file: {e}")
    
    return {
        "session_id": session_id,
        "session_status": session.status.value,
        "issues_found": issues_found,
        "fixes_applied": fixes_applied,
        "export_info": {
            "file_path": session.export_file_path,
            "file_exists": bool(session.export_file_path and os.path.exists(session.export_file_path)),
            "file_size_bytes": session.export_file_size_bytes,
            "created_at": session.export_created_at
        }
    }