import os
import trimesh
from typing import Dict, Optional, List, Any

class ModelConverter:
    @staticmethod
    def convert_model(input_path: str, output_path: str, output_format: str) -> bool:
        """Convert between 3D model formats"""
        if not os.path.exists(input_path):
            raise FileNotFoundError(f"Input file not found: {input_path}")

        try:
            mesh = trimesh.load(input_path)
            if isinstance(mesh, trimesh.Scene):
                mesh = mesh.dump(concatenate=True)
            
            mesh.export(output_path, file_type=output_format)
            return os.path.exists(output_path)
        except Exception as e:
            raise Exception(f"Failed to convert model: {str(e)}")

    @staticmethod
    def get_supported_formats() -> Dict[str, str]:
        """Get supported conversion formats"""
        return {
            'glb': 'Binary glTF',
            'gltf': 'glTF',
            'obj': 'Wavefront OBJ',
            'ply': 'Stanford PLY',
            'stl': 'STL',
            'fbx': 'FBX (limited support)'
        }

    @staticmethod
    def validate_model(file_path: str) -> Dict[str, Any]:
        """Validate a 3D model file"""
        try:
            mesh = trimesh.load(file_path)
            return {
                'valid': True,
                'format': os.path.splitext(file_path)[1][1:].lower(),
                'vertices': len(mesh.vertices) if hasattr(mesh, 'vertices') else 0,
                'faces': len(mesh.faces) if hasattr(mesh, 'faces') else 0,
                'is_watertight': mesh.is_watertight if hasattr(mesh, 'is_watertight') else False,
                'bounds': mesh.bounds.tolist() if hasattr(mesh, 'bounds') else None
            }
        except Exception as e:
            return {
                'valid': False,
                'error': str(e)
            }