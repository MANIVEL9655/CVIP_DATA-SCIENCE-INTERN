# spatial_optimizer.py

"""
Spatial Optimizer - Stage 3 of the refinement pipeline
Focuses on spatial relationship validation and positioning optimization
"""

import json
import logging
import time
from typing import Dict, List, Any, Tuple, Optional
from dataclasses import dataclass, field
from enum import Enum
import math
import numpy as np
from datetime import datetime

from database_manager import DatabaseManager
from models import ProcessingSession, JSONStage, ObjectClass, DebugLog

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class Point:
    x: float
    y: float
    def distance_to(self, other: 'Point') -> float: return math.sqrt((self.x - other.x)**2 + (self.y - other.y)**2)
    def to_numpy(self): return np.array([self.x, self.y])

@dataclass
class BoundingBox:
    x1: float; y1: float; x2: float; y2: float

@dataclass
class DetectedObject:
    id: str; class_name: str; class_type: str; bounding_box: BoundingBox; center_point: Point;
    orientation: str; start_point: Point; end_point: Point; dimensions: Dict[str, float];
    confidence_score: float; attributes: Dict[str, Any] = field(default_factory=dict)

class SpatialOptimizer:
    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager
        self.stage_name = "spatial_optimization"
        self.stage_number = 3
        self.stage_type = "local"
        
        self.T_JUNCTION_THRESHOLD = 25
        self.DOOR_WALL_CONNECTION_TOLERANCE = 15.0
        self.WINDOW_WALL_CONNECTION_TOLERANCE = 15.0

    def process_stage(self, session_id: int, input_json: Dict[str, Any]) -> Dict[str, Any]:
        start_time = time.time()
        try:
            logger.info(f"Starting spatial optimization for session {session_id}")
            
            detected_objects = self._parse_input_json(input_json)
            output_json = self._initialize_output_json(input_json)
            
            optimized_objects = self._close_t_junction_gaps(detected_objects, session_id)
            optimized_objects = self._optimize_opening_connections(optimized_objects, 'door', self.DOOR_WALL_CONNECTION_TOLERANCE, session_id)
            optimized_objects = self._optimize_opening_connections(optimized_objects, 'window', self.WINDOW_WALL_CONNECTION_TOLERANCE, session_id)
            
            output_json['detected_objects'] = [self._object_to_dict(obj) for obj in optimized_objects]
            
            processing_time = int((time.time() - start_time) * 1000)
            
            self._save_stage_result(session_id, input_json, output_json, processing_time)
            
            logger.info(f"Spatial optimization completed for session {session_id}")
            
            return {
                "json_output": output_json,
                "processing_time_ms": processing_time
            }
            
        except Exception as e:
            logger.error(f"Error in spatial optimization for session {session_id}: {str(e)}", exc_info=True)
            self._log_error(session_id, "spatial_optimization", str(e))
            raise

    def _parse_input_json(self, input_json: Dict[str, Any]) -> List[DetectedObject]:
        objects = []
        for obj_data in input_json.get('detected_objects', []):
            try:
                objects.append(DetectedObject(
                    id=obj_data['id'], class_name=obj_data['class_name'], class_type=obj_data['class_type'],
                    bounding_box=BoundingBox(**obj_data['bounding_box']),
                    center_point=Point(**obj_data['center_point']), orientation=obj_data['orientation'],
                    start_point=Point(**obj_data['start_point']), end_point=Point(**obj_data['end_point']),
                    dimensions=obj_data['dimensions'], confidence_score=obj_data['confidence_score'],
                    attributes=obj_data.get('attributes', {})
                ))
            except (KeyError, TypeError) as e:
                logger.warning(f"Skipping malformed object in spatial optimizer: {e}")
        return objects
    
    def _initialize_output_json(self, input_json: Dict[str, Any]) -> Dict[str, Any]:
        output_json = input_json.copy()
        output_json['metadata']['stage_number'] = self.stage_number
        output_json['metadata']['stage_name'] = self.stage_name
        output_json['metadata']['timestamp'] = datetime.now().isoformat()
        output_json['refinement_metadata'] = {
            "stage_number": self.stage_number, "stage_name": self.stage_name, "refinement_type": "spatial",
            "parent_stage_number": input_json.get('metadata', {}).get('stage_number'),
        }
        return output_json
        
    def _close_t_junction_gaps(self, objects: List[DetectedObject], session_id: int) -> List[DetectedObject]:
        walls = [obj for obj in objects if obj.class_name == 'wall']
        
        for wall_to_fix in walls:
            for is_start_node in [True, False]:
                p_check = wall_to_fix.start_point if is_start_node else wall_to_fix.end_point
                
                is_connected = any(
                    p_check.distance_to(other.start_point) < 2 or p_check.distance_to(other.end_point) < 2
                    for other in walls if other.id != wall_to_fix.id
                )
                if is_connected: continue

                best_projection, min_dist = None, self.T_JUNCTION_THRESHOLD
                for target_wall in walls:
                    if target_wall.id == wall_to_fix.id or self._get_orientation(wall_to_fix) == self._get_orientation(target_wall):
                        continue
                    
                    proj_point = self._project_point_to_line(p_check, target_wall.start_point, target_wall.end_point)
                    dist = p_check.distance_to(proj_point)

                    if dist < min_dist:
                        min_dist, best_projection = dist, proj_point
                
                if best_projection:
                    if is_start_node: wall_to_fix.start_point = best_projection
                    else: wall_to_fix.end_point = best_projection
                    self._log_modification(session_id, wall_to_fix.id, "position", "t_junction_closure")
        
        return objects

    def _optimize_opening_connections(self, objects: List[DetectedObject], opening_type: str, tolerance: float, session_id: int) -> List[DetectedObject]:
        openings = [obj for obj in objects if obj.class_name == opening_type]
        walls = [obj for obj in objects if obj.class_name == 'wall']
        
        for opening in openings:
            closest_wall, min_distance = None, float('inf')
            for wall in walls:
                dist = self._point_to_line_distance(opening.center_point, wall.start_point, wall.end_point)
                if dist < min_distance:
                    min_distance, closest_wall = dist, wall
            
            if closest_wall and 1.0 < min_distance < tolerance:
                proj_point = self._project_point_to_line(opening.center_point, closest_wall.start_point, closest_wall.end_point)
                dx, dy = proj_point.x - opening.center_point.x, proj_point.y - opening.center_point.y
                self._move_object(opening, dx, dy)
                self._log_modification(session_id, opening.id, "position", f"{opening_type}_wall_connection")
        return objects

    def _move_object(self, obj: DetectedObject, dx: float, dy: float):
        obj.center_point.x += dx; obj.center_point.y += dy
        obj.start_point.x += dx; obj.start_point.y += dy
        obj.end_point.x += dx; obj.end_point.y += dy
        bbox = obj.bounding_box
        obj.bounding_box = BoundingBox(bbox.x1 + dx, bbox.y1 + dy, bbox.x2 + dx, bbox.y2 + dy)

    def _get_orientation(self, obj: DetectedObject) -> str:
        dx = abs(obj.end_point.x - obj.start_point.x)
        dy = abs(obj.end_point.y - obj.start_point.y)
        return 'horizontal' if dx > dy else 'vertical'

    def _project_point_to_line(self, point: Point, line_start: Point, line_end: Point) -> Point:
        line_vec = line_end.to_numpy() - line_start.to_numpy()
        point_vec = point.to_numpy() - line_start.to_numpy()
        line_len_sq = np.dot(line_vec, line_vec)
        if line_len_sq < 1e-6: return line_start
        t = max(0, min(1, np.dot(point_vec, line_vec) / line_len_sq))
        return Point(*(line_start.to_numpy() + t * line_vec))

    def _point_to_line_distance(self, point: Point, line_start: Point, line_end: Point) -> float:
        return point.distance_to(self._project_point_to_line(point, line_start, line_end))
    
    def _object_to_dict(self, obj: DetectedObject) -> Dict[str, Any]:
        return {
            'id': obj.id, 'class_name': obj.class_name, 'class_type': obj.class_type,
            'bounding_box': {'x1': obj.bounding_box.x1, 'y1': obj.bounding_box.y1, 'x2': obj.bounding_box.x2, 'y2': obj.bounding_box.y2},
            'center_point': {'x': obj.center_point.x, 'y': obj.center_point.y},
            'orientation': obj.orientation,
            'start_point': {'x': obj.start_point.x, 'y': obj.start_point.y},
            'end_point': {'x': obj.end_point.x, 'y': obj.end_point.y},
            'dimensions': obj.dimensions, 'confidence_score': obj.confidence_score, 'attributes': obj.attributes
        }
        
    def _save_stage_result(self, session_id: int, input_json: Dict[str, Any], output_json: Dict[str, Any], processing_time: int):
        try:
            detected_objects = output_json.get('detected_objects', [])
            confidence_scores = {}
            if detected_objects:
                scores = [obj['confidence_score'] for obj in detected_objects if 'confidence_score' in obj]
                if scores:
                    confidence_scores = {
                        'average_confidence': np.mean(scores), 'min_confidence': min(scores), 'max_confidence': max(scores),
                    }
            
            with self.db_manager.get_session() as db:
                stage_data = {
                    'session_id': session_id, 'stage_number': self.stage_number, 'stage_name': self.stage_name,
                    'stage_type': self.stage_type, 'input_json': input_json, 'output_json': output_json,
                    'processing_time_ms': processing_time, 'confidence_scores': confidence_scores, 'status': 'completed'
                }
                self.db_manager.save_json_stage(db, stage_data)
            logger.info(f"Stage {self.stage_number} results saved for session {session_id}")
            
        except Exception as e:
            logger.error(f"Error saving stage {self.stage_number} results for session {session_id}: {str(e)}", exc_info=True)
            raise

    def _log_modification(self, session_id: int, object_id: str, modification_type: str, reason: str):
        try:
            with self.db_manager.get_session() as db:
                self.db_manager.save_debug_log(db=db, session_id=session_id, log_level='info', component='spatial_optimizer',
                                               message=f"Modified object {object_id}: {modification_type} - {reason}")
        except Exception as e:
            logger.error(f"Error logging modification: {e}")
        
    def _log_error(self, session_id: int, component: str, error_message: str):
        try:
            with self.db_manager.get_session() as db:
                self.db_manager.save_debug_log(db=db, session_id=session_id, log_level='error', component=component,
                                               message=error_message)
        except Exception as e:
            logger.error(f"Error logging error: {e}")