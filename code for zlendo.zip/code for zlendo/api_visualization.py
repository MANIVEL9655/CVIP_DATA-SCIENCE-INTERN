# api_visualization.py

import logging
import os
from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.orm import Session
from typing import Dict, Any
from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
import os
import glob

from database_manager import get_db
from repositories import JSONStageRepository, ProjectRepository, ProcessingSessionRepository
from visualization_service import VisualizationService

logger = logging.getLogger(__name__)
router = APIRouter()

# @router.get("/sessions/{session_id}/visualization/stage/{stage_number}", response_class=Response)
# def visualize_stage_results(session_id: int, stage_number: int, db: Session = Depends(get_db)):
#     """
#     Generate a debug visualization image for a specific processing stage.
#     """
#     session = ProcessingSessionRepository(db).get_by_id(session_id)
#     if not session:
#         raise HTTPException(status_code=404, detail="Session not found")

#     project = ProjectRepository(db).get_by_id(session.project_id)
#     if not project or not project.original_image_path or not os.path.exists(project.original_image_path):
#         raise HTTPException(status_code=404, detail="Original project image not found")

#     stage = JSONStageRepository(db).get_by_session_and_stage(session_id, stage_number)
#     if not stage or not stage.output_json:
#         raise HTTPException(status_code=404, detail=f"Data for stage {stage_number} not found")

#     try:
#         visualizer = VisualizationService()
#         image_bytes = visualizer.draw_stage_output(
#             image_path=project.original_image_path,
#             stage_json=stage.output_json
#         )
#         return Response(content=image_bytes, media_type="image/png")
#     except Exception as e:
#         logger.error(f"Failed to generate visualization for session {session_id}, stage {stage_number}: {e}", exc_info=True)
#         raise HTTPException(status_code=500, detail="Failed to generate visualization")


@router.get("/sessions/{session_id}/visualization/stage/{stage_number}", response_class=FileResponse)
def visualize_stage_results(session_id: int, stage_number: int, db: Session = Depends(get_db)):
    """
    Serve the PNG visualization image for a specific processing stage.
    """
    session = ProcessingSessionRepository(db).get_by_id(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    project = ProjectRepository(db).get_by_id(session.project_id)
    if not project or not os.path.exists(project.original_image_path):
        raise HTTPException(status_code=404, detail="Original image not found")

    stage = JSONStageRepository(db).get_by_session_and_stage(session_id, stage_number)
    if not stage or not stage.output_json:
        raise HTTPException(status_code=404, detail="Stage output not found")

    # Map stage number to filename
    stage_filename_map = {
        1: "01_global_detection.png",
        2: "02_refinement.png",
        3: "03_spatial_optimization.png",
        4: "04_final_output.png",  # matches visualize_final_2layer()
    }

    filename = stage_filename_map.get(stage_number)
    if not filename:
        raise HTTPException(status_code=400, detail="Unsupported stage number")

    file_path = os.path.join("session_visualizations", str(session_id), filename)

    if not os.path.exists(file_path):
        # If not already generated, do it now
        visualizer = VisualizationService()
        if stage_number == 4:
            visualizer.visualize_final_2layer(session_id, stage.output_json)
        else:
            visualizer.visualize_stage(session_id, filename.replace(".png", ""), stage.output_json)

    if not os.path.exists(file_path):
        raise HTTPException(status_code=500, detail="Visualization could not be created")

    return FileResponse(path=file_path, media_type="image/png", filename=filename)

    

VISUALIZATION_BASE_PATH = "session_visualizations"

@router.get("/visualization/{session_id}/", summary="List available visualizations")
def list_visualizations(session_id: int):
    """
    Returns a list of all .png visualization files available for a session.
    """
    session_path = os.path.join(VISUALIZATION_BASE_PATH, str(session_id))
    if not os.path.exists(session_path):
        raise HTTPException(status_code=404, detail="Session not found")

    png_files = sorted([
        os.path.basename(f)
        for f in glob.glob(os.path.join(session_path, "*.png"))
    ])

    return {
        "session_id": session_id,
        "visualizations": png_files
    }

@router.get("/visualization/{session_id}/{filename}", response_class=FileResponse, summary="Get visualization image")
def get_visualization(session_id: int, filename: str):
    """
    Fetch a specific visualization image (e.g., '04_final_output.png') for a session.
    """
    session_path = os.path.join(VISUALIZATION_BASE_PATH, str(session_id))
    file_path = os.path.join(session_path, filename)

    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Visualization file not found")

    return FileResponse(path=file_path, media_type="image/png", filename=filename)