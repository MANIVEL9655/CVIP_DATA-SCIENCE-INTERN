# file: api_flutter_exports.py

import logging
import os
import copy
import json
import math
from fastapi import APIRouter, Depends, HTTPException, File, UploadFile, Form, Body
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from typing import Dict, Any

# --- FIX 1: Imports moved to the top level ---
from database_manager import get_db, db_manager
from repositories import ProjectRepository, ProcessingSessionRepository, JSONStageRepository
from models import ImageFormat
from processing_pipeline import run_complete_pipeline_sync
from image_utils import (
    validate_image_file, 
    save_uploaded_file, 
    generate_safe_filename, 
    extract_image_metadata, 
    validate_file_for_processing, 
    ImageValidationError
)
from api_exports import create_2layer_json_structure
from services.asset_service import AssetService, get_asset_service

# Configure logging
logger = logging.getLogger(__name__)
router = APIRouter()

UPLOAD_DIRECTORY = os.getenv("UPLOAD_PATH", "./uploads")

# --- Helper functions (Unchanged) ---
HOLE_TYPE_TO_ASSET_NAME_MAP = {"Z_window": "Z_Window4", "Z_door": "Z_Door3"}

def _format_asset_urls(asset_data: dict) -> dict:
    if not asset_data: return {}
    urls, meta = asset_data.get("3D_asset_file_paths_urls", {}), asset_data.get("3D_asset_metadata", {})
    return {
        "GLB_File_URL": urls.get("GLB_File_URL"), "MTL_File_URL": urls.get("MTL_File_URL"),
        "OBJ_File_URL": urls.get("OBJ_File_URL"), "thumbnail_url": asset_data.get("2D_asset_thumbnail_url"),
        "texture_url": meta.get("texture_url")
    }

CEILING_HEIGHT_CM = 300.0
FLOOR_HEIGHT_CM = 0.0

FLUTTER_CANVAS_WIDTH = 40000
FLUTTER_CANVAS_HEIGHT = 40000

# Defines the starting offset (padding) from the bottom-left corner
FLUTTER_CANVAS_PADDING = 100.0

# DEFAULT_CEILING_ASSET_URLS = {
#     "texture_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture1/beige_wall_001_diff_4k.jpg",
#     "fallback_color": None
# }

DEFAULT_OUTER_WALL_FALLBACK_COLOR = None
DEFAULT_INNER_WALL_FALLBACK_COLOR = None
DEFAULT_CEILING_FALLBACK_COLOR = None
DEFAULT_FLOOR_FALLBACK_COLOR = None

# Textures for walls on the perimeter of the floor plan
# DEFAULT_OUTER_WALL_ASSET_URLS = {
#     "type": "outer_wall",
#     "roughness_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture3/brick_wall_10_rough_4k.exr",
#     "displacement_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture3/brick_wall_10_disp_4k.png",
#     "normal_gl_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture3/brick_wall_10_nor_gl_4k.exr",
#     "diffuse_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture3/brick_wall_10_diff_4k.jpg",
#     "ao_url": None,
#     "metallic_url":None,
#     "fallback_color": None 
# }
DEFAULT_OUTER_WALL_ASSET_URLS = [
    "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture3/brick_wall_10_rough_4k.exr",
    "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture3/brick_wall_10_disp_4k.png",
    "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture3/brick_wall_10_nor_gl_4k.exr",
    "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture3/brick_wall_10_diff_4k.jpg"
]

# Textures for internal walls separating rooms
# DEFAULT_INNER_WALL_ASSET_URLS = {
#     "type": "inner_wall",
#     "roughness_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture2/diagonal_parquet_rough_4k.exr",
#     "displacement_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture2/diagonal_parquet_disp_4k.png",
#     "normal_gl_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture2/diagonal_parquet_nor_gl_4k.exr",
#     "diffuse_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture2/diagonal_parquet_diff_4k.jpg",
#     "ao_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture2/diagonal_parquet_ao_4k.jpg",
#     "metallic_url": None,
#     "fallback_color": None
# }
DEFAULT_INNER_WALL_ASSET_URLS = [
    "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture2/diagonal_parquet_rough_4k.exr",
    "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture2/diagonal_parquet_disp_4k.png",
    "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture2/diagonal_parquet_nor_gl_4k.exr",
    "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture2/diagonal_parquet_diff_4k.jpg",
    "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture2/diagonal_parquet_ao_4k.jpg"
]

# DEFAULT_CEILING_URLS = {
#     "type": "ceiling",
#     "roughness_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture1/beige_wall_001_rough_4k.jpg",
#     "displacement_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture1/beige_wall_001_disp_4k.png",
#     "normal_gl_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture1/beige_wall_001_nor_gl_4k.exr",
#     "diffuse_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture1/beige_wall_001_diff_4k.jpg",
#     "ao_url": None,
#     "metallic_url": None,
#     "fallback_color": None
# }

DEFAULT_CEILING_URLS = [
    "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture1/beige_wall_001_rough_4k.jpg",
    "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture1/beige_wall_001_disp_4k.png",
    "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture1/beige_wall_001_nor_gl_4k.exr",
    "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture1/beige_wall_001_diff_4k.jpg"
]

# DEFAULT_FLOOR_URLS = {
#     "type": "floor",
#     "roughness_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture4/brick_wall_003_rough_4k.jpg",
#     "displacement_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture4/brick_wall_003_displacement_4k.png",
#     "normal_gl_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture4/brick_wall_003_nor_gl_4k.exr",
#     "diffuse_url": "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture4/brick_wall_003_diffuse_4k.jpg",
#     "ao_url": None,
#     "metallic_url": None,
#     "fallback_color": None
# }

DEFAULT_FLOOR_URLS = [
    "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture4/brick_wall_003_rough_4k.jpg",
    "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture4/brick_wall_003_displacement_4k.png",
    "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture4/brick_wall_003_nor_gl_4k.exr",
    "https://zrealtystoragedev.blob.core.windows.net/3dassets/textures/texture4/brick_wall_003_diffuse_4k.jpg"
]


def _unflip_flutter_json(flipped_json: dict) -> dict:
    if not flipped_json: return None
    unflipped_json = copy.deepcopy(flipped_json)
    canvas_height = unflipped_json.get("height", 4000)
    layer = unflipped_json.get("layers", {}).get("layer-1", {})
    for vertex in layer.get("vertices", {}).values():
        vertex["y"] = canvas_height - vertex["y"]
    for item in layer.get("items", {}).values():
        item["y"] = canvas_height - item["y"]
    logger.info(f"Corrected Y-coordinates for Flutter on {len(layer.get('vertices', {}))} vertices and {len(layer.get('items', {}))} items.")
    return unflipped_json

def _enrich_json_with_asset_urls(data: dict, asset_service: AssetService) -> dict:
    """
    Enriches the JSON with asset URLs. For walls, it provides both inner and outer
    texture sets nested under 'inner_texture' and 'outer_texture'.
    """
    if not data: return data
    layer = data.get("layers", {}).get("layer-1", {})
    if not layer: return data

    # Enrich 'items' (no change here)
    for item_data in layer.get("items", {}).values():
        asset_name = item_data.get("type")
        if asset_name:
            asset_info = asset_service.get_asset_by_name(asset_name)
            item_data["asset_urls"] = _format_asset_urls(asset_info) if asset_info else {}
            
    # --- MODIFIED LOGIC FOR WALLS ---
    # for line_data in layer.get("lines", {}).values():
    #     if line_data.get("type") == "wall":
    #         # Assign a dictionary containing both inner and outer texture sets
    #         line_data["asset_urls"] = {
    #             "inner_texture": DEFAULT_INNER_WALL_ASSET_URLS,
    #             "outer_texture": DEFAULT_OUTER_WALL_ASSET_URLS
    #         }

    for line_data in layer.get("lines", {}).values():
        if line_data.get("type") == "wall":
            line_data["asset_urls"] = {
                "inner": {
                    "textures": DEFAULT_INNER_WALL_ASSET_URLS,
                    "fallback_color": DEFAULT_INNER_WALL_FALLBACK_COLOR
                },
                "outer": {
                    "textures": DEFAULT_OUTER_WALL_ASSET_URLS,
                    "fallback_color": DEFAULT_OUTER_WALL_FALLBACK_COLOR
                }
            }
    # --- END MODIFIED LOGIC ---

    # Enrich 'holes' (no change here)
    for hole_data in layer.get("holes", {}).values():
        asset_name = HOLE_TYPE_TO_ASSET_NAME_MAP.get(hole_data.get("type"))
        if asset_name:
            asset_info = asset_service.get_asset_by_name(asset_name)
            hole_data["asset_urls"] = _format_asset_urls(asset_info) if asset_info else {}
    
    return data

def _add_floor_and_ceiling_properties_to_areas(flutter_json: dict) -> dict:
    """
    Adds both 'ceiling_properties' and 'floor_properties' directly into each 'area' object.
    Both surfaces will use the rich inner-wall texture set.
    """
    if not flutter_json:
        return None

    layer = flutter_json.get("layers", {}).get("layer-1", {})
    if not layer or "areas" not in layer:
        return flutter_json

    areas = layer.get("areas", {})
    logger.info(f"Adding floor and ceiling properties to {len(areas)} detected rooms...")

    # for area_data in areas.values():
    #     if len(area_data.get("vertices", [])) >= 3:
    #         # Add Ceiling Properties
    #         area_data["ceiling_properties"] = {
    #             "height": CEILING_HEIGHT_CM,
    #             "asset_urls": DEFAULT_CEILING_URLS  # Uses parquet texture
    #         }
    #         # Add Floor Properties
    #         area_data["floor_properties"] = {
    #             "height": FLOOR_HEIGHT_CM,
    #             "asset_urls": DEFAULT_FLOOR_URLS  # Uses parquet texture
    #         }
    for area_data in areas.values():
        if len(area_data.get("vertices", [])) >= 3:
            area_data["ceiling_properties"] = {
                "height": CEILING_HEIGHT_CM,
                "textures": DEFAULT_CEILING_URLS,
                "fallback_color": DEFAULT_CEILING_FALLBACK_COLOR
            }
            area_data["floor_properties"] = {
                "height": FLOOR_HEIGHT_CM,
                "textures": DEFAULT_FLOOR_URLS,
                "fallback_color": DEFAULT_FLOOR_FALLBACK_COLOR
            }
            
    # Clean up any old top-level keys if they exist
    if "ceilings" in layer:
        del layer["ceilings"]
    if "floor_properties" in layer:
        del layer["floor_properties"]
        
    return flutter_json

def _remap_coordinates_for_new_canvas(flutter_json: dict) -> dict:
    """
    Remaps all coordinates from the pipeline's canvas to a new, larger canvas
    with a specific bottom-left starting point (padding).
    """
    if not flutter_json:
        return None

    layer = flutter_json.get("layers", {}).get("layer-1", {})
    vertices = layer.get("vertices", {})
    items = layer.get("items", {})

    if not vertices:
        # If there are no vertices, just update the canvas size
        flutter_json["width"] = FLUTTER_CANVAS_WIDTH
        flutter_json["height"] = FLUTTER_CANVAS_HEIGHT
        return flutter_json

    # 1. Find the current bounding box of the entire plan
    all_x = [v["x"] for v in vertices.values()]
    all_y = [v["y"] for v in vertices.values()]
    min_x, min_y = min(all_x), min(all_y)

    # 2. Calculate the required translation to move the plan's corner to (100, 100)
    offset_x = FLUTTER_CANVAS_PADDING - min_x
    offset_y = FLUTTER_CANVAS_PADDING - min_y
    
    logger.info(f"Remapping coordinates with offset: (dx={offset_x:.2f}, dy={offset_y:.2f})")

    # 3. Apply the offset to all vertices
    for vertex in vertices.values():
        vertex["x"] += offset_x
        vertex["y"] += offset_y

    # 4. Apply the offset to all items
    for item in items.values():
        item["x"] += offset_x
        item["y"] += offset_y
        
    # 5. Update the main width and height of the canvas in the JSON
    flutter_json["width"] = FLUTTER_CANVAS_WIDTH
    flutter_json["height"] = FLUTTER_CANVAS_HEIGHT
    
    return flutter_json

def _is_outer_wall(line_data: dict, areas: dict) -> bool:
    """
    Determines if a wall is an outer (perimeter) wall by checking how many rooms share it.
    - 0 or 1 room -> Outer wall
    - 2 rooms -> Inner wall
    """
    wall_vertices = set(line_data.get("vertices", []))
    if len(wall_vertices) < 2:
        return True  # Treat incomplete lines as outer walls by default

    shared_area_count = 0
    for area_data in areas.values():
        area_vertices = area_data.get("vertices", [])
        # Check if the wall's vertices form an edge in this area's polygon
        for i in range(len(area_vertices)):
            v1 = area_vertices[i]
            v2 = area_vertices[(i + 1) % len(area_vertices)]
            if {v1, v2} == wall_vertices:
                shared_area_count += 1
                break
    
    return shared_area_count <= 1



@router.post("/projects-flutter", response_model=Dict[str, Any], tags=["Flutter Exports"])
def create_project_for_flutter(
    name: str = Form(...),
    description: str = Form(None),
    image_file: UploadFile = File(...),
    model: str = Form("yolo"),
    db: Session = Depends(get_db),
    asset_service: AssetService = Depends(get_asset_service)
):
    """
    Creates a project, runs the full pipeline, and returns a comprehensive response
    containing both the standard JSON and a URL-enriched, coordinate-corrected
    JSON for Flutter. Also creates two separate export files.
    """
    project_repo = ProjectRepository(db)
    try:
        # Steps 1-7: Same as the original /projects endpoint (validation, file saving, project creation, pipeline execution)
        validation_result = validate_image_file(image_file)
        if not validation_result['is_valid']: raise HTTPException(status_code=400, detail=validation_result['error_message'])
        file_info = validation_result['file_info']
        
        safe_filename = generate_safe_filename(image_file.filename, name)
        file_location = os.path.join(UPLOAD_DIRECTORY, safe_filename)
        saved_path = save_uploaded_file(image_file, file_location)
        
        additional_metadata = extract_image_metadata(saved_path)
        if not validate_file_for_processing(saved_path): logger.warning("Image may not be optimal for processing.")

        model = model.lower()
        if model == "yolo": ai_model_flags = {"maskrcnn": False, "yolo": True, "both": False}
        elif model == "maskrcnn": ai_model_flags = {"maskrcnn": True, "yolo": False, "both": False}
        elif model == "both": ai_model_flags = {"maskrcnn": False, "yolo": False, "both": True}
        else: raise HTTPException(status_code=400, detail="Invalid model specified.")

        project = project_repo.create(
            name=name, description=description, original_image_path=saved_path,
            image_width=file_info['image_width'], image_height=file_info['image_height'],
            image_resolution_dpi=additional_metadata.get('image_resolution_dpi', 72),
            image_size_bytes=file_info['file_size_bytes'], image_format=ImageFormat(file_info['image_format']),
            image_color_mode=file_info['image_mode'], image_has_transparency=file_info['has_transparency'],
            image_aspect_ratio=file_info['aspect_ratio'],
            image_dimensions={"width": file_info['image_width'], "height": file_info['image_height']}
        )
        
        processing_config = {"ai_model_flags": ai_model_flags, "processing_config": {}}
        pipeline_result = run_complete_pipeline_sync(project_id=project.id, image_path=saved_path, config=processing_config)

        # --- Step 8: Fetch final data and prepare both JSON versions ---
        with db_manager.get_session() as db_session:
            session_repo = ProcessingSessionRepository(db_session)
            json_stage_repo = JSONStageRepository(db_session)
            project_repo_new = ProjectRepository(db_session)
            
            latest_session = session_repo.get_latest_for_project(project.id)
            if not latest_session:
                raise HTTPException(status_code=404, detail="Session could not be retrieved after processing.")
            
            # --- FIX 2: Re-introduce the logic to create the final_json variable ---
            session_id_final = latest_session.id
            stage4_stage_obj = json_stage_repo.get_by_session_and_stage(session_id_final, 4)
            stage4_data = stage4_stage_obj.output_json if stage4_stage_obj else None
            final_json = create_2layer_json_structure(stage4_data, session_id_final) if stage4_data else None
            
            # Extract other necessary data into local variables before the session closes
            updated_project = project_repo_new.get_by_id(project.id)
            export_path_standard = latest_session.export_file_path
            project_name_final = updated_project.name
            project_status_final = updated_project.status.value if updated_project else "unknown"

        # A. Assign the standard JSON
        standard_final_json = final_json 

        # B. Create the enriched and coordinate-corrected JSON for Flutter
        flutter_final_json = None
        if standard_final_json:
            enriched_json = _enrich_json_with_asset_urls(copy.deepcopy(standard_final_json), asset_service)
            flutter_final_json = _unflip_flutter_json(enriched_json)
            # flutter_final_json = _add_ceilings_to_flutter_json(flutter_final_json)
            # flutter_final_json = _add_ceiling_properties_to_areas(flutter_final_json)
            # flutter_final_json = _add_floor_properties_to_json(flutter_final_json)
            flutter_final_json = _add_floor_and_ceiling_properties_to_areas(flutter_final_json)
            flutter_final_json = _remap_coordinates_for_new_canvas(flutter_final_json)

        # C. Prepare download info for the standard file
        download_info_standard = None
        if export_path_standard and os.path.exists(export_path_standard):
            file_size = os.path.getsize(export_path_standard)
            download_info_standard = {
                "available": True, "file_path": export_path_standard,
                "file_size_bytes": file_size, "file_size_mb": round(file_size / (1024*1024), 2),
                "filename": os.path.basename(export_path_standard)
            }

        # D. Create the separate Flutter export file
        download_info_flutter = None
        if flutter_final_json and export_path_standard:
            try:
                base_dir = os.path.dirname(export_path_standard)
                flutter_filename = f"session_{session_id_final}_flutter.json"
                flutter_export_path = os.path.join(base_dir, flutter_filename)
                
                with open(flutter_export_path, 'w', encoding='utf-8') as f:
                    json.dump(flutter_final_json, f, ensure_ascii=False, indent=2)
                logger.info(f"Successfully created corrected Flutter export file: {flutter_export_path}")

                file_size = os.path.getsize(flutter_export_path)
                download_info_flutter = {
                    "available": True, "file_path": flutter_export_path,
                    "file_size_bytes": file_size, "file_size_mb": round(file_size / (1024*1024), 2),
                    "filename": flutter_filename
                }
            except Exception as e:
                logger.error(f"Failed to create Flutter export file: {e}")
                download_info_flutter = {"available": False, "message": str(e)}

        # E. Build the final response
        return {
            "message": "Project processed. Standard and Flutter JSONs are available.",
            "project_id": project.id,
            "project_name": project_name_final,
            "status": project_status_final,
            "session_id": session_id_final,
            "flutter_json": flutter_final_json,
            "processing_result": pipeline_result,
            "download_flutter": download_info_flutter,
            "image_info": {
                "width": file_info['image_width'], "height": file_info['image_height'],
                "format": file_info['image_format'], "size_mb": round(file_info['file_size_bytes'] / (1024*1024), 2),
                "resolution_dpi": additional_metadata.get('image_resolution_dpi', 72),
                "aspect_ratio": file_info['aspect_ratio']
            }
        }
        
    except Exception as e:
        logger.error(f"Failed to create project for Flutter: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Project creation failed: {str(e)}")
    
@router.post("/update/project-flutter-json/{project_id}", response_model=Dict[str, Any], tags=["Flutter Exports"])
def update_project_flutter_json(
    project_id: int,
    floorplan: dict = Body(...),
    db: Session = Depends(get_db)
):
    """
    Update the Flutter-specific JSON for the latest session of a given project.
    This ONLY modifies the 'session_{id}_flutter.json' file.
    """
    logger.info(f"Received request to update FLUTTER JSON for project ID: {project_id}")
    try:
        from repositories import ProjectRepository, ProcessingSessionRepository
        project_repo = ProjectRepository(db)
        session_repo = ProcessingSessionRepository(db)

        # 1. Find the project and its latest session
        project = project_repo.get_by_id(project_id)
        if not project:
            raise HTTPException(status_code=404, detail=f"Project with ID {project_id} not found.")

        latest_session = session_repo.get_latest_for_project(project_id)
        if not latest_session:
            raise HTTPException(status_code=404, detail=f"No processing sessions found for project {project_id}.")

        # 2. Derive the path for the flutter.json file from the standard export path
        standard_export_path = latest_session.export_file_path
        if not standard_export_path:
            raise HTTPException(status_code=404, detail=f"Standard export path for session {latest_session.id} not found. Cannot determine Flutter file path.")

        base_dir = os.path.dirname(standard_export_path)
        flutter_filename = f"session_{latest_session.id}_flutter.json"
        flutter_export_path = os.path.join(base_dir, flutter_filename)

        # 3. Overwrite the flutter.json file
        with open(flutter_export_path, 'w', encoding='utf-8') as f:
            json.dump(floorplan, f, ensure_ascii=False, indent=2)
        logger.info(f"Successfully overwrote Flutter export file: {flutter_export_path}")

        # Note: We are not updating the database JSON field here, as it should reflect the original pipeline output.
        
        db.commit()
        
        return {
            "success": True,
            "message": f"Flutter floorplan for project {project_id} (session {latest_session.id}) updated successfully.",
            "project_id": project_id,
            "session_id": latest_session.id,
            "updated_file_path": flutter_export_path
        }

    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to update Flutter JSON for project {project_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"An internal error occurred: {str(e)}")


@router.post("/update/session-flutter-json/{session_id}", response_model=Dict[str, Any], tags=["Flutter Exports"])
def update_session_flutter_json(
    session_id: int,
    floorplan: dict = Body(...),
    db: Session = Depends(get_db)
):
    """
    Update the Flutter-specific JSON for a specific session ID.
    This ONLY modifies the 'session_{id}_flutter.json' file.
    """
    logger.info(f"Received request to update FLUTTER JSON for session ID: {session_id}")
    try:
        from repositories import ProcessingSessionRepository
        session_repo = ProcessingSessionRepository(db)
        
        # 1. Find the specific session
        session = session_repo.get_by_id(session_id)
        if not session:
            raise HTTPException(status_code=404, detail=f"Session with ID {session_id} not found.")

        # 2. Derive the path for the flutter.json file
        standard_export_path = session.export_file_path
        if not standard_export_path:
            raise HTTPException(status_code=404, detail=f"Standard export path for session {session_id} not found. Cannot determine Flutter file path.")
        
        base_dir = os.path.dirname(standard_export_path)
        flutter_filename = f"session_{session_id}_flutter.json"
        flutter_export_path = os.path.join(base_dir, flutter_filename)

        # 3. Overwrite the flutter.json file
        with open(flutter_export_path, 'w', encoding='utf-8') as f:
            json.dump(floorplan, f, ensure_ascii=False, indent=2)
        logger.info(f"Successfully overwrote Flutter export file: {flutter_export_path}")
        
        db.commit()

        return {
            "success": True,
            "message": f"Flutter floorplan for session {session_id} updated successfully.",
            "project_id": session.project_id,
            "session_id": session_id,
            "updated_file_path": flutter_export_path
        }

    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to update Flutter JSON for session {session_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"An internal error occurred: {str(e)}")
    

@router.get("/sessions/{session_id}/flutter-json", response_class=FileResponse, tags=["Flutter Exports"])
def get_session_flutter_json(session_id: int, db: Session = Depends(get_db)):
    """
    Retrieves the enriched and coordinate-corrected 'session_{id}_flutter.json' file.
    """
    logger.info(f"Request received for Flutter JSON for session ID: {session_id}")
    try:
        session_repo = ProcessingSessionRepository(db)
        session = session_repo.get_by_id(session_id)

        if not session:
            raise HTTPException(status_code=404, detail=f"Session with ID {session_id} not found.")

        # Derive the path for the flutter.json file from the standard export path
        standard_export_path = session.export_file_path
        if not standard_export_path:
            raise HTTPException(status_code=404, detail=f"Base export path for session {session_id} not found. Cannot locate Flutter file.")

        base_dir = os.path.dirname(standard_export_path)
        flutter_filename = f"session_{session_id}_flutter.json"
        flutter_export_path = os.path.join(base_dir, flutter_filename)

        if not os.path.exists(flutter_export_path):
            raise HTTPException(status_code=404, detail=f"Flutter export file ('{flutter_filename}') not found for session {session_id}.")

        return FileResponse(
            path=flutter_export_path,
            filename=flutter_filename,
            media_type='application/json'
        )
    except Exception as e:
        logger.error(f"Failed to retrieve Flutter JSON for session {session_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"An internal error occurred: {str(e)}")