# database_migration.py

"""
Database migration script to add new image metadata columns and export tracking columns.
Run this script after updating your models to add the new columns to existing database.
"""

import logging
from sqlalchemy import text
from database_manager import db_manager
from models import ImageFormat

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def run_migration():
    """
    Run the database migration to add new columns for image metadata and export tracking.
    """
    try:
        with db_manager.get_session() as db:
            logger.info("Starting database migration...")
            
            # Add image metadata columns to projects table
            image_metadata_columns = [
                "ALTER TABLE projects ADD COLUMN image_width INT NULL",
                "ALTER TABLE projects ADD COLUMN image_height INT NULL", 
                "ALTER TABLE projects ADD COLUMN image_resolution_dpi INT NULL",
                "ALTER TABLE projects ADD COLUMN image_size_bytes INT NULL",
                "ALTER TABLE projects ADD COLUMN image_format ENUM('jpeg', 'jpg', 'png', 'bmp', 'tiff', 'webp') NULL",
                "ALTER TABLE projects ADD COLUMN image_color_mode VARCHAR(20) NULL",
                "ALTER TABLE projects ADD COLUMN image_has_transparency BOOLEAN DEFAULT FALSE",
                "ALTER TABLE projects ADD COLUMN image_aspect_ratio FLOAT NULL"
            ]
            
            # Add export tracking columns to processing_sessions table
            export_tracking_columns = [
                "ALTER TABLE processing_sessions ADD COLUMN export_file_path VARCHAR(500) NULL",
                "ALTER TABLE processing_sessions ADD COLUMN export_file_size_bytes INT NULL", 
                "ALTER TABLE processing_sessions ADD COLUMN export_created_at TIMESTAMP NULL",
                "ALTER TABLE processing_sessions ADD COLUMN export_format_version VARCHAR(20) DEFAULT '2.1'"
            ]
            
            # Execute image metadata columns
            logger.info("Adding image metadata columns to projects table...")
            for sql in image_metadata_columns:
                try:
                    db.execute(text(sql))
                    logger.info(f"✓ Executed: {sql}")
                except Exception as e:
                    if "Duplicate column name" in str(e) or "already exists" in str(e):
                        logger.info(f"✓ Column already exists: {sql}")
                    else:
                        logger.error(f"✗ Failed: {sql} - {e}")
                        raise
            
            # Execute export tracking columns
            logger.info("Adding export tracking columns to processing_sessions table...")
            for sql in export_tracking_columns:
                try:
                    db.execute(text(sql))
                    logger.info(f"✓ Executed: {sql}")
                except Exception as e:
                    if "Duplicate column name" in str(e) or "already exists" in str(e):
                        logger.info(f"✓ Column already exists: {sql}")
                    else:
                        logger.error(f"✗ Failed: {sql} - {e}")
                        raise
            
            # Add indexes for better performance
            indexes = [
                "CREATE INDEX IF NOT EXISTS idx_projects_image_format ON projects (image_format)",
                "CREATE INDEX IF NOT EXISTS idx_projects_image_size ON projects (image_width, image_height)",
                "CREATE INDEX IF NOT EXISTS idx_sessions_export_created ON processing_sessions (export_created_at)"
            ]
            
            logger.info("Adding performance indexes...")
            for sql in indexes:
                try:
                    db.execute(text(sql))
                    logger.info(f"✓ Created index: {sql}")
                except Exception as e:
                    logger.warning(f"⚠ Index creation warning: {sql} - {e}")
            
            db.commit()
            logger.info("✅ Database migration completed successfully!")
            
            # Migration verification
            logger.info("Verifying migration...")
            verify_migration(db)
            
    except Exception as e:
        logger.error(f"❌ Migration failed: {e}")
        raise

def verify_migration(db):
    """
    Verify that the migration was successful by checking if new columns exist.
    """
    try:
        # Check projects table columns  
        result = db.execute(text("DESCRIBE projects"))
        project_columns = [row[0] for row in result.fetchall()]
        
        expected_project_columns = [
            'image_width', 'image_height', 'image_resolution_dpi', 
            'image_size_bytes', 'image_format', 'image_color_mode',
            'image_has_transparency', 'image_aspect_ratio'
        ]
        
        missing_project_columns = [col for col in expected_project_columns if col not in project_columns]
        if missing_project_columns:
            logger.error(f"Missing project columns: {missing_project_columns}")
            return False
        
        logger.info("✓ All project image metadata columns verified")
        
        # Check processing_sessions table columns
        result = db.execute(text("DESCRIBE processing_sessions"))
        session_columns = [row[0] for row in result.fetchall()]
        
        expected_session_columns = [
            'export_file_path', 'export_file_size_bytes', 
            'export_created_at', 'export_format_version'
        ]
        
        missing_session_columns = [col for col in expected_session_columns if col not in session_columns]
        if missing_session_columns:
            logger.error(f"Missing session columns: {missing_session_columns}")
            return False
            
        logger.info("✓ All session export tracking columns verified")
        
        # Test data insertion
        logger.info("Testing data insertion...")
        test_insert = text("""
            INSERT INTO projects (name, description, image_width, image_height, image_format) 
            VALUES ('migration_test', 'test', 1920, 1080, 'png')
        """)
        result = db.execute(test_insert)
        test_id = result.lastrowid
        
        # Clean up test data
        db.execute(text(f"DELETE FROM projects WHERE id = {test_id}"))
        db.commit()
        
        logger.info("✓ Data insertion test successful")
        logger.info("🎉 Migration verification completed successfully!")
        return True
        
    except Exception as e:
        logger.error(f"❌ Migration verification failed: {e}")
        return False

def rollback_migration():
    """
    Rollback the migration by removing the added columns.
    USE WITH CAUTION - This will delete data in the new columns.
    """
    try:
        with db_manager.get_session() as db:
            logger.warning("⚠️  STARTING MIGRATION ROLLBACK - This will delete data!")
            
            # Remove image metadata columns from projects table
            rollback_project_columns = [
                "ALTER TABLE projects DROP COLUMN image_width",
                "ALTER TABLE projects DROP COLUMN image_height",
                "ALTER TABLE projects DROP COLUMN image_resolution_dpi", 
                "ALTER TABLE projects DROP COLUMN image_size_bytes",
                "ALTER TABLE projects DROP COLUMN image_format",
                "ALTER TABLE projects DROP COLUMN image_color_mode",
                "ALTER TABLE projects DROP COLUMN image_has_transparency",
                "ALTER TABLE projects DROP COLUMN image_aspect_ratio"
            ]
            
            # Remove export tracking columns from processing_sessions table
            rollback_session_columns = [
                "ALTER TABLE processing_sessions DROP COLUMN export_file_path",
                "ALTER TABLE processing_sessions DROP COLUMN export_file_size_bytes",
                "ALTER TABLE processing_sessions DROP COLUMN export_created_at", 
                "ALTER TABLE processing_sessions DROP COLUMN export_format_version"
            ]
            
            # Execute rollback
            for sql in rollback_project_columns + rollback_session_columns:
                try:
                    db.execute(text(sql))
                    logger.info(f"✓ Rolled back: {sql}")
                except Exception as e:
                    if "doesn't exist" in str(e) or "Unknown column" in str(e):
                        logger.info(f"✓ Column already removed: {sql}")
                    else:
                        logger.error(f"✗ Rollback failed: {sql} - {e}")
                        raise
            
            db.commit()
            logger.info("✅ Migration rollback completed!")
            
    except Exception as e:
        logger.error(f"❌ Rollback failed: {e}")
        raise

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "rollback":
        rollback_migration()
    else:
        run_migration()
    
    print("\nMigration script completed. You can now restart your application.")